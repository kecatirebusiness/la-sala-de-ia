import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';
import path from 'path';
const secs = process.argv.slice(2).map(Number);
const serveUrl = await bundle({entryPoint: path.resolve('src/index.ts')});
const comp = await selectComposition({serveUrl, id: 'Replica'});
for (const s of secs) {
  await renderStill({serveUrl, composition: comp, frame: Math.round(s * 30), output: `stills/s${s}.png`, scale: 0.5});
  console.log('ok', s);
}
