import React from 'react';
import {interpolate, Easing, Img, staticFile} from 'remotion';
import {SANS, MONO, INK, MUTED, LINE, GREEN, GREEN_SOFT, RED, useT, sp, lin, Logo, Ico, Pop, Typed, Count, Cursor} from './base';
import {Agente} from './diagrama';

// ---------- marco de módulo ----------
export const Cabecera: React.FC<{num: number; titulo: string; agentes: number; at: number}> = ({num, titulo, agentes, at}) => (
  <Pop at={at} style={{position: 'absolute', left: 92, right: 92, top: 246, display: 'flex', alignItems: 'center', gap: 12}}>
    <div style={{width: 40, height: 40, borderRadius: 11, background: INK, color: '#fff', fontFamily: SANS, fontWeight: 800, fontSize: 24, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{num}</div>
    <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 34, color: INK, letterSpacing: -0.8}}>{titulo}</div>
    <div style={{marginLeft: 'auto', fontFamily: MONO, fontSize: 15, color: GREEN, fontWeight: 700, letterSpacing: 1.5}}>{agentes} AGENTES</div>
  </Pop>
);

// panel lavanda detrás de la ventana
export const Escenario: React.FC<{at: number}> = ({at}) => {
  const {t, fps} = useT();
  const s = sp(t, at, fps);
  return <div style={{position: 'absolute', left: 90, top: 306, width: 900, height: 700, borderRadius: 38, background: 'linear-gradient(180deg, #F0EDFB 0%, #F6EEF8 55%, #FBF0F4 100%)', opacity: s, transform: `scale(${0.96 + 0.04 * s})`}} />;
};

// ventana tipo app
export const Ventana: React.FC<{titulo: string; logo: string; children: React.ReactNode; tag?: string}> = ({titulo, logo, children, tag}) => (
  <div style={{position: 'absolute', left: 120, top: 336, width: 960, height: 660, transform: 'scale(0.875)', transformOrigin: '0 0', background: '#fff', borderRadius: 30, boxShadow: '0 30px 60px -30px rgba(14,20,17,.45), 0 0 0 1.5px rgba(14,20,17,.07)', overflow: 'hidden'}}>
    <div style={{height: 62, borderBottom: `1.5px solid ${LINE}`, display: 'flex', alignItems: 'center', padding: '0 22px', gap: 10, background: '#FAFBF9'}}>
      {['#FF5F57', '#FEBC2E', '#28C840'].map((c) => <div key={c} style={{width: 14, height: 14, borderRadius: 7, background: c}} />)}
      <div style={{flex: 1, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 10, fontFamily: SANS, fontWeight: 600, fontSize: 21, color: MUTED}}>
        <Logo n={logo} size={30} />
        {titulo}
      </div>
      {tag ? <div style={{fontFamily: MONO, fontSize: 15, fontWeight: 700, color: GREEN, background: GREEN_SOFT, borderRadius: 999, padding: '5px 12px'}}>{tag}</div> : <div style={{width: 60}} />}
    </div>
    <div style={{position: 'absolute', left: 0, right: 0, top: 62, bottom: 0}}>{children}</div>
  </div>
);

// cambia de pantalla según el tiempo, con cruce
export const Secuencia: React.FC<{items: {at: number; el: React.ReactNode}[]; end: number}> = ({items, end}) => {
  const {t} = useT();
  return (
    <>
      {items.map((it, i) => {
        const fin = i < items.length - 1 ? items[i + 1].at : end;
        if (t < it.at - 0.05 || t > fin + 0.3) return null;
        const a = lin(t, it.at, it.at + 0.35, 0, 1, Easing.out(Easing.cubic));
        const b = i < items.length - 1 ? lin(t, fin, fin + 0.3) : 0;
        return (
          <div key={i} style={{position: 'absolute', inset: 0, opacity: a * (1 - b), transform: `translateY(${(1 - a) * 40 - b * 30}px) scale(${0.97 + 0.03 * a})`, filter: `blur(${(1 - a) * 8 + b * 6}px)`}}>
            {it.el}
          </div>
        );
      })}
    </>
  );
};

// tarjeta del módulo abajo con los agentes que trabajan ahora
export const Tarjeta: React.FC<{titulo: string; agentes: Agente[]; activos: {at: number; idx: number[]}[]; at: number; cols?: number}> = ({titulo, agentes, activos, at, cols = 2}) => {
  const {t, fps} = useT();
  const s = sp(t, at + 0.2, fps);
  let act: number[] = [];
  for (const a of activos) if (t >= a.at) act = a.idx;
  const filas = Math.ceil(agentes.length / cols);
  const h = 64 + filas * 36;
  const w = cols === 1 ? 470 : 760;
  return (
    <>
      <svg style={{position: 'absolute', left: 0, top: 1000}} width={1080} height={70}>
        <path d={`M${540 - w / 2 + 40} 62 V 14`} stroke={GREEN} strokeWidth={2.5} strokeDasharray="5 6" strokeDashoffset={t * 20} />
        <path d={`M${540 - w / 2 + 32} 20 L ${540 - w / 2 + 40} 8 L ${540 - w / 2 + 48} 20`} stroke={GREEN} strokeWidth={2.5} fill="none" />
      </svg>
      <div style={{position: 'absolute', left: 540 - w / 2, width: w, top: 1062, height: h, background: '#fff', borderRadius: 22, border: `1.5px solid ${LINE}`, boxShadow: '0 18px 40px -24px rgba(14,20,17,.45)', padding: '14px 20px', opacity: s, transform: `translateY(${(1 - s) * 30}px)`}}>
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'baseline'}}>
          <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 23, color: INK, letterSpacing: -0.4}}>{titulo}</div>
          <div style={{fontFamily: MONO, fontSize: 13, color: MUTED}}>{agentes.length} agentes</div>
        </div>
        <div style={{display: 'grid', gridTemplateColumns: `repeat(${cols}, 1fr)`, gridAutoFlow: 'column', gridTemplateRows: `repeat(${filas}, 33px)`, columnGap: 14, rowGap: 3, marginTop: 8}}>
          {agentes.map((a, k) => {
            const on = act.includes(k);
            return (
              <div key={k} style={{display: 'flex', alignItems: 'center', gap: 7, borderRadius: 10, padding: '0 8px', background: on ? GREEN_SOFT : 'transparent', border: `1.5px solid ${on ? GREEN : 'transparent'}`, opacity: on ? 1 : 0.38}}>
                <Logo n={a.l} size={22} />
                <Logo n="claude" size={22} tile={false} />
                <span style={{fontFamily: SANS, fontWeight: on ? 700 : 500, fontSize: 16.5, color: INK, whiteSpace: 'nowrap'}}>{a.n}</span>
                {on ? <span style={{marginLeft: 'auto', width: 9, height: 9, borderRadius: 5, background: GREEN, boxShadow: `0 0 0 ${3 + 3 * Math.abs(Math.sin(t * 5))}px rgba(0,194,106,.2)`}} /> : null}
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
};

// ====================== MÓDULO 1 ======================
export const Tendencias: React.FC<{at: number}> = ({at}) => {
  const {t} = useT();
  const d = lin(t, at + 0.1, at + 1.5, 0, 1, Easing.out(Easing.cubic));
  const kw = [
    {k: 'agentes de IA', v: '+340%', c: GREEN},
    {k: 'Claude Code', v: '+210%', c: '#7C6CFF'},
    {k: 'automatizar negocio', v: '+120%', c: '#F59E0B'},
    {k: 'ChatGPT para ventas', v: '+45%', c: '#F472B6'},
  ];
  const paths = ['M0 230 C 120 225, 220 215, 300 190 S 420 60, 470 20', 'M0 240 C 140 230, 260 200, 340 160 S 430 120, 470 100', 'M0 235 C 160 228, 300 215, 380 190 S 450 170, 470 165', 'M0 245 C 200 242, 320 232, 400 222 S 450 214, 470 212'];
  return (
    <Ventana titulo="Google Trends · tu mercado · 7 días" logo="trends" tag="EN VIVO">
      <div style={{position: 'absolute', left: 40, top: 30, fontFamily: SANS, fontWeight: 600, fontSize: 22, color: MUTED}}>Interés en el tiempo</div>
      <svg style={{position: 'absolute', left: 40, top: 80}} width={500} height={270} viewBox="0 0 470 260">
        {[60, 120, 180, 240].map((y) => <path key={y} d={`M0 ${y} H470`} stroke="#EEF0EC" strokeWidth={1.5} />)}
        {paths.map((p, i) => <path key={i} d={p} stroke={kw[i].c} strokeWidth={i === 0 ? 6 : 3.5} fill="none" strokeLinecap="round" strokeDasharray="700" strokeDashoffset={700 * (1 - d)} opacity={i === 0 ? 1 : 0.7} />)}
      </svg>
      <div style={{position: 'absolute', left: 580, top: 90, display: 'flex', flexDirection: 'column', gap: 22}}>
        {kw.map((k, i) => (
          <Pop key={i} at={at + 0.3 + i * 0.15} style={{display: 'flex', alignItems: 'center', gap: 12}}>
            <div style={{width: 14, height: 14, borderRadius: 7, background: k.c}} />
            <span style={{fontFamily: SANS, fontWeight: 600, fontSize: 23, color: INK, width: 230}}>{k.k}</span>
            <span style={{fontFamily: MONO, fontWeight: 700, fontSize: 20, color: k.c === GREEN ? GREEN : MUTED}}>{k.v}</span>
          </Pop>
        ))}
      </div>
      <Pop at={at + 1.5} style={{position: 'absolute', left: 40, right: 40, top: 390, border: `2.5px solid ${GREEN}`, background: GREEN_SOFT, borderRadius: 24, padding: '26px 30px'}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 10, fontFamily: MONO, fontWeight: 700, fontSize: 18, color: GREEN, letterSpacing: 1.5}}><Ico n="fire" size={24} color={GREEN} /> SUBIENDO EN TU MERCADO</div>
        <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 56, color: INK, marginTop: 8, letterSpacing: -1.2}}>“agentes de IA”</div>
        <div style={{display: 'flex', gap: 12, marginTop: 12}}>
          <span style={{background: GREEN, color: '#fff', fontFamily: SANS, fontWeight: 700, fontSize: 20, borderRadius: 999, padding: '6px 16px'}}>+340% esta semana</span>
          <span style={{background: '#fff', color: INK, fontFamily: SANS, fontWeight: 600, fontSize: 20, borderRadius: 999, padding: '6px 16px', border: `1.5px solid ${LINE}`}}>poca competencia</span>
        </div>
      </Pop>
    </Ventana>
  );
};

export const Audiencia: React.FC<{at: number}> = ({at}) => {
  const qs = [
    {v: '1.2K', q: '¿Cómo uso IA en mi negocio sin saber programar?'},
    {v: '860', q: '¿Qué agente me ahorra más horas a la semana?'},
    {v: '540', q: '¿Claude o ChatGPT para vender más?'},
  ];
  const bars = [{l: 'instagram', n: 'Instagram', p: 48}, {l: 'youtube', n: 'YouTube', p: 31}, {l: 'tiktok', n: 'TikTok', p: 21}];
  const {t} = useT();
  return (
    <Ventana titulo="Reddit · r/emprendedores · lo más votado" logo="reddit">
      <div style={{position: 'absolute', left: 40, right: 40, top: 30, display: 'flex', flexDirection: 'column', gap: 16}}>
        {qs.map((q, i) => (
          <Pop key={i} at={at + 0.15 + i * 0.32} style={{display: 'flex', alignItems: 'center', gap: 18, background: '#FAFBF9', border: `1.5px solid ${LINE}`, borderRadius: 18, padding: '16px 20px'}}>
            <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', width: 64}}>
              <Ico n="up" size={26} color="#FF4500" w={2.6} />
              <span style={{fontFamily: MONO, fontWeight: 700, fontSize: 18, color: INK}}>{q.v}</span>
            </div>
            <span style={{fontFamily: SANS, fontWeight: 600, fontSize: 26, color: INK, lineHeight: 1.2}}>{q.q}</span>
          </Pop>
        ))}
      </div>
      <Pop at={at + 1.2} style={{position: 'absolute', left: 40, right: 40, top: 390, background: '#fff', border: `1.5px solid ${LINE}`, borderRadius: 22, padding: '22px 28px'}}>
        <div style={{fontFamily: MONO, fontSize: 16, fontWeight: 700, color: MUTED, letterSpacing: 1.5}}>DÓNDE ESTÁ TU AUDIENCIA</div>
        {bars.map((b, i) => {
          const w = lin(t, at + 1.4 + i * 0.12, at + 2.2 + i * 0.12) * b.p;
          return (
            <div key={i} style={{display: 'flex', alignItems: 'center', gap: 14, marginTop: 14}}>
              <Logo n={b.l} size={34} />
              <span style={{fontFamily: SANS, fontWeight: 600, fontSize: 21, width: 120}}>{b.n}</span>
              <div style={{flex: 1, height: 14, background: '#EEF0EC', borderRadius: 7}}><div style={{width: `${w * 1.6}%`, height: 14, borderRadius: 7, background: GREEN}} /></div>
              <span style={{fontFamily: MONO, fontWeight: 700, fontSize: 20, width: 60, textAlign: 'right'}}>{Math.round(w)}%</span>
            </div>
          );
        })}
      </Pop>
    </Ventana>
  );
};

export const Escritor: React.FC<{at: number; mail: number}> = ({at, mail}) => (
  <Ventana titulo="Notion · borrador de post · Instagram" logo="notion" tag="ESCRIBIENDO">
    <div style={{position: 'absolute', left: 44, right: 44, top: 34}}>
      <div style={{fontFamily: MONO, fontSize: 16, fontWeight: 700, color: MUTED, letterSpacing: 1.5}}>CLAUDE · ESCRITOR DE POSTS</div>
      <div style={{fontFamily: SANS, fontWeight: 700, fontSize: 36, color: INK, lineHeight: 1.22, marginTop: 14, letterSpacing: -0.5}}>
        <Typed at={at + 0.2} cps={34} text="Los agentes de IA ya trabajan para tu competencia. Así pones el tuyo a trabajar en 20 minutos:" />
      </div>
    </div>
    <Pop at={mail} style={{position: 'absolute', left: 30, right: 30, top: 330, background: '#FAFBF9', border: `1.5px solid ${LINE}`, borderRadius: 22, padding: '20px 26px'}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 10, fontFamily: SANS, fontWeight: 600, fontSize: 20, color: MUTED}}><Logo n="gmail" size={30} /> Gmail · borrador del newsletter</div>
      <div style={{fontFamily: SANS, fontSize: 26, color: INK, marginTop: 16}}><b>Asunto: </b><Typed at={mail + 0.2} cps={30} text="Tu primer agente en 20 minutos" /></div>
      <div style={{height: 12, width: '82%', background: '#ECEFEA', borderRadius: 6, marginTop: 18}} />
      <div style={{height: 12, width: '64%', background: '#ECEFEA', borderRadius: 6, marginTop: 10}} />
      <div style={{height: 12, width: '74%', background: '#ECEFEA', borderRadius: 6, marginTop: 10}} />
    </Pop>
  </Ventana>
);

const DIAS = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
const CHIPS = [['instagram', 'Reel: agentes'], ['tiktok', '3 errores'], ['youtube', 'Tutorial'], ['instagram', 'Carrusel'], ['gmail', 'Newsletter'], ['tiktok', 'Antes/después'], ['instagram', 'Historia'], ['linkedin', 'Caso real'], ['tiktok', 'Tip rápido'], ['youtube', 'En vivo'], ['instagram', 'Reel: Claude'], ['gmail', 'Oferta'], ['tiktok', 'Pregunta'], ['instagram', 'Resumen']];
export const Calendario: React.FC<{at: number; compact?: boolean}> = ({at, compact}) => (
  <Ventana titulo="Notion · plan de contenido · próxima semana" logo="notion" tag="14 POSTS">
    <div style={{position: 'absolute', left: 26, right: 26, top: 26, display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 10}}>
      {DIAS.map((d, i) => (
        <div key={d}>
          <div style={{fontFamily: MONO, fontWeight: 700, fontSize: 17, color: MUTED, textAlign: 'center', marginBottom: 10}}>{d}</div>
          {[0, 1].map((r) => {
            const c = CHIPS[i * 2 + r];
            return (
              <Pop key={r} at={at + 0.15 + (i * 2 + r) * 0.11} style={{background: '#FAFBF9', border: `1.5px solid ${LINE}`, borderRadius: 14, padding: '10px 8px', marginBottom: 10, height: compact ? 96 : 150, display: 'flex', flexDirection: 'column', gap: 8}}>
                <Logo n={c[0]} size={30} />
                <span style={{fontFamily: SANS, fontWeight: 600, fontSize: 17, color: INK, lineHeight: 1.1}}>{c[1]}</span>
              </Pop>
            );
          })}
        </div>
      ))}
    </div>
  </Ventana>
);

export const Competencia: React.FC<{at: number}> = ({at}) => {
  const {t} = useT();
  const a = lin(t, at + 0.6, at + 1.4);
  return (
    <Ventana titulo="Buscador de keywords · antes que la competencia" logo="googleanalytics">
      <Pop at={at + 0.1} style={{position: 'absolute', left: 40, right: 40, top: 40, border: `2px solid ${LINE}`, borderRadius: 24, padding: '26px 30px', display: 'flex', alignItems: 'center', gap: 20}}>
        <Ico n="fire" size={44} color={RED} />
        <div>
          <div style={{fontFamily: MONO, fontSize: 16, fontWeight: 700, color: MUTED, letterSpacing: 1.5}}>MÁS GENTE BUSCANDO</div>
          <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 44, color: INK, letterSpacing: -1}}>“agentes de IA”</div>
        </div>
        <div style={{marginLeft: 'auto', textAlign: 'right'}}>
          <div style={{fontFamily: SANS, fontWeight: 900, fontSize: 60, color: GREEN}}><Count from={0} to={74} at={at + 0.2} dur={1} />K</div>
          <div style={{fontFamily: MONO, fontSize: 15, color: MUTED}}>búsquedas / mes</div>
        </div>
      </Pop>
      <Pop at={at + 0.5} style={{position: 'absolute', left: 40, right: 40, top: 270, border: `2px solid ${LINE}`, borderRadius: 24, padding: '28px 30px'}}>
        <div style={{fontFamily: MONO, fontSize: 16, fontWeight: 700, color: MUTED, letterSpacing: 1.5, marginBottom: 22}}>MISMO TEMA · ¿QUIÉN LLEGA PRIMERO?</div>
        {[{n: 'Tú', w: 1, c: GREEN, tag: 'Publicado mañana'}, {n: 'Tu competencia', w: 0.22, c: RED, tag: 'Ni lo ha visto'}].map((r, i) => (
          <div key={i} style={{display: 'flex', alignItems: 'center', gap: 16, marginBottom: 22}}>
            <div style={{width: 46, height: 46, borderRadius: 23, background: i === 0 ? INK : '#DADFD8', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Ico n="user" size={26} color={i === 0 ? '#fff' : MUTED} /></div>
            <span style={{fontFamily: SANS, fontWeight: 700, fontSize: 24, width: 190}}>{r.n}</span>
            <div style={{flex: 1, height: 16, background: '#EEF0EC', borderRadius: 8}}><div style={{width: `${r.w * a * 100}%`, height: 16, borderRadius: 8, background: r.c}} /></div>
            <span style={{background: r.c, color: '#fff', fontFamily: SANS, fontWeight: 700, fontSize: 17, borderRadius: 999, padding: '5px 12px', opacity: a, whiteSpace: 'nowrap'}}>{r.tag}</span>
          </div>
        ))}
      </Pop>
    </Ventana>
  );
};

export const Bonito: React.FC<{at: number}> = ({at}) => {
  const {t} = useT();
  const ar = lin(t, at + 0.35, at + 0.8);
  return (
    <Ventana titulo="Del texto al contenido" logo="claude">
      <Pop at={at} style={{position: 'absolute', left: 44, top: 70, width: 330, height: 470, background: '#FAFBF9', border: `1.5px solid ${LINE}`, borderRadius: 22, padding: 22}}>
        <div style={{fontFamily: MONO, fontSize: 14, fontWeight: 700, color: MUTED, letterSpacing: 1.2}}>BORRADOR</div>
        <div style={{fontFamily: SANS, fontWeight: 600, fontSize: 22, color: INK, marginTop: 12, lineHeight: 1.3}}>Los agentes de IA ya trabajan para tu competencia. Así pones el tuyo a trabajar en 20 minutos:</div>
        {[80, 64, 72].map((w, i) => <div key={i} style={{height: 11, width: `${w}%`, background: '#E7EAE5', borderRadius: 6, marginTop: 14}} />)}
      </Pop>
      <div style={{position: 'absolute', left: 392, top: 280, opacity: ar, transform: `translateX(${(1 - ar) * -20}px)`}}><Ico n="arrow" size={64} color={GREEN} w={2.6} /></div>
      <Pop at={at + 0.6} style={{position: 'absolute', left: 480, top: 30, width: 320, height: 560, borderRadius: 30, overflow: 'hidden', background: '#000', boxShadow: '0 24px 40px -20px rgba(0,0,0,.6)'}}>
        <Foto i="kevin3" style={{position: 'absolute', inset: 0}}><div style={SOMBRA} /></Foto>
        <div style={{position: 'absolute', left: 24, right: 24, bottom: 96, fontFamily: SANS, fontWeight: 900, fontSize: 38, color: '#fff', lineHeight: 1.02, letterSpacing: -1}}>Los agentes de IA ya trabajan para tu competencia</div>
        <div style={{position: 'absolute', left: 24, bottom: 40, background: GREEN, color: INK, fontFamily: SANS, fontWeight: 800, fontSize: 18, borderRadius: 999, padding: '6px 14px'}}>Comenta IA</div>
      </Pop>
      <Pop at={at + 1} style={{position: 'absolute', left: 520, top: 604, display: 'flex', alignItems: 'center', gap: 8, fontFamily: SANS, fontWeight: 600, fontSize: 18, color: GREEN}}><Ico n="check" size={20} color={GREEN} w={3} />Listo · con tu marca</Pop>
    </Ventana>
  );
};

// ====================== MÓDULO 2 ======================
const TILES = [
  {i: 'g1', t: 'Mi panadería con IA'},
  {i: 'kevin14', t: 'Tu agente en 20 min'},
  {i: 'g3', t: 'La barbería que no falla'},
];
export const Foto: React.FC<{i: string; style?: React.CSSProperties; children?: React.ReactNode}> = ({i, style, children}) => (
  <div style={{position: 'relative', overflow: 'hidden', ...style}}>
    <Img src={staticFile(`img/${i}.jpg`)} style={{position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover'}} />
    {children}
  </div>
);
const SOMBRA: React.CSSProperties = {position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(0,0,0,0) 45%, rgba(0,0,0,.7))'};
export const Graficos: React.FC<{at: number}> = ({at}) => {
  const {t} = useT();
  return (
    <Ventana titulo="Higgsfield · gráficos y videos" logo="higgsfield" tag="GENERANDO">
      <div style={{position: 'absolute', left: 36, right: 36, top: 36, display: 'flex', gap: 22}}>
        {TILES.map((x, i) => {
          const g = lin(t, at + 0.2 + i * 0.35, at + 1.3 + i * 0.35);
          return (
            <Pop key={i} at={at + 0.1 + i * 0.15} style={{flex: 1, height: 500, borderRadius: 24, overflow: 'hidden', position: 'relative', background: '#EEF0EC'}}>
              <Foto i={x.i} style={{position: 'absolute', inset: 0, opacity: g, filter: `blur(${(1 - g) * 24}px)`}}><div style={SOMBRA} /></Foto>
              <div style={{position: 'absolute', left: 20, right: 20, bottom: 66, fontFamily: SANS, fontWeight: 900, fontSize: 34, color: '#fff', lineHeight: 1.02, opacity: g}}>{x.t}</div>
              <div style={{position: 'absolute', left: 20, bottom: 22, display: 'flex', alignItems: 'center', gap: 6, fontFamily: MONO, fontSize: 15, fontWeight: 700, color: '#fff', opacity: g}}><Ico n="play" size={18} color="#fff" /> 0:{18 + i * 7}</div>
              {g < 1 ? <div style={{position: 'absolute', left: 20, right: 20, top: 230, height: 8, background: 'rgba(14,20,17,.12)', borderRadius: 4}}><div style={{width: `${g * 100}%`, height: 8, borderRadius: 4, background: INK}} /></div> : null}
              {g >= 1 ? <div style={{position: 'absolute', right: 14, top: 14, width: 38, height: 38, borderRadius: 19, background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Ico n="check" size={22} color={GREEN} w={3} /></div> : null}
            </Pop>
          );
        })}
      </div>
    </Ventana>
  );
};

export const Voz: React.FC<{at: number}> = ({at}) => {
  const {t} = useT();
  return (
    <Ventana titulo="ElevenLabs · voz" logo="elevenlabs">
      <Pop at={at} style={{position: 'absolute', left: 36, right: 36, top: 36, height: 340, borderRadius: 26, background: INK, padding: 30, overflow: 'hidden'}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 14}}>
          <div style={{width: 54, height: 54, borderRadius: 27, background: '#24302A', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Ico n="user" size={30} color="#fff" /></div>
          <div>
            <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 28, color: '#fff'}}>Tu voz</div>
            <div style={{fontFamily: MONO, fontSize: 15, color: '#8FA39A'}}>clonada · español</div>
          </div>
          <div style={{marginLeft: 'auto', fontFamily: MONO, fontSize: 15, fontWeight: 700, color: INK, background: GREEN, borderRadius: 999, padding: '6px 14px'}}>● grabando</div>
        </div>
        <div style={{display: 'flex', alignItems: 'center', gap: 6, height: 150, marginTop: 20}}>
          {Array.from({length: 52}).map((_, i) => {
            const h = 16 + Math.abs(Math.sin(i * 0.9 + t * 9) * Math.cos(i * 0.37 + t * 4)) * 120;
            const on = i / 52 < lin(t, at + 0.2, at + 1.8);
            return <div key={i} style={{width: 9, height: h, borderRadius: 5, background: on ? GREEN : '#33413A'}} />;
          })}
        </div>
      </Pop>
      <div style={{position: 'absolute', left: 36, right: 36, top: 404, display: 'flex', gap: 18}}>
        {TILES.map((x, i) => (
          <Pop key={i} at={at + 0.5 + i * 0.25} style={{flex: 1, height: 200, borderRadius: 20, overflow: 'hidden', position: 'relative'}}>
            <Foto i={x.i} style={{position: 'absolute', inset: 0}} />
            <div style={{position: 'absolute', right: 12, top: 12, display: 'flex', alignItems: 'center', gap: 6, background: '#fff', borderRadius: 999, padding: '4px 10px', fontFamily: MONO, fontWeight: 700, fontSize: 14}}><Ico n="check" size={16} color={GREEN} w={3} />con voz</div>
          </Pop>
        ))}
      </div>
    </Ventana>
  );
};

export const Aprobar: React.FC<{at: number; click: number}> = ({at, click}) => {
  const {t} = useT();
  const cx = interpolate(t, [at + 0.1, click - 0.05], [820, 640], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)});
  const cy = interpolate(t, [at + 0.1, click - 0.05], [620, 488], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)});
  const pr = t > click - 0.05 && t < click + 0.15 ? 1 : 0;
  const ok = t >= click;
  return (
    <Ventana titulo="WhatsApp · mesa de aprobación" logo="whatsapp">
      <Pop at={at} style={{position: 'absolute', left: 40, right: 40, top: 40, background: '#FAFBF9', border: `1.5px solid ${LINE}`, borderRadius: 24, padding: 26}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 12}}>
          <Logo n="sala" size={44} />
          <div>
            <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 24}}>Mesa de aprobación</div>
            <div style={{fontFamily: SANS, fontSize: 19, color: MUTED}}>3 piezas listas para publicar</div>
          </div>
        </div>
        <div style={{display: 'flex', gap: 14, marginTop: 20}}>
          {TILES.map((x, i) => <Foto key={i} i={x.i} style={{flex: 1, height: 210, borderRadius: 18, border: t >= click ? `3px solid ${GREEN}` : '3px solid transparent'}} />)}
        </div>
        <div style={{display: 'flex', justifyContent: 'flex-end', gap: 14, marginTop: 22}}>
          <div style={{fontFamily: SANS, fontWeight: 700, fontSize: 22, color: MUTED, border: `1.5px solid ${LINE}`, borderRadius: 999, padding: '12px 26px'}}>Cambiar</div>
          <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 22, color: ok ? '#fff' : INK, background: ok ? GREEN : '#FFC83D', borderRadius: 999, padding: '12px 30px', display: 'flex', alignItems: 'center', gap: 8, transform: `scale(${pr ? 0.94 : 1})`}}>
            {ok ? <Ico n="check" size={22} color="#fff" w={3} /> : null}{ok ? 'Aprobado' : 'Aprobar'}
          </div>
        </div>
      </Pop>
      <Cursor x={cx} y={cy} press={pr} />
    </Ventana>
  );
};

const CANALES = [['tiktok', 'TikTok'], ['instagram', 'Instagram'], ['youtube', 'YouTube'], ['linkedin', 'LinkedIn'], ['facebook', 'Facebook'], ['x', 'X']];
export const Publicar: React.FC<{at: number}> = ({at}) => {
  const {t} = useT();
  return (
    <Ventana titulo="Programador · publicando" logo="meta" tag="6 CANALES">
      <div style={{position: 'absolute', left: 40, right: 40, top: 30, display: 'flex', flexDirection: 'column', gap: 12}}>
        {CANALES.map((c, i) => {
          const done = t >= at + 0.25 + i * 0.22;
          return (
            <Pop key={i} at={at + i * 0.08} style={{display: 'flex', alignItems: 'center', gap: 16, border: `1.5px solid ${done ? GREEN : LINE}`, background: done ? GREEN_SOFT : '#fff', borderRadius: 18, padding: '12px 20px'}}>
              <Logo n={c[0]} size={44} />
              <span style={{fontFamily: SANS, fontWeight: 700, fontSize: 25}}>{c[1]}</span>
              <span style={{marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8, fontFamily: MONO, fontWeight: 700, fontSize: 18, color: done ? GREEN : MUTED}}>
                {done ? <><Ico n="check" size={22} color={GREEN} w={3} />PUBLICADO</> : 'EN COLA'}
              </span>
            </Pop>
          );
        })}
      </div>
    </Ventana>
  );
};

export const Comentarios: React.FC<{at: number}> = ({at}) => {
  const C = [
    {u: 'barberia.luis', q: '¿Esto funciona para una barbería?', r: '¡Claro! Te mandé la guía por DM para que lo pruebes hoy.'},
    {u: 'ana.cafe', q: 'INFO', r: 'Listo, Ana. Revisa tus mensajes.'},
  ];
  return (
    <Ventana titulo="Instagram · comentarios y DMs" logo="instagram" tag="CON TU VOZ">
      <div style={{position: 'absolute', left: 40, right: 40, top: 34, display: 'flex', flexDirection: 'column', gap: 22}}>
        {C.map((c, i) => {
          const a = at + i * 1.15;
          return (
            <div key={i}>
              <Pop at={a} style={{display: 'flex', gap: 14, alignItems: 'flex-start'}}>
                <Foto i={i ? 'g1' : 'g3'} style={{width: 48, height: 48, borderRadius: 24, flexShrink: 0}} />
                <div><div style={{fontFamily: SANS, fontWeight: 700, fontSize: 19, color: MUTED}}>{c.u}</div><div style={{fontFamily: SANS, fontWeight: 600, fontSize: 27, color: INK}}>{c.q}</div></div>
              </Pop>
              <Pop at={a + 0.35} style={{display: 'flex', gap: 14, alignItems: 'flex-start', marginLeft: 62, marginTop: 14}}>
                <Logo n="sala" size={44} />
                <div style={{background: GREEN_SOFT, border: `1.5px solid ${GREEN}`, borderRadius: 18, padding: '12px 18px'}}>
                  <div style={{fontFamily: SANS, fontWeight: 700, fontSize: 18, color: GREEN}}>tú · respuesta automática</div>
                  <div style={{fontFamily: SANS, fontWeight: 600, fontSize: 25, color: INK}}><Typed at={a + 0.45} cps={44} text={c.r} caret={false} /></div>
                </div>
              </Pop>
            </div>
          );
        })}
      </div>
    </Ventana>
  );
};

export const TodosLados: React.FC<{at: number}> = ({at}) => {
  const {t} = useT();
  return (
    <Ventana titulo="Esta semana · todos tus canales" logo="googlecalendar" tag="42 / 42">
      <div style={{position: 'absolute', left: 40, right: 40, top: 30}}>
        <div style={{display: 'grid', gridTemplateColumns: '70px repeat(7, 1fr)', gap: 10, alignItems: 'center'}}>
          <div />
          {DIAS.map((d) => <div key={d} style={{fontFamily: MONO, fontWeight: 700, fontSize: 17, color: MUTED, textAlign: 'center'}}>{d}</div>)}
          {CANALES.map((c, r) => (
            <React.Fragment key={r}>
              <Logo n={c[0]} size={44} />
              {DIAS.map((_, d) => {
                const on = t >= at + 0.1 + (d * 6 + r) * 0.035;
                return (
                  <div key={d} style={{height: 66, borderRadius: 14, background: on ? GREEN : '#F0F2EE', display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${on ? 1 : 0.9})`}}>
                    {on ? <Ico n="check" size={26} color="#fff" w={3} /> : null}
                  </div>
                );
              })}
            </React.Fragment>
          ))}
        </div>
      </div>
    </Ventana>
  );
};

export const Clientes: React.FC<{at: number; cli: number}> = ({at, cli}) => (
  <Ventana titulo="Tu marca · últimos 90 días" logo="googleanalytics">
    <div style={{position: 'absolute', left: 40, right: 40, top: 40, display: 'flex', flexDirection: 'column', gap: 24}}>
      <Pop at={at} style={{border: `1.5px solid ${LINE}`, borderRadius: 24, padding: '26px 32px', display: 'flex', alignItems: 'center', gap: 22}}>
        <Ico n="heart" size={54} color="#F472B6" />
        <div><div style={{fontFamily: MONO, fontSize: 17, fontWeight: 700, color: MUTED, letterSpacing: 1.5}}>SEGUIDORES</div>
          <div style={{fontFamily: SANS, fontWeight: 900, fontSize: 84, letterSpacing: -2}}><Count from={3200} to={12400} at={at + 0.2} dur={1.8} /></div></div>
      </Pop>
      <Pop at={cli - 0.3} style={{display: 'flex', justifyContent: 'center'}}><Ico n="down" size={56} color={GREEN} w={2.6} /></Pop>
      <Pop at={cli} style={{border: `2.5px solid ${GREEN}`, background: GREEN_SOFT, borderRadius: 24, padding: '26px 32px', display: 'flex', alignItems: 'center', gap: 22}}>
        <Ico n="dollar" size={54} color={GREEN} />
        <div><div style={{fontFamily: MONO, fontSize: 17, fontWeight: 700, color: GREEN, letterSpacing: 1.5}}>CLIENTES</div>
          <div style={{fontFamily: SANS, fontWeight: 900, fontSize: 84, letterSpacing: -2}}><Count from={4} to={38} at={cli + 0.1} dur={1.4} /></div></div>
      </Pop>
    </div>
  </Ventana>
);

// ====================== MÓDULO 3 ======================
const POSTS = [
  {n: 'Reel · agentes de IA', v: '48K', c: 9, s: '$2,340', best: true},
  {n: 'Carrusel · 5 errores', v: '22K', c: 3, s: '$780'},
  {n: 'Tutorial · Claude', v: '15K', c: 2, s: '$390'},
  {n: 'Historia · encuesta', v: '6K', c: 0, s: '$0'},
];
export const Misterio: React.FC<{at: number}> = ({at}) => {
  const {t} = useT();
  return (
    <Ventana titulo="Tus posts · últimos 30 días" logo="instagram">
      <div style={{position: 'absolute', left: 24, right: 24, top: 24, display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10}}>
        {['g1', 'kevin3', 'g0', 'g4', 'g3', 'g2', 'kevin27', 'g5', 'kevin14', 'g1', 'g0', 'kevin40'].map((im, i) => (
          <Pop key={i} at={at + i * 0.05}><Foto i={im} style={{height: 172, borderRadius: 14}}><div style={{position: 'absolute', left: 8, bottom: 6, fontFamily: MONO, fontSize: 13, fontWeight: 700, color: '#fff', textShadow: '0 1px 3px rgba(0,0,0,.6)'}}>▶ {(i * 7 + 3) % 40 + 2}K</div></Foto></Pop>
        ))}
      </div>
      <Pop at={at + 0.8} style={{position: 'absolute', left: 250, top: 220, width: 460, background: 'rgba(255,255,255,.92)', borderRadius: 26, boxShadow: '0 24px 50px -20px rgba(0,0,0,.5)', padding: '22px 26px', display: 'flex', alignItems: 'center', gap: 18}}>
        <div style={{width: 74, height: 74, borderRadius: 37, background: '#F59E0B', color: '#fff', fontFamily: SANS, fontWeight: 900, fontSize: 46, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${1 + 0.06 * Math.sin(t * 6)})`}}>?</div>
        <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 32, lineHeight: 1.05, color: INK}}>¿Cuál te dejó dinero?</div>
      </Pop>
    </Ventana>
  );
};

export const Tabla: React.FC<{at: number; best: number}> = ({at, best}) => {
  const {t} = useT();
  return (
    <Ventana titulo="Analítica · últimos 7 días" logo="googleanalytics" tag="CONECTADO A VENTAS">
      <div style={{position: 'absolute', left: 30, right: 30, top: 26}}>
        <div style={{display: 'grid', gridTemplateColumns: '1fr 110px 130px 140px', fontFamily: MONO, fontWeight: 700, fontSize: 16, color: MUTED, letterSpacing: 1.2, padding: '0 18px 12px'}}>
          <span>POST</span><span style={{textAlign: 'right'}}>VISTAS</span><span style={{textAlign: 'right'}}>LLAMADAS</span><span style={{textAlign: 'right'}}>VENTAS</span>
        </div>
        {POSTS.map((p, i) => {
          const hb = p.best && t >= best;
          return (
            <Pop key={i} at={at + 0.1 + i * 0.18} style={{display: 'grid', gridTemplateColumns: '1fr 110px 130px 140px', alignItems: 'center', padding: '18px', borderRadius: 18, marginBottom: 10, border: `2px solid ${hb ? GREEN : LINE}`, background: hb ? GREEN_SOFT : '#fff', fontFamily: SANS, fontSize: 24}}>
              <span style={{fontWeight: 700, display: 'flex', alignItems: 'center', gap: 10}}><Foto i={['kevin14', 'g1', 'g0', 'g4'][i]} style={{width: 40, height: 50, borderRadius: 8, flexShrink: 0}} />{p.n}{hb ? <span style={{fontFamily: MONO, fontSize: 14, background: GREEN, color: '#fff', borderRadius: 999, padding: '3px 10px'}}>GANADOR</span> : null}</span>
              <span style={{textAlign: 'right', color: MUTED}}>{p.v}</span>
              <span style={{textAlign: 'right', fontWeight: 700}}><Count from={0} to={p.c} at={at + 0.4 + i * 0.18} dur={0.8} /></span>
              <span style={{textAlign: 'right', fontWeight: 800, color: p.c ? GREEN : MUTED}}>{p.s}</span>
            </Pop>
          );
        })}
      </div>
    </Ventana>
  );
};

export const Alimenta: React.FC<{at: number}> = ({at}) => {
  const {t} = useT();
  const fly = lin(t, at + 0.3, at + 1.1);
  return (
    <Ventana titulo="Alimentador del loop · próxima semana" logo="claude">
      <Pop at={at} style={{position: 'absolute', left: 40, top: 40, width: 400, border: `2px solid ${GREEN}`, background: GREEN_SOFT, borderRadius: 20, padding: '18px 20px', display: 'flex', alignItems: 'center', gap: 14}}>
        <Foto i="kevin14" style={{width: 56, height: 70, borderRadius: 10}} />
        <div><div style={{fontFamily: MONO, fontSize: 14, fontWeight: 700, color: GREEN}}>GANADOR · 9 LLAMADAS · $2,340</div><div style={{fontFamily: SANS, fontWeight: 800, fontSize: 24}}>Reel · agentes de IA</div></div>
      </Pop>
      <svg style={{position: 'absolute', left: 0, top: 0}} width={960} height={598}>
        <path d="M440 90 C 640 90, 700 160, 700 240" stroke={GREEN} strokeWidth={4} fill="none" strokeDasharray="420" strokeDashoffset={420 * (1 - fly)} />
      </svg>
      <div style={{position: 'absolute', left: 40, right: 40, top: 260, border: `1.5px solid ${LINE}`, borderRadius: 22, padding: 22}}>
        <div style={{fontFamily: MONO, fontSize: 16, fontWeight: 700, color: MUTED, letterSpacing: 1.5}}>PRÓXIMA SEMANA · MÁS COMO ESTE</div>
        <div style={{display: 'flex', gap: 14, marginTop: 16}}>
          {['Reel · agentes para ventas', 'Reel · tu primer agente', 'Carrusel · 3 agentes gratis'].map((x, i) => (
            <Pop key={i} at={at + 1.1 + i * 0.25} style={{flex: 1, borderRadius: 16, border: `2px solid ${GREEN}`, padding: 14, height: 190, display: 'flex', flexDirection: 'column', justifyContent: 'space-between'}}>
              <Foto i={['kevin3', 'kevin27', 'kevin40'][i]} style={{width: 46, height: 58, borderRadius: 8}} />
              <div style={{fontFamily: SANS, fontWeight: 700, fontSize: 21, lineHeight: 1.15}}>{x}</div>
            </Pop>
          ))}
        </div>
      </div>
    </Ventana>
  );
};

export const Grafica: React.FC<{at: number}> = ({at}) => {
  const {t} = useT();
  const W = [{l: 'Sem 1', v: 1.2}, {l: 'Sem 2', v: 2.1}, {l: 'Sem 3', v: 3.4}, {l: 'Sem 4', v: 5.0}];
  return (
    <Ventana titulo="Ventas por semana" logo="stripe" tag="+317%">
      <div style={{position: 'absolute', left: 60, right: 60, top: 40, bottom: 50, display: 'flex', alignItems: 'flex-end', gap: 40}}>
        {W.map((w, i) => {
          const h = lin(t, at + 0.15 + i * 0.25, at + 0.9 + i * 0.25, 0, 1, Easing.out(Easing.cubic)) * (w.v / 5) * 400;
          return (
            <div key={i} style={{flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12}}>
              <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 30, opacity: h > 10 ? 1 : 0}}>${w.v.toFixed(1)}K</div>
              <div style={{width: '100%', height: h, borderRadius: 16, background: i === 3 ? GREEN : '#CFEFDD'}} />
              <div style={{fontFamily: MONO, fontWeight: 700, fontSize: 18, color: MUTED}}>{w.l}</div>
            </div>
          );
        })}
      </div>
    </Ventana>
  );
};

export const SinExcel: React.FC<{at: number}> = ({at}) => {
  const {t} = useT();
  const x = lin(t, at + 0.5, at + 0.9);
  return (
    <Ventana titulo="Reportes" logo="notion">
      <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 30}}>
        <Pop at={at} style={{position: 'relative'}}>
          <Logo n="excel" size={220} />
          <svg style={{position: 'absolute', left: -30, top: -30}} width={280} height={280}>
            <path d="M30 30 L 250 250" stroke={RED} strokeWidth={22} strokeLinecap="round" strokeDasharray="320" strokeDashoffset={320 * (1 - x)} />
          </svg>
        </Pop>
        <Pop at={at + 0.6} style={{fontFamily: SANS, fontWeight: 800, fontSize: 46, color: INK, letterSpacing: -1}}>Cero hojas de cálculo</Pop>
      </div>
    </Ventana>
  );
};
