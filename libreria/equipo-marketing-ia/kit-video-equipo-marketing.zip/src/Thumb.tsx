import React from 'react';
import {AbsoluteFill} from 'remotion';
import {SANS, MONO, INK, GREEN, Logo} from './base';
import {Diagrama} from './diagrama';

export const Thumb: React.FC = () => (
  <AbsoluteFill style={{background: '#fff'}}>
    <div style={{position: 'absolute', left: 540, top: 1300, width: 0, height: 0}}>
      <div style={{position: 'absolute', transform: 'scale(0.95) translate(-550px, -560px)', transformOrigin: '0 0'}}>
        <Diagrama b={-20} flash={-100} aprobar={9999} />
      </div>
    </div>
    <div style={{position: 'absolute', left: 0, right: 0, top: 0, height: 860, background: 'linear-gradient(180deg,#fff 78%,rgba(255,255,255,0))'}} />
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 420, background: 'linear-gradient(180deg,rgba(255,255,255,0),#fff 75%)'}} />
    <div style={{position: 'absolute', left: 0, right: 0, top: 290, textAlign: 'center'}}>
      <div style={{fontFamily: MONO, fontWeight: 700, fontSize: 30, letterSpacing: 4, color: '#6B7471'}}>MI EQUIPO DE MARKETING</div>
      <div style={{fontFamily: SANS, fontWeight: 900, fontSize: 150, lineHeight: 0.95, color: INK, letterSpacing: -5, marginTop: 18}}>1 persona.</div>
      <div style={{display: 'inline-block', marginTop: 18, fontFamily: SANS, fontWeight: 900, fontSize: 150, lineHeight: 1, color: '#fff', background: GREEN, borderRadius: 34, padding: '4px 34px 14px', letterSpacing: -5, transform: 'rotate(-2deg)'}}>36 agentes.</div>
    </div>
  </AbsoluteFill>
);
