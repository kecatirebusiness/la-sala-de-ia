import React from 'react';
import {interpolate, spring, useCurrentFrame, useVideoConfig, Easing, staticFile, Img} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Outfit';
import {loadFont as loadMono} from '@remotion/google-fonts/JetBrainsMono';

export const {fontFamily: SANS} = loadFont('normal', {weights: ['400', '500', '600', '700', '800', '900']});
export const {fontFamily: MONO} = loadMono('normal', {weights: ['400', '600', '700']});

export const INK = '#0E1411';
export const MUTED = '#6B7471';
export const LINE = '#D9DED8';
export const GREEN = '#00C26A';
export const GREEN_SOFT = '#E3F8EC';
export const BG = '#FFFFFF';
export const RED = '#F0454B';

export const useT = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return {t: f / fps, f, fps};
};

// 0→1 con resorte a partir de t0
export const sp = (t: number, t0: number, fps: number, cfg = {damping: 14, stiffness: 150, mass: 0.7}) =>
  spring({frame: Math.round((t - t0) * fps), fps, config: cfg});

export const lin = (t: number, a: number, b: number, from = 0, to = 1, ease = Easing.inOut(Easing.cubic)) =>
  interpolate(t, [a, b], [from, to], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: ease});

// aparece desde abajo con blur
export const Pop: React.FC<{at: number; children: React.ReactNode; style?: React.CSSProperties; dy?: number; out?: number}> = ({at, children, style, dy = 26, out}) => {
  const {t, fps} = useT();
  const s = sp(t, at, fps);
  const o = out !== undefined ? lin(t, out - 0.25, out, 1, 0) : 1;
  if (t < at - 0.02) return null;
  return (
    <div style={{opacity: Math.min(1, s * 1.4) * o, transform: `translateY(${(1 - s) * dy}px) scale(${0.94 + 0.06 * s})`, filter: `blur(${(1 - Math.min(1, s)) * 6}px)`, ...style}}>
      {children}
    </div>
  );
};

// texto que se escribe solo
export const Typed: React.FC<{text: string; at: number; cps?: number; style?: React.CSSProperties; caret?: boolean}> = ({text, at, cps = 38, style, caret = true}) => {
  const {t} = useT();
  const n = Math.max(0, Math.min(text.length, Math.floor((t - at) * cps)));
  const done = n >= text.length;
  const blink = Math.floor(t * 2.4) % 2 === 0;
  return (
    <span style={style}>
      {text.slice(0, n)}
      {caret && t >= at && (!done || blink) ? <span style={{display: 'inline-block', width: 3, height: '1em', background: GREEN, marginLeft: 2, verticalAlign: '-0.12em'}} /> : null}
    </span>
  );
};

// contador
export const Count: React.FC<{from: number; to: number; at: number; dur?: number; fmt?: (n: number) => string; style?: React.CSSProperties}> = ({from, to, at, dur = 1.2, fmt, style}) => {
  const {t} = useT();
  const v = interpolate(t, [at, at + dur], [from, to], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic)});
  return <span style={{fontVariantNumeric: 'tabular-nums', ...style}}>{fmt ? fmt(v) : Math.round(v).toLocaleString('en-US')}</span>;
};

// ---------- logos ----------
const SVG = ['claude', 'anthropic', 'elevenlabs', 'hubspot', 'notion', 'stripe', 'tiktok', 'instagram', 'youtube', 'gmail', 'googlecalendar', 'reddit', 'calendly', 'meta', 'whatsapp', 'facebook', 'googleanalytics', 'googledocs', 'x'];

export const Logo: React.FC<{n: string; size?: number; tile?: boolean; style?: React.CSSProperties}> = ({n, size = 44, tile = true, style}) => {
  const r = size * 0.26;
  const box: React.CSSProperties = {width: size, height: size, borderRadius: r, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, ...style};
  if (n === 'higgsfield')
    return <div style={{...box, background: '#0B0B0B', color: '#D7FF3A', fontFamily: SANS, fontWeight: 900, fontSize: size * 0.42, letterSpacing: -1}}>hf</div>;
  if (n === 'linkedin')
    return <div style={{...box, background: '#0A66C2', color: '#fff', fontFamily: SANS, fontWeight: 800, fontSize: size * 0.48}}>in</div>;
  if (n === 'excel')
    return <div style={{...box, background: '#1D6F42', color: '#fff', fontFamily: SANS, fontWeight: 900, fontSize: size * 0.5}}>X</div>;
  if (n === 'claudecode')
    return (
      <div style={{...box, background: '#141413', gap: 2}}>
        <Img src={staticFile('logos/claude.svg')} style={{width: size * 0.46, height: size * 0.46}} />
      </div>
    );
  if (n === 'trends')
    return (
      <div style={{...box, background: '#fff', border: `1px solid ${LINE}`}}>
        <svg width={size * 0.6} height={size * 0.6} viewBox="0 0 24 24" fill="none" stroke="#4285F4" strokeWidth={2.6} strokeLinecap="round" strokeLinejoin="round"><path d="M3 17l6-6 4 4 8-8" /></svg>
      </div>
    );
  if (n === 'sala')
    return (
      <div style={{...box, background: GREEN, borderRadius: size}}>
        <svg width={size * 0.62} height={size * 0.62} viewBox="0 0 24 24"><circle cx="8.5" cy="10" r="1.6" fill={INK} /><circle cx="15.5" cy="10" r="1.6" fill={INK} /><rect x="8" y="15" width="8" height="1.8" rx=".9" fill={INK} /></svg>
      </div>
    );
  if (!SVG.includes(n)) return <div style={{...box, background: '#eee'}} />;
  return (
    <div style={{...box, background: tile ? '#fff' : 'transparent', border: tile ? `1px solid ${LINE}` : 'none', boxShadow: tile ? '0 2px 6px rgba(0,0,0,.05)' : 'none'}}>
      <Img src={staticFile(`logos/${n}.svg`)} style={{width: size * 0.56, height: size * 0.56}} />
    </div>
  );
};

// íconos de trazo
export const Ico: React.FC<{n: string; size?: number; color?: string; w?: number}> = ({n, size = 28, color = INK, w = 2}) => {
  const p: Record<string, React.ReactNode> = {
    check: <path d="m5 12 5 5 9-10" />,
    arrow: <path d="M4 12h15m-5-6 6 6-6 6" />,
    down: <path d="M12 4v15m-6-5 6 6 6-6" />,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7" /></>,
    doc: <><path d="M6 3h8l4 4v14H6z" /><path d="M14 3v4h4M9 12h6M9 16h6" /></>,
    fire: <path d="M12 3c1 4 5 5 5 10a5 5 0 0 1-10 0c0-2 1-3.5 2-4.5 0 2 1 3 2 3 0-3-1-5 1-8.5z" />,
    up: <path d="M12 19V5m-6 6 6-6 6 6" />,
    comment: <path d="M4 5h16v11H9l-5 4z" />,
    send: <path d="M3 11 21 3l-8 18-2-8z" />,
    cal: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M3 10h18M8 3v4M16 3v4" /></>,
    sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>,
    phone: <path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z" />,
    dollar: <><path d="M12 2v20" /><path d="M17 6.5c-1-1.2-2.7-2-5-2-3 0-4.5 1.6-4.5 3.4 0 4.6 10 2.4 10 7.2 0 1.9-1.8 3.4-5 3.4-2.6 0-4.4-.9-5.5-2.3" /></>,
    loop: <><path d="M4 12a8 8 0 0 1 14-5.3L20 9" /><path d="M20 4v5h-5" /><path d="M20 12a8 8 0 0 1-14 5.3L4 15" /><path d="M4 20v-5h5" /></>,
    x: <path d="M6 6l12 12M18 6 6 18" />,
    terminal: <><rect x="3" y="4" width="18" height="16" rx="2" /><path d="m7 9 3 3-3 3M12 15h5" /></>,
    sliders: <><path d="M4 7h10M18 7h2M4 17h4M12 17h8" /><circle cx="16" cy="7" r="2" /><circle cx="10" cy="17" r="2" /></>,
    play: <path d="m9 7 8 5-8 5z" />,
    spark: <path d="M12 3c.6 4.2 2.8 6.4 7 7-4.2.6-6.4 2.8-7 7-.6-4.2-2.8-6.4-7-7 4.2-.6 6.4-2.8 7-7z" />,
    heart: <path d="M12 20s-7-4.5-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.5-7 10-7 10z" />,
    db: <><ellipse cx="12" cy="6" rx="7" ry="3" /><path d="M5 6v12c0 1.7 3.1 3 7 3s7-1.3 7-3V6" /><path d="M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3" /></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={w} strokeLinecap="round" strokeLinejoin="round">{p[n]}</svg>;
};

// cursor de mano/flecha
export const Cursor: React.FC<{x: number; y: number; press?: number}> = ({x, y, press = 0}) => (
  <div style={{position: 'absolute', left: x, top: y, transform: `scale(${1 - press * 0.15})`, transformOrigin: '0 0', filter: 'drop-shadow(0 6px 10px rgba(0,0,0,.25))', zIndex: 50}}>
    <svg width="46" height="46" viewBox="0 0 24 24"><path d="M5 3l14 8-6 1.5L10 19z" fill="#fff" stroke={INK} strokeWidth={1.6} strokeLinejoin="round" /></svg>
  </div>
);
