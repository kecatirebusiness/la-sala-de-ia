import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile, interpolate, Easing} from 'remotion';
import {SANS, MONO, INK, MUTED, LINE, GREEN, GREEN_SOFT, BG, RED, useT, sp, lin, Logo, Ico, Pop, Typed, Count, Cursor} from './base';
import {Diagrama, Fichas, MODS, MW, MH, DW} from './diagrama';
import * as P from './pantallas';
import WORDS from './words.json';

export const DUR = 95.4;

// ---------- escenas por tiempo (segundos de la voz) ----------
const S = {
  loop: 16.86, vuelta: 22.48, m1: 23.72, m2: 40.64, m3: 61.08, hub: 80.14, brief: 84.3, split: 88.16, cta: 91.08,
};

const Escena: React.FC<{a: number; b: number; children: React.ReactNode}> = ({a, b, children}) => {
  const {t} = useT();
  if (t < a - 0.05 || t > b + 0.4) return null;
  const i = lin(t, a, a + 0.4, 0, 1, Easing.out(Easing.cubic));
  const o = lin(t, b, b + 0.35);
  return <AbsoluteFill style={{opacity: i * (1 - o), transform: `scale(${0.96 + 0.04 * i + o * 0.05})`, filter: `blur(${(1 - i) * 10 + o * 10}px)`}}>{children}</AbsoluteFill>;
};

// ---------- cámara sobre el diagrama ----------
const card = (i: number, s = 2.6) => ({x: MODS[i].x + MW / 2, y: MODS[i].y + MH / 2, s});
const FULL = {x: 550, y: 650, s: 1.0};
const HOOK = {x: 550, y: 560, s: 0.9};
const KEYS: {t: number; x: number; y: number; s: number}[] = [
  {t: 0, ...HOOK, s: 0.8},
  {t: 3.6, ...HOOK},
  {t: 11.0, ...FULL},
  {t: 11.6, ...card(0)}, {t: 12.75, ...card(1)}, {t: 13.85, ...card(2)}, {t: 14.8, ...card(3)}, {t: 15.82, ...card(5)},
  {t: 16.8, x: 960, y: 760, s: 1.45},
  {t: 19.5, x: 790, y: 1200, s: 2.5},
  {t: 22.4, ...FULL},
  {t: 23.0, ...card(0, 3.4)},
  {t: 88.0, x: 300, y: 1380, s: 1.9},
  {t: 89.3, x: 795, y: 1225, s: 2.1},
  {t: 90.9, ...FULL, s: 0.95},
];
const cam = (t: number) => {
  let k = KEYS[0];
  for (let i = 1; i < KEYS.length; i++) {
    const a = KEYS[i - 1], b = KEYS[i];
    const p = interpolate(t, [b.t, b.t + 0.65], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)});
    if (t >= b.t) k = {t: b.t, x: a.x + (b.x - a.x) * p, y: a.y + (b.y - a.y) * p, s: a.s + (b.s - a.s) * p};
  }
  if (t < KEYS[1].t) {
    const p = lin(t, 0, 3.6);
    k = {t: 0, x: HOOK.x, y: HOOK.y, s: 0.8 + (HOOK.s - 0.8) * p};
  }
  return k;
};

const Vista: React.FC<{dim?: number}> = ({dim = 0}) => {
  const {t} = useT();
  const c = cam(t);
  const enFull = (t < 11.5) || (t > 22.3 && t < 23.0) || t > 90.9;
  const tit = enFull ? 1 : 0;
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 540, top: 960, width: 0, height: 0, opacity: 1 - dim * 0.88, filter: `blur(${dim * 3}px)`}}>
        <div style={{position: 'absolute', left: 0, top: 0, transform: `scale(${c.s}) translate(${-c.x}px, ${-c.y}px)`, transformOrigin: '0 0'}}>
          <Diagrama b={0.1} flash={8.3} aprobar={21.94} />
        </div>
      </div>
      {/* desvanecido abajo como el original */}
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 560, background: 'linear-gradient(180deg, rgba(255,255,255,0), rgba(255,255,255,.85) 55%, #fff)'}} />
      <div style={{position: 'absolute', left: 0, right: 0, top: 226, height: 70, background: '#fff', opacity: tit}} />
      <div style={{position: 'absolute', left: 0, right: 0, top: 232, textAlign: 'center', opacity: tit, fontFamily: SANS, fontWeight: 900, fontSize: 40, color: INK, letterSpacing: -0.8}}>
        EL EQUIPO DE MARKETING <span style={{color: GREEN}}>DE UNA PERSONA</span>
      </div>
      {t < 11.6 ? <div style={{position: 'absolute', inset: 0, opacity: 1 - lin(t, 10.9, 11.4)}}><Fichas at={3.7} emp={5.74} ag={8.28} /></div> : null}
    </AbsoluteFill>
  );
};

// ---------- módulos ----------
const M1 = () => (
  <AbsoluteFill>
    <P.Escenario at={S.m1} />
    <P.Cabecera num={1} titulo="Investigación y contenido" agentes={6} at={S.m1} />
    <P.Secuencia end={S.m2} items={[
      {at: S.m1 + 0.3, el: <P.Tendencias at={S.m1 + 0.5} />},
      {at: 29.2, el: <P.Audiencia at={29.3} />},
      {at: 31.5, el: <P.Escritor at={31.6} mail={33.1} />},
      {at: 34.0, el: <P.Calendario at={34.1} />},
      {at: 37.3, el: <P.Competencia at={37.4} />},
      {at: 39.25, el: <P.Bonito at={39.3} />},
    ]} />
    <P.Tarjeta at={S.m1} titulo="Investigación y contenido" agentes={MODS[0].agentes} cols={1} activos={[{at: 0, idx: [0]}, {at: 29.2, idx: [1]}, {at: 31.5, idx: [3]}, {at: 33.1, idx: [3, 4]}, {at: 34.0, idx: [5]}, {at: 37.3, idx: [2]}, {at: 39.25, idx: [3]}]} />
  </AbsoluteFill>
);
const M2 = () => (
  <AbsoluteFill>
    <P.Escenario at={S.m2} />
    <P.Cabecera num={2} titulo="Creativo y distribución" agentes={12} at={S.m2} />
    <P.Secuencia end={S.m3} items={[
      {at: 43.1, el: <P.Graficos at={43.2} />},
      {at: 45.9, el: <P.Voz at={46.0} />},
      {at: 47.7, el: <P.Aprobar at={47.7} click={48.32} />},
      {at: 49.0, el: <P.Publicar at={49.1} />},
      {at: 50.8, el: <P.Comentarios at={50.9} />},
      {at: 53.2, el: <P.TodosLados at={53.3} />},
      {at: 55.9, el: <P.Clientes at={56.0} cli={58.8} />},
    ]} />
    <PortadaModulo at={S.m2} hasta={43.1} titulo="Higgsfield + ElevenLabs" logos={['higgsfield', 'elevenlabs', 'instagram', 'tiktok', 'youtube']} />
    <P.Tarjeta at={S.m2} titulo="Creativo y distribución" agentes={[...MODS[1].agentes, ...MODS[2].agentes]} activos={[{at: 0, idx: []}, {at: 43.1, idx: [0, 1]}, {at: 45.9, idx: [2]}, {at: 47.7, idx: [5]}, {at: 49.0, idx: [6, 7, 8]}, {at: 50.8, idx: [9]}, {at: 53.2, idx: [10, 6]}, {at: 55.9, idx: []}]} />
  </AbsoluteFill>
);
const M3 = () => (
  <AbsoluteFill>
    <P.Escenario at={S.m3} />
    <P.Cabecera num={3} titulo="El loop de analítica" agentes={6} at={65.1} />
    <P.Secuencia end={S.hub} items={[
      {at: S.m3 + 0.1, el: <P.Misterio at={S.m3 + 0.2} />},
      {at: 67.6, el: <P.Tabla at={67.7} best={70.6} />},
      {at: 71.25, el: <P.Alimenta at={71.3} />},
      {at: 74.15, el: <P.Grafica at={74.2} />},
      {at: 78.0, el: <P.SinExcel at={78.06} />},
    ]} />
    <P.Tarjeta at={65.1} titulo="El loop de analítica" agentes={MODS[5].agentes} cols={1} activos={[{at: 0, idx: [0]}, {at: 67.6, idx: [0, 1, 2]}, {at: 71.25, idx: [4]}, {at: 74.15, idx: [2]}, {at: 78.0, idx: [5]}]} />
  </AbsoluteFill>
);

const PortadaModulo: React.FC<{at: number; hasta: number; titulo: string; logos: string[]}> = ({at, hasta, titulo, logos}) => {
  const {t, fps} = useT();
  if (t > hasta + 0.3) return null;
  const o = 1 - lin(t, hasta, hasta + 0.3);
  return (
    <div style={{position: 'absolute', left: 90, top: 306, width: 900, height: 700, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 34, opacity: o}}>
      <div style={{display: 'flex', gap: 20}}>
        {logos.map((l, i) => {
          const s = sp(t, at + 0.3 + i * 0.1, fps);
          return <div key={l} style={{opacity: s, transform: `translateY(${(1 - s) * 30}px) scale(${0.7 + 0.3 * s})`}}><Logo n={l} size={120} /></div>;
        })}
      </div>
      <Pop at={at + 0.8} style={{fontFamily: SANS, fontWeight: 800, fontSize: 40, color: MUTED}}>{titulo}</Pop>
    </div>
  );
};


// ---------- módulo 4: Claude Code ----------
const Conecta: React.FC = () => {
  const {t} = useT();
  const R = [
    {at: 82.3, l: ['hubspot'], n: 'Tu CRM', d: 'cada lead y cliente'},
    {at: 83.0, l: ['googlecalendar'], n: 'Tu calendario', d: 'llamadas y citas'},
    {at: 83.8, l: ['instagram', 'tiktok', 'youtube', 'linkedin'], n: 'Tus canales', d: '6 cuentas'},
  ];
  return (
    <P.Ventana titulo="Claude Code · ~/marketing" logo="claudecode" tag="CORRIENDO">
      <div style={{position: 'absolute', left: 26, right: 26, top: 22, height: 190, background: '#141413', borderRadius: 18, padding: '18px 22px', fontFamily: MONO, fontSize: 19, lineHeight: 1.55, color: '#C9D2CD'}}>
        <div style={{color: '#9FE8C4'}}>&gt; <Typed at={80.3} cps={34} text="claude code: corre el marketing" caret={false} /></div>
        <div><Typed at={81.2} cps={40} text="leyendo /voz /oferta /reglas" caret={false} /></div>
        <div><Typed at={82.0} cps={40} text="conectando CRM… calendario… canales…" caret={false} /></div>
        <div style={{color: '#FFC83D'}}><Typed at={83.9} cps={40} text="36 agentes listos" /></div>
      </div>
      <div style={{position: 'absolute', left: 26, right: 26, top: 232, display: 'flex', flexDirection: 'column', gap: 14}}>
        {R.map((r, i) => {
          const on = t >= r.at;
          return (
            <div key={i} style={{display: 'flex', alignItems: 'center', gap: 16, borderRadius: 18, padding: '16px 20px', border: `2px solid ${on ? '#C4B5FD' : LINE}`, background: on ? '#F7F5FF' : '#fff', opacity: on ? 1 : 0.45, transform: `scale(${on ? 1 : 0.98})`}}>
              <div style={{display: 'flex', gap: 6}}>{r.l.map((l) => <Logo key={l} n={l} size={44} />)}</div>
              <div>
                <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 26}}>{r.n}</div>
                <div style={{fontFamily: SANS, fontSize: 18, color: MUTED}}>{r.d}</div>
              </div>
              <div style={{marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6, fontFamily: SANS, fontWeight: 700, fontSize: 17, color: on ? '#fff' : MUTED, background: on ? GREEN : '#EEF0EC', borderRadius: 999, padding: '7px 14px'}}>{on ? <><Ico n="check" size={16} color="#fff" w={3} />Conectado</> : 'Esperando'}</div>
            </div>
          );
        })}
      </div>
    </P.Ventana>
  );
};
const Manana: React.FC = () => {
  const {t} = useT();
  const L = [
    {at: 86.2, k: '1 · Qué funcionó', v: ['“Agentes de IA” trajo 9 llamadas · $2,340', 'Mito vs. realidad le gana a los tips 3 a 1']},
    {at: 86.9, k: '2 · Qué está agendado', v: ['Sara M. · hoy 10:00 AM', 'Luis R. · hoy 4:30 PM']},
    {at: 87.65, k: '3 · Qué sigue', v: ['3 posts esperando tu aprobación', 'Repetir el formato ganador']},
  ];
  return (
    <P.Ventana titulo="Gmail · tu página de la mañana" logo="gmail">
      <div style={{position: 'absolute', left: 0, top: 0, bottom: 0, width: 170, background: '#FAFBF9', borderRight: `1.5px solid ${LINE}`, padding: '24px 18px', fontFamily: SANS, fontSize: 18, color: MUTED, lineHeight: 2.2}}>
        <div style={{color: INK, fontWeight: 800}}>Recibidos</div><div>Destacados</div><div>Enviados</div><div>Borradores</div>
      </div>
      <div style={{position: 'absolute', left: 196, right: 26, top: 22}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 12}}>
          <Logo n="sala" size={44} />
          <div><div style={{fontFamily: SANS, fontWeight: 900, fontSize: 28}}>Tu página de la mañana · jueves</div><div style={{fontFamily: MONO, fontSize: 15, color: MUTED}}>Claude Code · 7:00 AM</div></div>
        </div>
        <div style={{display: 'flex', gap: 12, marginTop: 16}}>
          {[['VISTAS', '212K'], ['LLAMADAS', '9'], ['VENTAS', '$4,200']].map(([k, v]) => (
            <div key={k} style={{flex: 1, border: `1.5px solid ${LINE}`, borderRadius: 14, padding: '10px 14px'}}>
              <div style={{fontFamily: MONO, fontSize: 13, fontWeight: 700, color: MUTED}}>{k}</div>
              <div style={{fontFamily: SANS, fontWeight: 900, fontSize: 30}}>{v}</div>
            </div>
          ))}
        </div>
        <div style={{display: 'flex', flexDirection: 'column', gap: 10, marginTop: 14}}>
          {L.map((l, i) => {
            const on = t >= l.at;
            return (
              <div key={i} style={{borderRadius: 14, padding: '10px 14px', border: `2px solid ${on ? '#C4B5FD' : 'transparent'}`, background: on ? '#F7F5FF' : 'transparent', opacity: on ? 1 : 0.35}}>
                <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 21}}>{l.k}</div>
                {l.v.map((x) => <div key={x} style={{fontFamily: SANS, fontSize: 18, color: '#3F4743'}}>• {x}</div>)}
              </div>
            );
          })}
        </div>
      </div>
    </P.Ventana>
  );
};
const M4: React.FC = () => (
  <AbsoluteFill>
    <P.Escenario at={S.hub} />
    <P.Cabecera num={4} titulo="Claude Code" agentes={36} at={S.hub} />
    <P.Secuencia end={S.split} items={[{at: S.hub + 0.1, el: <Conecta />}, {at: S.brief, el: <Manana />}]} />
    <P.Tarjeta at={S.hub} titulo="Equipo de Marketing" agentes={[{n: 'Investigación', l: 'trends'}, {n: 'Creativo', l: 'higgsfield'}, {n: 'Distribución', l: 'instagram'}, {n: 'Email', l: 'gmail'}, {n: 'Leads y citas', l: 'calendly'}, {n: 'Analítica', l: 'stripe'}]} activos={[{at: 0, idx: [0, 1, 2, 3, 4, 5]}]} />
  </AbsoluteFill>
);
// ---------- Claude Code conectado ----------
const Hub: React.FC = () => {
  const {t, fps} = useT();
  const a = S.hub;
  const nodos = [
    {at: 82.3, x: 200, y: 900, l: ['hubspot'], n: 'Tu CRM'},
    {at: 83.0, x: 880, y: 900, l: ['googlecalendar'], n: 'Tu calendario'},
    {at: 83.8, x: 540, y: 1180, l: ['instagram', 'tiktok', 'youtube'], n: 'Tus canales'},
  ];
  const cx = 540, cy = 640;
  return (
    <AbsoluteFill>
      <Pop at={a} style={{position: 'absolute', left: 0, right: 0, top: 236, textAlign: 'center', fontFamily: SANS, fontWeight: 900, fontSize: 52, color: INK, letterSpacing: -1.2}}>
        Claude Code lo corre <span style={{color: GREEN}}>todo</span>
      </Pop>
      <svg style={{position: 'absolute', left: 0, top: 0}} width={1080} height={1400}>
        {nodos.map((n, i) => {
          const d = lin(t, n.at - 0.15, n.at + 0.3);
          return <path key={i} d={`M${cx} ${cy + 120} L ${n.x} ${n.y - 70}`} stroke={GREEN} strokeWidth={4} strokeDasharray="8 10" strokeDashoffset={-t * 40} opacity={d} />;
        })}
      </svg>
      <Pop at={a + 0.2} style={{position: 'absolute', left: cx - 260, top: cy - 150, width: 520, height: 290, background: '#141413', borderRadius: 30, boxShadow: '0 30px 60px -24px rgba(0,0,0,.6)', padding: 28}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 12}}>
          <Logo n="claudecode" size={52} />
          <span style={{fontFamily: SANS, fontWeight: 800, fontSize: 32, color: '#fff'}}>Claude Code</span>
        </div>
        <div style={{fontFamily: MONO, fontSize: 21, color: '#9FE8C4', marginTop: 22, lineHeight: 1.6}}>
          <div>&gt; <Typed at={a + 0.5} cps={30} text="corriendo 36 agentes" caret={false} /></div>
          <div style={{color: '#8C978F'}}>&gt; <Typed at={a + 1.3} cps={30} text="post #214 programado" caret={false} /></div>
          <div style={{color: '#8C978F'}}>&gt; <Typed at={a + 2.0} cps={30} text="3 leads nuevos" /></div>
        </div>
      </Pop>
      {nodos.map((n, i) => {
        const s = sp(t, n.at, fps);
        if (t < n.at) return null;
        return (
          <div key={i} style={{position: 'absolute', left: n.x - 150, top: n.y - 70, width: 300, height: 140, background: '#fff', border: `1.5px solid ${LINE}`, borderRadius: 26, boxShadow: '0 16px 34px -20px rgba(0,0,0,.4)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10, opacity: s, transform: `scale(${0.8 + 0.2 * s})`}}>
            <div style={{display: 'flex', gap: 8}}>{n.l.map((l) => <Logo key={l} n={l} size={48} />)}</div>
            <span style={{fontFamily: SANS, fontWeight: 800, fontSize: 27}}>{n.n}</span>
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

const Resumen: React.FC = () => {
  const a = S.brief;
  const L = [
    {at: 86.2, k: 'Qué funcionó', v: 'Reel “agentes de IA” → 6 llamadas', c: GREEN},
    {at: 86.9, k: 'Qué está agendado', v: '4 llamadas hoy · 2 demos mañana', c: '#7C6CFF'},
    {at: 87.65, k: 'Qué sigue', v: '3 posts listos para aprobar', c: '#F59E0B'},
  ];
  return (
    <AbsoluteFill>
      <Pop at={a} style={{position: 'absolute', left: 0, right: 0, top: 236, textAlign: 'center', fontFamily: SANS, fontWeight: 900, fontSize: 52, color: INK, letterSpacing: -1.2}}>
        Cada mañana, <span style={{color: GREEN}}>una página</span>
      </Pop>
      <Pop at={a + 0.25} style={{position: 'absolute', left: 120, right: 120, top: 360, height: 860, background: '#fff', borderRadius: 30, boxShadow: '0 40px 70px -34px rgba(0,0,0,.5), 0 0 0 1.5px rgba(14,20,17,.06)', padding: 46}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 14}}>
          <Ico n="sun" size={44} color="#F59E0B" />
          <div>
            <div style={{fontFamily: SANS, fontWeight: 900, fontSize: 40, letterSpacing: -1}}>Tu resumen</div>
            <div style={{fontFamily: MONO, fontSize: 18, color: MUTED}}>jueves · 7:00 AM</div>
          </div>
        </div>
        <div style={{height: 1.5, background: LINE, margin: '30px 0'}} />
        {L.map((l, i) => (
          <Pop key={i} at={l.at} style={{display: 'flex', gap: 18, marginBottom: 34}}>
            <div style={{width: 8, borderRadius: 4, background: l.c}} />
            <div>
              <div style={{fontFamily: MONO, fontSize: 18, fontWeight: 700, color: l.c, letterSpacing: 1.4, textTransform: 'uppercase'}}>{l.k}</div>
              <div style={{fontFamily: SANS, fontWeight: 700, fontSize: 32, marginTop: 6, lineHeight: 1.2}}>{l.v}</div>
            </div>
          </Pop>
        ))}
      </Pop>
    </AbsoluteFill>
  );
};

const Division: React.FC = () => {
  const {t} = useT();
  const a = S.split;
  return (
    <AbsoluteFill>
      <Pop at={a} style={{position: 'absolute', left: 80, right: 80, top: 260, height: 440, background: INK, borderRadius: 34, padding: 40, overflow: 'hidden'}}>
        <div style={{fontFamily: MONO, fontSize: 20, fontWeight: 700, color: GREEN, letterSpacing: 2}}>LA IA</div>
        <div style={{fontFamily: SANS, fontWeight: 900, fontSize: 64, color: '#fff', letterSpacing: -1.5, lineHeight: 1}}>mueve la<br />información</div>
        {Array.from({length: 14}).map((_, i) => {
          const x = ((t - a) * 260 + i * 70) % 920;
          return <div key={i} style={{position: 'absolute', left: x, top: 330 + (i % 3) * 30, width: 40, height: 14, borderRadius: 7, background: i % 3 === 0 ? GREEN : '#33413A'}} />;
        })}
      </Pop>
      <Pop at={89.42} style={{position: 'absolute', left: 80, right: 80, top: 740, height: 440, background: '#fff', border: `2.5px solid ${GREEN}`, borderRadius: 34, padding: 40}}>
        <div style={{fontFamily: MONO, fontSize: 20, fontWeight: 700, color: GREEN, letterSpacing: 2}}>TÚ</div>
        <div style={{fontFamily: SANS, fontWeight: 900, fontSize: 64, color: INK, letterSpacing: -1.5, lineHeight: 1}}>mueves la marca<br />y el presupuesto</div>
        <div style={{position: 'absolute', left: 40, right: 40, bottom: 44, display: 'flex', gap: 30}}>
          {['Marca', 'Presupuesto'].map((k, i) => {
            const v = 0.3 + 0.5 * lin(t, 89.9 + i * 0.3, 90.8 + i * 0.3);
            return (
              <div key={k} style={{flex: 1}}>
                <div style={{fontFamily: MONO, fontSize: 16, color: MUTED, fontWeight: 700}}>{k.toUpperCase()}</div>
                <div style={{height: 12, background: '#EEF0EC', borderRadius: 6, marginTop: 10, position: 'relative'}}>
                  <div style={{width: `${v * 100}%`, height: 12, background: GREEN, borderRadius: 6}} />
                  <div style={{position: 'absolute', left: `calc(${v * 100}% - 14px)`, top: -8, width: 28, height: 28, borderRadius: 14, background: '#fff', border: `3px solid ${GREEN}`}} />
                </div>
              </div>
            );
          })}
        </div>
      </Pop>
    </AbsoluteFill>
  );
};

const CTA: React.FC = () => {
  const {t} = useT();
  const a = S.cta;
  const send = 92.1;
  return (
    <AbsoluteFill>
      <Pop at={a} style={{position: 'absolute', left: 0, right: 0, top: 300, textAlign: 'center'}}>
        <div style={{fontFamily: SANS, fontWeight: 900, fontSize: 62, color: INK, letterSpacing: -1.5}}>Comenta</div>
        <div style={{display: 'inline-block', marginTop: 10, fontFamily: SANS, fontWeight: 900, fontSize: 110, color: '#fff', background: GREEN, borderRadius: 28, padding: '6px 40px', letterSpacing: -2, transform: `rotate(-2deg) scale(${1 + 0.03 * Math.sin(t * 6)})`}}>MARKETING</div>
      </Pop>
      <Pop at={a + 0.3} style={{position: 'absolute', left: 110, right: 110, top: 640, background: '#fff', borderRadius: 999, boxShadow: '0 20px 40px -20px rgba(0,0,0,.4), 0 0 0 1.5px rgba(14,20,17,.08)', padding: '22px 30px', display: 'flex', alignItems: 'center', gap: 16}}>
        <Logo n="sala" size={50} />
        <div style={{flex: 1, fontFamily: SANS, fontWeight: 700, fontSize: 34, color: INK}}><Typed at={a + 0.4} cps={16} text="MARKETING" /></div>
        <div style={{width: 58, height: 58, borderRadius: 29, background: t >= send ? GREEN : '#E6E9E4', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Ico n="send" size={28} color={t >= send ? '#fff' : MUTED} /></div>
      </Pop>
      <Pop at={92.4} style={{position: 'absolute', left: 170, right: 170, top: 800, background: '#fff', border: `1.5px solid ${LINE}`, borderRadius: 30, padding: 30, display: 'flex', alignItems: 'center', gap: 22, boxShadow: '0 24px 50px -28px rgba(0,0,0,.45)'}}>
        <div style={{width: 100, height: 126, borderRadius: 14, background: INK, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Ico n="doc" size={56} color={GREEN} /></div>
        <div>
          <div style={{fontFamily: MONO, fontSize: 17, fontWeight: 700, color: GREEN, letterSpacing: 1.5}}>TE LLEGA POR DM</div>
          <div style={{fontFamily: SANS, fontWeight: 900, fontSize: 40, lineHeight: 1.05, letterSpacing: -1}}>El blueprint completo</div>
          <div style={{display: 'inline-block', marginTop: 10, fontFamily: SANS, fontWeight: 800, fontSize: 22, color: '#fff', background: INK, borderRadius: 999, padding: '5px 16px', opacity: lin(t, 93.8, 94.1)}}>GRATIS</div>
        </div>
      </Pop>
    </AbsoluteFill>
  );
};

// ---------- subtítulos ----------
type W = {w: string; s: number; e: number};
const ARR: W[] = (WORDS as W[]).map((x) => ({...x, w: x.w === 'guía' ? 'IA' : x.w === 'marketing' && x.s > 90 ? 'MARKETING' : x.w}));
const CHUNKS: W[][] = (() => {
  const out: W[][] = [];
  let cur: W[] = [];
  for (const w of ARR) {
    cur.push(w);
    const len = cur.reduce((a, b) => a + b.w.length, 0);
    if (/[.,:?!]$/.test(w.w) || cur.length >= 3 || len > 16) { out.push(cur); cur = []; }
  }
  if (cur.length) out.push(cur);
  return out;
})();
const Subs: React.FC = () => {
  const {t} = useT();
  const i = CHUNKS.findIndex((c, k) => t >= c[0].s - 0.05 && t < (k < CHUNKS.length - 1 ? CHUNKS[k + 1][0].s - 0.05 : c[c.length - 1].e + 0.6));
  if (i < 0) return null;
  const c = CHUNKS[i];
  const s = lin(t, c[0].s - 0.05, c[0].s + 0.08);
  return (
    <div style={{position: 'absolute', left: 50, right: 50, top: 1338, textAlign: 'center', transform: `scale(${0.9 + 0.1 * s})`, opacity: s}}>
      {c.map((w, k) => {
        const on = t >= w.s - 0.03;
        return (
          <span key={k} style={{fontFamily: SANS, fontWeight: 900, fontSize: 58, letterSpacing: -1, color: on ? '#fff' : 'rgba(255,255,255,.55)', WebkitTextStroke: `12px ${INK}`, paintOrder: 'stroke fill', margin: '0 9px', display: 'inline-block'}}>
            {w.w.replace(/[.,:]$/, '')}
          </span>
        );
      })}
    </div>
  );
};

// ---------- efectos de sonido (SND Sine) ----------
const sfx: [number, string, number][] = [];
const add = (t: number, f: string, v = 0.32) => sfx.push([t, f, v]);
// construcción del diagrama
for (let i = 0; i < 7; i++) add(0.25 + i * 0.09, `tap_0${(i % 5) + 1}`, 0.18);
add(1.45, 'transition_up', 0.3);
for (let i = 0; i < 6; i++) add(2.05 + i * 0.13, `tap_0${(i % 5) + 1}`, 0.2);
add(3.5, 'swipe_02', 0.22);
add(3.8, 'select', 0.3); add(5.74, 'notification', 0.28); add(8.28, 'notification', 0.3);
[11.6, 12.75, 13.85, 14.8, 15.82, 16.6].forEach((x, i) => add(x, `swipe_0${(i % 5) + 1}`, 0.3));
add(16.8, 'swipe_05', 0.3); add(19.5, 'swipe_03', 0.3); add(19.6, 'notification', 0.2); add(21.94, 'button', 0.4); add(21.98, 'toggle_on', 0.3);
add(22.4, 'transition_down', 0.3); add(23.15, 'swipe_04', 0.3);
// módulo 1
add(23.72, 'transition_up', 0.32); add(26.0, 'notification', 0.26);
[29.2, 31.5, 34.0, 37.3, 39.25].forEach((x) => add(x, 'swipe_01', 0.26));
for (let k = 0; k < 7; k++) add(31.8 + k * 0.32, `type_0${(k % 5) + 1}`, 0.14);
for (let k = 0; k < 4; k++) add(33.3 + k * 0.25, `type_0${(k % 5) + 1}`, 0.12);
for (let k = 0; k < 7; k++) add(34.25 + k * 0.22, `tap_0${(k % 5) + 1}`, 0.16);
add(38.0, 'select', 0.26); add(39.9, 'notification', 0.24);
// módulo 2
add(40.64, 'transition_up', 0.32);
[43.1, 45.9, 47.7, 49.0, 50.8, 53.2, 55.9].forEach((x) => add(x, 'swipe_02', 0.26));
add(44.6, 'select', 0.22); add(48.32, 'button', 0.42); add(48.36, 'toggle_on', 0.3);
for (let k = 0; k < 6; k++) add(49.35 + k * 0.22, `tap_0${(k % 5) + 1}`, 0.2);
add(51.25, 'notification', 0.22); add(52.4, 'notification', 0.22);
for (let k = 0; k < 6; k++) add(53.4 + k * 0.25, `tap_0${(k % 5) + 1}`, 0.14);
add(58.8, 'celebration', 0.22);
// módulo 3
add(61.08, 'transition_up', 0.32); add(65.1, 'select', 0.26);
[67.6, 71.25, 74.15, 78.0].forEach((x) => add(x, 'swipe_03', 0.26));
add(70.6, 'notification', 0.28); add(72.4, 'tap_02', 0.2); add(72.65, 'tap_03', 0.2); add(72.9, 'tap_04', 0.2);
add(75.2, 'select', 0.2); add(78.6, 'caution', 0.24);
// final
add(80.14, 'transition_up', 0.32); add(82.3, 'tap_01', 0.25); add(83.0, 'tap_02', 0.25); add(83.8, 'tap_03', 0.25);
add(82.3, 'toggle_on', 0.2); add(83.0, 'toggle_on', 0.2); add(83.8, 'toggle_on', 0.2); add(84.3, 'swipe_04', 0.3); add(86.2, 'select', 0.22); add(86.9, 'select', 0.22); add(87.65, 'select', 0.22);
add(88.0, 'transition_down', 0.3); add(89.3, 'swipe_02', 0.28); add(90.9, 'swipe_04', 0.26);
add(91.08, 'transition_up', 0.32); for (let k = 0; k < 9; k++) add(91.5 + k * 0.0625, `type_0${(k % 5) + 1}`, 0.12);
add(92.1, 'button', 0.36); add(92.4, 'notification', 0.3); add(93.8, 'celebration', 0.3);

export const Replica: React.FC = () => {
  const {t, fps} = useT();
  return (
    <AbsoluteFill style={{background: BG, fontFamily: SANS}}>
      {/* fondo con puntos */}

      <Escena a={0} b={S.m1}><Vista /></Escena>
      <Escena a={S.m1} b={S.m2}><M1 /></Escena>
      <Escena a={S.m2} b={S.m3}><M2 /></Escena>
      <Escena a={S.m3} b={S.hub}><M3 /></Escena>
      <Escena a={S.hub} b={S.split}><M4 /></Escena>
      <Escena a={S.split} b={DUR + 1}><Vista dim={lin(t, S.cta, S.cta + 0.5)} /></Escena>
      {t >= S.cta - 0.05 ? <CTA /> : null}

      {/* marca */}
      <div style={{position: 'absolute', right: 56, top: 160, display: 'flex', alignItems: 'center', gap: 8, background: 'rgba(255,255,255,.92)', borderRadius: 999, padding: '6px 14px 6px 8px', boxShadow: '0 4px 14px -8px rgba(0,0,0,.3)'}}>
        <Logo n="sala" size={30} />
        <span style={{fontFamily: SANS, fontWeight: 700, fontSize: 21, color: INK}}>La Sala <span style={{fontStyle: 'italic', color: GREEN}}>de IA</span></span>
      </div>

      <Subs />

      <Audio src={staticFile('vo.wav')} />
      {sfx.map(([at, f, v], i) => (
        <Sequence key={i} from={Math.round(at * fps)} durationInFrames={Math.round(3 * fps)} layout="none">
          <Audio src={staticFile(`snd/${f}.wav`)} volume={v} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
