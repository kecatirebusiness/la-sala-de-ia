import React from 'react';
import {Composition} from 'remotion';
import {Replica, DUR} from './Replica';
import {Thumb} from './Thumb';
import {Mapa} from './Mapa';
export const Root: React.FC = () => <><Composition id="Mapa" component={Mapa} durationInFrames={1} fps={30} width={1310} height={1720} /><Composition id="Thumb" component={Thumb} durationInFrames={1} fps={30} width={1080} height={1920} /><Composition id="Replica" component={Replica} durationInFrames={Math.round(DUR * 30)} fps={30} width={1080} height={1920} /></>;
