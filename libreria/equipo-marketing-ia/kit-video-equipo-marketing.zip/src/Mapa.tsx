import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Diagrama} from './diagrama';
export const Mapa: React.FC = () => (
  <AbsoluteFill style={{background: '#fff'}}>
    <div style={{position: 'absolute', left: 70, top: 20}}><Diagrama b={-20} flash={-100} aprobar={9999} /></div>
  </AbsoluteFill>
);
