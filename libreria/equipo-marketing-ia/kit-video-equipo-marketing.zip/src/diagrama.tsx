import React from 'react';
import {interpolate, Easing, Img, staticFile} from 'remotion';
import {SANS, MONO, INK, MUTED, LINE, GREEN, GREEN_SOFT, useT, sp, lin, Logo, Ico, Count, Cursor} from './base';

export const PURPLE = '#8B7CF6';
export const ORANGE = '#F59E0B';

export type Agente = {n: string; l: string};
// 6 módulos × 6 agentes = 36
export const MODS: {id: string; titulo: string; x: number; y: number; agentes: Agente[]}[] = [
  {id: 'inv', titulo: 'Investigación\ny contenido', x: 70, y: 440, agentes: [
    {n: 'Detector de tendencias', l: 'trends'}, {n: 'Investigador de audiencia', l: 'reddit'}, {n: 'Buscador de keywords', l: 'googleanalytics'},
    {n: 'Escritor de posts', l: 'notion'}, {n: 'Escritor de emails', l: 'gmail'}, {n: 'Planificador', l: 'notion'}]},
  {id: 'cre', titulo: 'Estudio\ncreativo', x: 400, y: 440, agentes: [
    {n: 'Hacedor de videos', l: 'higgsfield'}, {n: 'Diseñador gráfico', l: 'higgsfield'}, {n: 'Voz', l: 'elevenlabs'},
    {n: 'Editor', l: 'claudecode'}, {n: 'Miniaturas', l: 'higgsfield'}, {n: 'Mesa de aprobación', l: 'whatsapp'}]},
  {id: 'dis', titulo: 'Distribución\ny comunidad', x: 730, y: 440, agentes: [
    {n: 'Programador', l: 'meta'}, {n: 'Posteo corto', l: 'tiktok'}, {n: 'Posteo largo', l: 'youtube'},
    {n: 'Comentarios y DMs', l: 'instagram'}, {n: 'Republicador', l: 'linkedin'}, {n: 'Escalamiento', l: 'whatsapp'}]},
  {id: 'ema', titulo: 'Email\ny nurture', x: 70, y: 800, agentes: [
    {n: 'Newsletter', l: 'gmail'}, {n: 'Secuencias', l: 'hubspot'}, {n: 'Lead magnet', l: 'googledocs'},
    {n: 'Segmentador', l: 'hubspot'}, {n: 'Asuntos', l: 'claude'}, {n: 'Recuperación', l: 'gmail'}]},
  {id: 'lea', titulo: 'Leads\ny citas', x: 400, y: 800, agentes: [
    {n: 'Captura de leads', l: 'hubspot'}, {n: 'Calificador', l: 'claude'}, {n: 'Agenda llamadas', l: 'calendly'},
    {n: 'Recordatorios', l: 'googlecalendar'}, {n: 'Seguimiento', l: 'whatsapp'}, {n: 'Link de pago', l: 'stripe'}]},
  {id: 'ana', titulo: 'El loop de\nanalítica', x: 730, y: 800, agentes: [
    {n: 'Analista de posts', l: 'googleanalytics'}, {n: 'Rastreador de llamadas', l: 'calendly'}, {n: 'Rastreador de ventas', l: 'stripe'},
    {n: 'Analista de email', l: 'gmail'}, {n: 'Alimentador del loop', l: 'claude'}, {n: 'Reporte matutino', l: 'notion'}]},
];
export const MW = 300, MH = 330;
export const DW = 1100, DH = 1680;

const CANALES = ['tiktok', 'youtube', 'instagram', 'linkedin', 'trends', 'reddit', 'meta', 'x', 'stripe'];

const Caja: React.FC<{x: number; y: number; w: number; h: number; at: number; dark?: boolean; children: React.ReactNode; style?: React.CSSProperties}> = ({x, y, w, h, at, dark, children, style}) => {
  const {t, fps} = useT();
  const s = sp(t, at, fps);
  if (t < at - 0.02) return null;
  return (
    <div style={{position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: 18, background: dark ? '#111413' : '#fff', border: dark ? 'none' : `1.5px solid ${LINE}`, boxShadow: '0 10px 26px -18px rgba(14,20,17,.35)', padding: '12px 14px', opacity: Math.min(1, s * 1.4), transform: `translateY(${(1 - s) * 18}px) scale(${0.94 + 0.06 * s})`, ...style}}>
      {children}
    </div>
  );
};
const Etq: React.FC<{c?: string; children: React.ReactNode}> = ({c = MUTED, children}) => <div style={{fontFamily: MONO, fontWeight: 700, fontSize: 11.5, letterSpacing: 1.3, color: c, textTransform: 'uppercase', marginBottom: 8}}>{children}</div>;

const ModCard: React.FC<{m: typeof MODS[0]; idx: number; at: number; flash: number}> = ({m, idx, at, flash}) => {
  const {t, fps} = useT();
  const s = sp(t, at, fps);
  if (t < at - 0.02) return null;
  return (
    <div style={{position: 'absolute', left: m.x, top: m.y, width: MW, height: MH, background: '#fff', borderRadius: 20, border: `1.5px solid ${LINE}`, boxShadow: '0 14px 30px -20px rgba(14,20,17,.4)', padding: '16px 16px', opacity: Math.min(1, s * 1.4), transform: `translateY(${(1 - s) * 26}px) scale(${0.92 + 0.08 * s})`}}>
      <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start'}}>
        <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 25, lineHeight: 1.0, color: INK, whiteSpace: 'pre-line', letterSpacing: -0.5}}>{m.titulo}</div>
        <div style={{fontFamily: MONO, fontSize: 11.5, color: MUTED, marginTop: 4}}>6 agentes</div>
      </div>
      <div style={{marginTop: 12, display: 'flex', flexDirection: 'column', gap: 2}}>
        {m.agentes.map((a, k) => {
          const d = flash + (idx * 6 + k) * 0.028;
          const on = lin(t, d, d + 0.1) * (1 - lin(t, flash + 1.7, flash + 2.3));
          const r = sp(t, at + 0.2 + k * 0.05, fps);
          return (
            <div key={k} style={{display: 'flex', alignItems: 'center', gap: 7, height: 37, opacity: r, borderBottom: k < 5 ? '1px solid #F0F2EF' : 'none', background: on > 0 ? `rgba(0,194,106,${0.14 * on})` : 'transparent', borderRadius: 8, padding: '0 4px', margin: '0 -4px'}}>
              <Logo n={a.l} size={23} />
              <Logo n="claude" size={23} tile={false} style={{marginLeft: -2}} />
              <span style={{fontFamily: SANS, fontWeight: 500, fontSize: 15.5, color: INK, whiteSpace: 'nowrap'}}>{a.n}</span>
              {on > 0.5 ? <span style={{marginLeft: 'auto'}}><Ico n="check" size={16} color={GREEN} w={3} /></span> : null}
            </div>
          );
        })}
      </div>
    </div>
  );
};

const Nodo: React.FC<{x: number; y: number; c?: string; o?: number}> = ({x, y, c = INK, o = 1}) => <circle cx={x} cy={y} r={6} fill="#fff" stroke={c} strokeWidth={2.5} opacity={o} />;

// diagrama completo (lienzo 1100 × 1680)
export const Diagrama: React.FC<{b: number; flash: number; aprobar: number}> = ({b, flash, aprobar}) => {
  const {t, fps} = useT();
  const L = (a: number, d = 0.6) => lin(t, b + a, b + a + d);
  const dash = (len: number, p: number) => ({strokeDasharray: `${len}`, strokeDashoffset: len * (1 - p)});
  const ok = t >= aprobar;
  const press = t > aprobar - 0.05 && t < aprobar + 0.12 ? 1 : 0;
  const loopP = ((t * 0.35) % 1);
  return (
    <div style={{position: 'absolute', left: 0, top: 0, width: DW, height: DH}}>
      {/* --- conexiones --- */}
      <svg style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}} width={DW} height={DH}>
        {/* canales → cajas */}
        <path d="M550 66 V 84 M 200 84 H 865 M 200 84 V 100 M 515 84 V 100 M 865 84 V 100" stroke={INK} strokeWidth={2} fill="none" {...dash(1200, L(0.5))} />
        {/* cajas → orquestador */}
        <path d="M200 214 V 232 H 550 V 250 M 515 214 V 232 M 865 214 V 232 H 550" stroke={INK} strokeWidth={2} fill="none" {...dash(1200, L(0.8))} />
        {/* orquestador → módulos */}
        <path d="M550 372 V 408 M 220 408 H 880 M 220 408 V 440 M 550 408 V 440 M 880 408 V 440 M 220 770 V 800 M 550 770 V 800 M 880 770 V 800" stroke={INK} strokeWidth={2.4} fill="none" {...dash(1600, L(1.1))} />
        {[220, 550, 880].map((x) => <Nodo key={x} x={x} y={408} o={L(1.3)} />)}
        {/* lateral morado (sistema de registro → leads) */}
        <path d="M40 160 H 26 V 1240 H 70" stroke={PURPLE} strokeWidth={2.4} strokeDasharray="7 7" fill="none" opacity={L(1.6)} />
        {[300, 620, 980].map((y) => <Nodo key={y} x={26} y={y} c={PURPLE} o={L(1.7)} />)}
        {/* lateral naranja (conocimiento → handoff) — el loop */}
        <path d="M1060 160 H 1076 V 1150 H 1030" stroke={ORANGE} strokeWidth={2.6} fill="none" opacity={L(1.6)} />
        {[300, 620, 980].map((y) => <Nodo key={y} x={1076} y={y} c={ORANGE} o={L(1.7)} />)}
        {/* loop: analítica → vuelve arriba al orquestador */}
        <path id="loopPath" d="M880 1130 V 1150 H 1040 Q 1056 1150 1056 1134 V 330 Q 1056 312 1040 312 H 772" stroke={ORANGE} strokeWidth={4} fill="none" opacity={L(1.9)} />
        <circle r={9} fill={ORANGE} opacity={L(2)} style={{offsetPath: `path('M880 1130 V 1150 H 1040 Q 1056 1150 1056 1134 V 330 Q 1056 312 1040 312 H 772')`, offsetDistance: `${loopP * 100}%`} as React.CSSProperties} />
        {/* módulos → abajo */}
        <path d="M220 1130 V 1170 M 795 1130 V 1170" stroke={INK} strokeWidth={2} fill="none" opacity={L(2.4)} />
        <path d="M290 1300 V 1330 M 795 1300 V 1330" stroke={INK} strokeWidth={2} fill="none" opacity={L(2.6)} />
      </svg>

      {/* canales arriba */}
      <Caja x={150} y={0} w={800} h={66} at={b + 0.05} style={{display: 'flex', alignItems: 'center', justifyContent: 'space-around', padding: '0 18px', borderRadius: 20}}>
        {CANALES.map((n, i) => <div key={n} style={{opacity: sp(t, b + 0.1 + i * 0.05, fps)}}><Logo n={n} size={40} /></div>)}
      </Caja>
      {/* fila de cajas */}
      <Caja x={40} y={100} w={320} h={114} at={b + 0.35}>
        <Etq>Sistema de registro</Etq>
        <div style={{display: 'flex', gap: 8}}>{['hubspot', 'notion', 'gmail', 'googlecalendar', 'stripe'].map((n) => <Logo key={n} n={n} size={40} />)}</div>
      </Caja>
      <Caja x={390} y={100} w={250} h={114} at={b + 0.45}>
        <Etq>Tú · reglas una vez</Etq>
        <div style={{display: 'flex', gap: 8}}>{['whatsapp', 'notion', 'googledocs'].map((n) => <Logo key={n} n={n} size={40} />)}</div>
      </Caja>
      <Caja x={670} y={100} w={390} h={114} at={b + 0.55} dark>
        <Etq c="#9FE8C4">Conocimiento · 24 archivos</Etq>
        <div style={{fontFamily: MONO, fontSize: 15, color: '#C9D2CD', lineHeight: 1.5}}>/voz /oferta /reglas<br />/audiencia /contenido /marca</div>
      </Caja>
      {/* orquestador */}
      <Caja x={330} y={250} w={440} h={122} at={b + 0.8} dark style={{borderRadius: 24, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10, boxShadow: '0 22px 40px -18px rgba(0,0,0,.6)'}}>
        <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 31, color: '#fff', letterSpacing: -0.6}}>Equipo de Marketing</div>
        <div style={{display: 'flex', gap: 10}}>{['claude', 'hubspot', 'higgsfield', 'notion'].map((n) => <Logo key={n} n={n} size={40} />)}</div>
      </Caja>
      {/* columnas laterales */}
      {['posts.db', 'leads.db', 'ventas.db'].map((d, i) => (
        <Caja key={d} x={-48} y={470 + i * 250} w={64} h={110} at={b + 1.8 + i * 0.1} style={{padding: 6, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6}}>
          <Ico n="db" size={30} color={[PURPLE, GREEN, '#7C6CFF'][i]} />
          <span style={{fontFamily: MONO, fontSize: 9.5, color: MUTED}}>{d}</span>
        </Caja>
      ))}
      {['Señales', 'Revisión', 'Leads', 'Agenda'].map((d, i) => (
        <Caja key={d} x={1090} y={420 + i * 190} w={110} h={150} at={b + 1.8 + i * 0.1} dark style={{padding: 10}}>
          <Etq c="#9FE8C4">{d}</Etq>
          {[0, 1, 2].map((k) => <div key={k} style={{height: 8, borderRadius: 4, background: '#2A322E', marginBottom: 8, width: `${90 - k * 18}%`}} />)}
        </Caja>
      ))}
      {/* módulos */}
      {MODS.map((m, i) => <ModCard key={m.id} m={m} idx={i} at={b + 1.3 + i * 0.12} flash={flash} />)}
      {/* datos + handoff */}
      <Caja x={70} y={1170} w={450} h={130} at={b + 2.4}>
        <Etq>Datos · lo que ves cada mañana</Etq>
        <div style={{display: 'flex', gap: 8}}>{['googleanalytics', 'stripe', 'calendly', 'hubspot', 'instagram', 'youtube'].map((n) => <Logo key={n} n={n} size={40} />)}</div>
      </Caja>
      <Caja x={560} y={1170} w={470} h={130} at={b + 2.5}>
        <Etq>Human handoff</Etq>
        <div style={{display: 'flex', gap: 18}}>
          {[{k: 'Tú apruebas', c: ORANGE, l: ['whatsapp', 'gmail']}, {k: 'Clientes', c: '#3B82F6', l: ['calendly', 'stripe']}, {k: 'Tu audiencia', c: GREEN, l: ['instagram', 'tiktok']}].map((g) => (
            <div key={g.k}>
              <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 16, color: g.c, marginBottom: 6}}>{g.k}</div>
              <div style={{display: 'flex', gap: 6}}>{g.l.map((n) => <Logo key={n} n={n} size={38} />)}</div>
            </div>
          ))}
        </div>
      </Caja>
      {/* aprobar dentro del handoff */}
      {t > aprobar - 2.4 ? (
        <div style={{position: 'absolute', left: 560, top: 1120, width: 270, height: 62, borderRadius: 16, background: '#fff', border: `1.5px solid ${ok ? GREEN : ORANGE}`, boxShadow: '0 14px 26px -14px rgba(0,0,0,.35)', display: 'flex', alignItems: 'center', gap: 8, padding: '0 10px', opacity: sp(t, aprobar - 2.4, fps), transform: `translateY(${(1 - sp(t, aprobar - 2.4, fps)) * 14}px)`}}>
          <Img src={staticFile('img/kevin14.jpg')} style={{width: 40, height: 40, borderRadius: 8, objectFit: 'cover'}} />
          <span style={{fontFamily: SANS, fontWeight: 700, fontSize: 14, color: INK, lineHeight: 1.1}}>Post listo<br /><span style={{color: MUTED, fontWeight: 500}}>Reel · agentes</span></span>
          <div style={{marginLeft: 'auto', fontFamily: SANS, fontWeight: 800, fontSize: 14, color: ok ? '#fff' : INK, background: ok ? GREEN : '#FFC83D', borderRadius: 999, padding: '7px 12px', transform: `scale(${press ? 0.92 : 1})`, display: 'flex', alignItems: 'center', gap: 4}}>{ok ? <><Ico n="check" size={14} color="#fff" w={3} />Aprobado</> : 'Aprobar'}</div>
        </div>
      ) : null}
      {t > aprobar - 1.6 && t < aprobar + 1.5 ? (
        <div style={{position: 'absolute', left: 0, top: 0, transform: 'scale(.45)', transformOrigin: '0 0'}}>
          <Cursor x={interpolate(t, [aprobar - 1.5, aprobar - 0.05], [2050, 1745], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)})} y={interpolate(t, [aprobar - 1.5, aprobar - 0.05], [2700, 2545], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)})} press={press} />
        </div>
      ) : null}
      {/* terminal + interrupciones */}
      <Caja x={70} y={1330} w={420} h={300} at={b + 2.7} dark style={{padding: 0, overflow: 'hidden'}}>
        <div style={{display: 'flex', gap: 6, padding: '10px 12px'}}>{['#FF5F57', '#FEBC2E', '#28C840'].map((c) => <div key={c} style={{width: 9, height: 9, borderRadius: 5, background: c}} />)}</div>
        <div style={{fontFamily: MONO, fontSize: 15, color: '#C9D2CD', padding: '0 18px', lineHeight: 1.7}}>
          <div style={{color: '#9FE8C4'}}>$ marketing status --hoy</div>
          <div>posts escritos&nbsp;&nbsp;&nbsp;&nbsp;14</div>
          <div>videos&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;7</div>
          <div>comentarios&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;312</div>
          <div>llamadas&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;9</div>
          <div style={{color: '#FFC83D'}}>esperando por ti&nbsp;&nbsp;3</div>
          <div>resumen&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;7:00</div>
        </div>
      </Caja>
      <Caja x={520} y={1330} w={510} h={300} at={b + 2.8}>
        <Etq>Qué interrumpe el loop</Etq>
        <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px 16px'}}>
          {[['Cliente pide una persona', ['whatsapp', 'calendly']], ['Comentario enojado', ['instagram', 'whatsapp']], ['Post se hace viral', ['tiktok', 'whatsapp']], ['Llega un lead caliente', ['hubspot', 'whatsapp']], ['Alguien se da de baja', ['gmail', 'hubspot']], ['Créditos bajos', ['higgsfield', 'whatsapp']]].map(([k, l]) => (
            <div key={k as string}>
              <div style={{fontFamily: SANS, fontWeight: 700, fontSize: 14.5, color: INK, marginBottom: 5}}>{k as string}</div>
              <div style={{display: 'flex', gap: 5}}>{(l as string[]).map((n) => <Logo key={n} n={n} size={30} />)}</div>
            </div>
          ))}
        </div>
      </Caja>
      {/* etiqueta del loop */}
      <div style={{position: 'absolute', left: 1066, top: 560, transform: 'rotate(90deg)', transformOrigin: 'left top', fontFamily: MONO, fontWeight: 700, fontSize: 13, color: ORANGE, background: '#fff', padding: '2px 8px', borderRadius: 6, opacity: L(2), whiteSpace: 'nowrap'}}>LOOP · VUELVE CADA SEMANA</div>
    </div>
  );
};

// fichas: 1 persona · empleados · agentes
export const Fichas: React.FC<{at: number; emp: number; ag: number}> = ({at, emp, ag}) => {
  const {t, fps} = useT();
  const items = [
    {k: 'Personas', v: <span>1</span>},
    {k: 'Empleados', v: <Count from={0} to={24} at={emp} dur={1.3} />},
    {k: 'Agentes', v: <Count from={0} to={36} at={ag} dur={1.1} />},
  ];
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: 300, display: 'flex', justifyContent: 'center', gap: 14}}>
      {items.map((it, i) => {
        const s = sp(t, at + i * 0.12, fps);
        const hot = (i === 1 && t > emp && t < emp + 1.6) || (i === 2 && t > ag && t < ag + 1.5);
        return (
          <div key={i} style={{opacity: s, transform: `translateY(${(1 - s) * 16}px) scale(${hot ? 1.06 : 1})`, background: hot ? INK : '#fff', color: hot ? '#fff' : INK, border: `1.5px solid ${hot ? INK : LINE}`, borderRadius: 14, padding: '8px 18px', minWidth: 150, boxShadow: '0 10px 24px -16px rgba(0,0,0,.4)'}}>
            <div style={{fontFamily: MONO, fontSize: 12, letterSpacing: 1.4, textTransform: 'uppercase', color: hot ? '#9FE8C4' : MUTED}}>{it.k}</div>
            <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 40, lineHeight: 1.05}}>{it.v}</div>
          </div>
        );
      })}
    </div>
  );
};
