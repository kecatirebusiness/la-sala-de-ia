# Mi oferta

- Producto o servicio: [nombre]
- Para quién es (cliente ideal): [descripción]
- Problema que resuelve: [problema]
- Resultado que promete: [resultado real, sin exagerar]
- Precio y forma de pago: [precio] · [link de Stripe]
- Por qué yo y no otro: [razón]
- Preguntas frecuentes y sus respuestas:
