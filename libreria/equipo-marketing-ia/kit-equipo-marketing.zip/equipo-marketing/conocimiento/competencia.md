# Competencia

- [Cuenta 1]: qué hace bien, qué no
- [Cuenta 2]:
- [Cuenta 3]:
