# Reglas

- Nada se publica sin mi OK.
- Nunca inventar testimonios, cifras ni resultados.
- Nunca prometer ingresos.
- Temas que no tocamos: [temas]
- Si alguien está molesto o pide una persona: escalar a mí.
- Presupuesto máximo de créditos por semana: [número]
