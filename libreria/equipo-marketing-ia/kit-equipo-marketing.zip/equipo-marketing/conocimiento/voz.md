# Mi voz

- Cómo me presento: [una frase]
- Palabras que uso: [ej. "mano", "o sea", "brutal"]
- Palabras que NUNCA uso: [ej. "sinergia", "disruptivo"]
- Tono: [ej. como un amigo que sabe más, directo, con humor]
- 3 posts míos que suenan a mí (pega el texto):
  1. 
  2. 
  3. 
- ID de mi voz clonada (ElevenLabs): [ID]
