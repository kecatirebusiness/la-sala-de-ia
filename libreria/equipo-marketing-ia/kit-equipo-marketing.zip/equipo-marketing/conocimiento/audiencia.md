# Mi audiencia

- Nicho: [nicho]
- Edad, país, idioma: [datos]
- Qué quieren lograr: [meta]
- Qué los frena: [miedos y objeciones]
- Dónde pasan el tiempo: [plataformas, subreddits, grupos]
- Cuentas que ya siguen: [cuentas]
