# Contenido

- Pilares (3 a 5 temas fijos): 
- Formatos que más me funcionan: 
- Frecuencia por plataforma: [ej. Instagram 5/semana, TikTok 5, YouTube 1]
- Palabra clave de los CTA: [PALABRA]
