# Marca

- Colores (hex): 
- Tipografías: 
- Logo: [ruta]
- Estilo de imagen: [ej. fotos reales, luz cálida, nada de stock]
- Zona segura de Reels: nada importante en los 220 px de arriba ni en los 450 de abajo.
