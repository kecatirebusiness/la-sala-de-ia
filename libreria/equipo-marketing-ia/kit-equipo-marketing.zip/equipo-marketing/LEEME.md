# Kit · Tu equipo de marketing de 36 agentes (La Sala de IA)

1. Instala Claude Code: https://claude.com/claude-code
2. Abre esta carpeta con Claude Code.
3. Llena los 7 archivos de conocimiento/ (cambia todo lo que está entre [corchetes]).
4. Dile: «Lee CLAUDE.md y corre solo el módulo 1 para la próxima semana».
5. Sigue el plan de 7 días del PDF.

Los agentes están en .claude/agents/ (uno por archivo). Puedes editarlos: son instrucciones en español.
Receta completa con el video: https://lasaladeia.com/libreria/equipo-marketing-ia/
