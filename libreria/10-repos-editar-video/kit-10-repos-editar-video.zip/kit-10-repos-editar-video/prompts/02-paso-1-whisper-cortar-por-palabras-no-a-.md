# 02 · Paso 1 · Whisper: cortar por palabras, no a ojo

Whisper pasa tu voz a texto con el tiempo de cada palabra. Con eso Claude sabe exactamente dónde empieza y termina cada frase, y corta ahí.

## Prompt para Claude Code: transcribir con tiempos

```
Instala Whisper (pip install -U openai-whisper; si falta FFmpeg, instálalo también). Transcribe material/[ARCHIVO] en español con el tiempo de cada palabra y guárdalo en material/transcripcion.json y un .srt. Después márcame las pausas de más de medio segundo y las frases repetidas.
```

