# 10 · Si te falta algo: el índice

Awesome Claude Video Skills reúne cientos de repos de video para Claude Code, ordenados por tipo y con una nota de seguridad para cada uno. La nota no garantiza nada: revisa el README y los pasos de instalación antes de instalar cualquier cosa.

## Prompt para Claude Code: buscar en el índice

```
Lee https://github.com/zhuyansen/awesome-claude-video-skills. Necesito una herramienta para [LO QUE TE FALTA, ej. poner efectos de sonido]. Dame las 3 mejores opciones con su nota de seguridad, cuántas estrellas tienen, cuándo se actualizaron por última vez y qué instalan en mi computadora. No instales nada todavía.
```

