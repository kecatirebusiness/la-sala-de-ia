# 03 · Paso 2 · Cortar: FFmpeg Skill

Le da a Claude 42 herramientas para recortar, subtitular, pasar a vertical, nivelar el audio y exportar para cada red. Claude decide; la skill ejecuta y comprueba.

## Prompt para Claude Code: el corte

```
Instala ffmpeg-skill con "npx ffmpeg-skill setup". Con material/transcripcion.json, corta las pausas y las frases repetidas de material/[ARCHIVO] (quédate con la última toma buena), pásalo a vertical 1080×1920, quema los subtítulos y nivela el audio para Reels. Enséñame la página de revisión antes de exportar.
```

