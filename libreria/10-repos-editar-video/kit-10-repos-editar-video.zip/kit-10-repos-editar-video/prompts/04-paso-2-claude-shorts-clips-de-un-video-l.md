# 04 · Paso 2 · Claude Shorts: clips de un video largo

Para podcasts y lives: encuentra los mejores momentos y los devuelve como clips verticales con subtítulos animados. Tú apruebas cuáles se renderizan.

## Prompt para Claude Code: clips

```
Instala claude-shorts siguiendo su README (git clone, bash setup.sh, bash install.sh). Busca los 5 mejores momentos de material/[VIDEO LARGO] para clips de 30 a 60 segundos y enséñamelos con su gancho antes de renderizar.
```

