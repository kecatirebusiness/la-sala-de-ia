# 06 · Paso 3 · Animar: HyperFrames

Claude diseña cada escena como una página web (HTML y CSS, que domina) y HyperFrames la convierte en MP4. Ideal para tarjetas, títulos y gráficos sobre tu video.

## Prompt para Claude Code: gráficos con HyperFrames

```
Instala HyperFrames (npx skills add heygen-com/hyperframes, escoge «Core Skills»). Hazme un título animado de 3 segundos con el texto "[TU TEXTO]" en [TUS COLORES], vertical 1080×1920 con fondo transparente, y ponlo al inicio de exportados/[MI VIDEO].
```

