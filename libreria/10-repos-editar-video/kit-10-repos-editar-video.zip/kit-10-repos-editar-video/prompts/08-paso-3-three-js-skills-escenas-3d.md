# 08 · Paso 3 · Three.js Skills: escenas 3D

Le enseña a Claude a armar escenas 3D para la web con Three.js: un producto girando, un logo en 3D o un fondo animado que luego grabas para tu video.

## Prompt para Claude Code: escena 3D

```
Instala threejs-skills (npx skills add cloudai-x/threejs-skills). Hazme una escena 3D en una página web con [TU OBJETO, ej. mi logo] girando despacio sobre fondo [COLOR], y grábala como video vertical de 5 segundos.
```

