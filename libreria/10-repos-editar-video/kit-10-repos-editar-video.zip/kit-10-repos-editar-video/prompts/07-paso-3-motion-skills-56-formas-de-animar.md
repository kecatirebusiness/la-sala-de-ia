# 07 · Paso 3 · Motion Skills: 56 formas de animar

Texto cinético, gráficas de datos, explicativos, TikTok/Reels, 3D y más, en 19 paquetes. Instala solo el paquete de lo que haces.

## Prompt para Claude Code: escoger el paquete

```
Mira la lista de paquetes de https://github.com/iart-ai/motion-skills. Yo hago [TIPO DE VIDEO, ej. reels explicativos de mi negocio]. Dime cuál paquete me sirve, instálalo con npx skills add y hazme una prueba de 5 segundos con mi texto: "[TEXTO]".
```

