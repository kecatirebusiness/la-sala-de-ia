# 01 · Paso 1 · El material: yt-dlp

Baja video y audio de YouTube, Vimeo, TikTok, Instagram y más de mil sitios. La herramienta es legal, pero bajar videos de otros puede ir contra las reglas de YouTube y los derechos de autor: úsala con tus videos o con material que tengas permiso de usar.

## Prompt para Claude Code: bajar tu material

```
Instala yt-dlp (python -m pip install -U "yt-dlp[default]") y baja este video mío a la carpeta material/: [LINK]. Guarda el video en la mejor calidad y el audio aparte en .m4a.
```

