# 05 · Paso 2 · Ghost Editor: tu toma a cámara

Convierte tu toma hablando a cámara en un reel con subtítulos que no te tapan la cara. Solo Mac con chip Apple; por ahora probado en inglés y ruso.

## Prompt para Claude Code: instalar Ghost Editor

```
Install the ghost-editor skill: clone https://github.com/kurbaitaev/ghost-editor into ~/.claude/skills/ghost-editor and follow its docs/INSTALL.md. Después edita material/[MI TOMA] en un reel vertical con la mejor toma de cada frase.
```

