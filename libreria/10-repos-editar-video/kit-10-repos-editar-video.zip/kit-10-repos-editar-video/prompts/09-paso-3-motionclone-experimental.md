# 09 · Paso 3 · MotionClone (experimental)

Copia el movimiento de un clip de referencia a un video nuevo generado con IA. Es un proyecto de investigación: necesita una tarjeta gráfica potente (NVIDIA), modelos de Stable Diffusion 1.5 y no se actualiza desde junio de 2025. Pruébalo solo si tienes GPU.

## Prompt para Claude Code: probar MotionClone

```
Revisa si esta computadora tiene una GPU NVIDIA con suficiente memoria para MotionClone (https://github.com/LPengYang/MotionClone). Si no la tiene, dímelo y no instales nada. Si sí: sigue su README (conda env, modelos de Stable Diffusion 1.5) y prueba el ejemplo que trae antes de usar mis clips.
```

