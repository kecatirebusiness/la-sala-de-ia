# Instalar

Los comandos que empiezan con / se escriben dentro de Claude Code. Los demás, en la terminal (o pídeselos a Claude Code). Después de instalar plugins: /reload-plugins.

## yt-dlp/yt-dlp
https://github.com/yt-dlp/yt-dlp

```
python -m pip install -U "yt-dlp[default]"
```

## openai/whisper
https://github.com/openai/whisper

```
pip install -U openai-whisper
```

## kajisho5/ffmpeg-skill
https://github.com/kajisho5/ffmpeg-skill

```
npx ffmpeg-skill setup
```

## AgriciDaniel/claude-shorts
https://github.com/AgriciDaniel/claude-shorts

```
git clone https://github.com/AgriciDaniel/claude-shorts.git && cd claude-shorts && bash setup.sh && bash install.sh
```

## kurbaitaev/ghost-editor
https://github.com/kurbaitaev/ghost-editor

```
Install the ghost-editor skill: clone https://github.com/kurbaitaev/ghost-editor into ~/.claude/skills/ghost-editor and follow its docs/INSTALL.md.
```

## heygen-com/hyperframes
https://github.com/heygen-com/hyperframes

```
npx skills add heygen-com/hyperframes
```

## iart-ai/motion-skills
https://github.com/iart-ai/motion-skills

```
npx skills add iart-ai/tiktok-video-skills
```

## CloudAI-X/threejs-skills
https://github.com/CloudAI-X/threejs-skills

```
npx skills add cloudai-x/threejs-skills
```

## LPengYang/MotionClone
https://github.com/LPengYang/MotionClone

```
git clone https://github.com/LPengYang/MotionClone.git && cd MotionClone && conda env create -f environment.yaml
```

