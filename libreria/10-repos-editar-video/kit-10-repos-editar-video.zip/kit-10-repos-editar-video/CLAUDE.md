# Carpeta de edición

Herramientas por paso:
1. Material: yt-dlp (solo mis videos o con permiso) y Whisper (texto con el tiempo de cada palabra).
2. Cortar: ffmpeg-skill para cortes, subtítulos y exportar; claude-shorts para clips de videos largos; ghost-editor para tomas a cámara (solo Mac).
3. Animar: HyperFrames para títulos y gráficos; el paquete de motion-skills que tenga instalado; threejs-skills para 3D. MotionClone solo si hay GPU.

Corta por palabras usando la transcripción, nunca a ojo. Antes de instalar algo nuevo, dime qué instala y espera mi sí.
