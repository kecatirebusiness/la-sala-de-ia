# 10 repos de GitHub para que Claude edite video

Claude no sabe editar video… hasta que le instalas estas herramientas. Ordenadas por paso: el material, cortar y animar, más un índice con cientos de repos de video. Cada una con su link y su instalación.

Receta completa: https://lasaladeia.com/libreria/10-repos-editar-video/

Paso 1, el material: yt-dlp baja el video y Whisper lo pasa a texto con el tiempo de cada palabra, así Claude corta por palabras y no a ojo. Paso 2, cortar: FFmpeg Skill, Claude Shorts y Ghost Editor. Paso 3, animar: HyperFrames, Motion Skills, Three.js Skills y MotionClone. Y si te falta algo, Awesome Claude Video Skills. Un dato de esa lista: Claude sin ninguna skill hizo un video sencillo en menos de 5 minutos. Las herramientas valen cuando buscas un estilo o tienes material tuyo que editar.

**Costo:** Los diez son de código abierto (MotionClone no publica licencia). Para usarlos con Claude Code necesitas un plan de pago de Claude. HyperFrames también tiene una app Studio con plan gratis y uno Pro de 25 USD al mes

**Tiempo:** Una tarde para los del paso 1 y 2. MotionClone es aparte: necesita GPU potente y paciencia

## Herramientas
- Claude Code: Donde se instalan y corren los diez. https://claude.com/claude-code
- FFmpeg: La base de casi todos: varias de estas herramientas lo necesitan instalado. https://ffmpeg.org
- La Sala de IA: Aquí editamos así nuestros reels y te enseñamos el proceso en vivo. https://lasaladeia.com/?utm_source=libreria

## Repos
- yt-dlp/yt-dlp: https://github.com/yt-dlp/yt-dlp
- openai/whisper: https://github.com/openai/whisper
- kajisho5/ffmpeg-skill: https://github.com/kajisho5/ffmpeg-skill
- AgriciDaniel/claude-shorts: https://github.com/AgriciDaniel/claude-shorts
- kurbaitaev/ghost-editor: https://github.com/kurbaitaev/ghost-editor
- heygen-com/hyperframes: https://github.com/heygen-com/hyperframes
- iart-ai/motion-skills: https://github.com/iart-ai/motion-skills
- CloudAI-X/threejs-skills: https://github.com/CloudAI-X/threejs-skills
- LPengYang/MotionClone: https://github.com/LPengYang/MotionClone
- zhuyansen/awesome-claude-video-skills: https://github.com/zhuyansen/awesome-claude-video-skills

## Qué hay en este kit
- instalar.md: los comandos de instalación.
- prompts/: un archivo por paso con sus prompts.
