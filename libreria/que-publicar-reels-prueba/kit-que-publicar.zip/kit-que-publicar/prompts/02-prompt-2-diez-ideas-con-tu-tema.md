# 02 · Prompt 2: diez ideas con tu tema

Pídele 10 ideas con esas estructuras, pero con tu tema, tus palabras y pensadas para tu cliente. Inspiración, no copia: usa la estructura y cuéntalo con tu experiencia.

## Prompt 2 · Diez ideas

```
Con esas estructuras, dame 10 ideas de reels para mi cuenta. Mi tema es [TEMA], mi cliente ideal es [QUIÉN ES Y QUÉ LE PREOCUPA] y hablo así: [2 O 3 FRASES TUYAS]. Inspírate en las estructuras, no copies los textos ni las ideas de los otros videos. Para cada idea dame: el gancho, lo que digo en los primeros 3 segundos y un guion corto en 4 o 5 puntos.
```

