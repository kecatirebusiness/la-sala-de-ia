# 01 · Prompt 1: por qué funcionó

Busca 5 reels que estén funcionando en tu tema. Pásale a Claude lo que dice cada uno (la transcripción o el texto, no hace falta bajar nada) y pídele que te explique el gancho, los primeros 3 segundos y la estructura.

## Prompt 1 · Por qué funcionó

```
Te voy a pegar lo que dicen 5 reels que están funcionando en mi tema: [TEMA]. Para cada uno, explícame: 1) el gancho (la primera frase y por qué engancha), 2) qué pasa en los primeros 3 segundos, 3) la estructura del video paso a paso, 4) por qué crees que funcionó y 5) qué cosas NO debería copiar porque son del estilo o la marca de esa persona. Al final, dame las 3 estructuras que más se repiten.

[PEGA AQUÍ EL TEXTO DE LOS 5 REELS]
```

