# 04 · Prompt 3: qué aprendimos

A las 72 horas mira cuál ganó. Si le fue bien, deja que Instagram lo comparta automáticamente con tus seguidores. Y llévale los números a Claude para que la próxima tanda salga mejor.

## Prompt 3 · Qué aprendimos

```
Publiqué estos reels de prueba hace 72 horas. Te pego sus números: vistas, retención o tiempo promedio de reproducción, guardados, compartidos y comentarios. [PEGA LOS NÚMEROS DE CADA REEL]. Dime cuál ganó y por qué, qué tienen en común los que funcionaron, qué dejo de hacer y qué 3 ideas nuevas debería probar en la próxima tanda.
```

