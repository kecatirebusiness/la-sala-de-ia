# 05 · Hazlo un ciclo semanal

Para no empezar de cero cada vez, guarda todo en un Proyecto de Claude: tus estructuras ganadoras, tus ideas probadas y los números de cada tanda. Así cada semana Claude sabe qué ya funcionó contigo.

## Instrucciones para tu Proyecto de Claude

```
Este proyecto es mi laboratorio de contenido para Instagram. Mi tema: [TEMA]. Mi cliente ideal: [QUIÉN]. Cómo hablo: [2 O 3 FRASES MÍAS].
Cada semana te voy a pasar: los reels de otros que estoy analizando, las ideas que escogí y los números de mis reels de prueba a las 72 horas. Lleva una tabla con cada reel que publiqué (gancho, estructura, vistas, retención, guardados, compartidos) y úsala para que cada tanda de ideas nueva se parezca más a lo que ya me funcionó. Nunca copies textos de otros creadores.
```

