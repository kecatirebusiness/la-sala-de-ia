# Cómo saber qué publicar: Claude + los reels de prueba de Instagram

Editar ya no es lo difícil; lo difícil es saber qué publicar. Analiza 5 reels que funcionan, saca 10 ideas con tu tema y pruébalas con gente que no te sigue. Tres prompts y un ciclo de 72 horas.

Receta completa: https://lasaladeia.com/libreria/que-publicar-reels-prueba/

Los reels de prueba son una opción de Instagram al publicar: el reel se lo enseña primero a gente que no te sigue, así que puedes probar ideas sin miedo. Tus seguidores no lo ven en su feed ni en Reels (salvo que alguien se lo comparta). Si le va bien en las primeras 72 horas, puedes dejar que Instagram lo comparta solo con tus seguidores. Claude pone el método: por qué funcionó lo de otros, qué ideas probar y qué aprendiste de los números.

**Costo:** Gratis: el plan gratis de Claude alcanza para los 3 prompts, y los reels de prueba son una función de Instagram (la disponibilidad puede variar según tu cuenta)

**Tiempo:** 1 hora para la primera tanda. Después, 72 horas de espera y 15 minutos para leer los números

## Herramientas
- Claude: Analiza los reels, te da las ideas y lee tus números. Sirve la app o claude.ai. https://claude.ai
- Instagram · reels de prueba: La guía oficial de Instagram sobre los reels de prueba (trial reels). https://creators.instagram.com/blog/instagram-trial-reels
- La Sala de IA: Aquí hacemos este ciclo cada semana con nuestras cuentas. https://lasaladeia.com/?utm_source=libreria

## Qué hay en este kit
- instalar.md: los comandos de instalación.
- prompts/: un archivo por paso con sus prompts.
