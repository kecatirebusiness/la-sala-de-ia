# Los 30 mejores plugins de Claude en GitHub, ordenados por tarea

Programar como un senior, investigar, gastar menos tokens, diseñar y escribir. Los 30 del video con su link real y su comando de instalación. No instales los 30: escoge la fila de tu semana y añade uno.

Receta completa: https://lasaladeia.com/libreria/30-plugins-claude/

Un plugin o skill le enseña a Claude Code una forma de trabajar: preguntar antes de programar, recordar lo que hizo la sesión pasada, diseñar con gusto o escribir sin sonar a IA. Hay miles en GitHub; estos son 30 de los más usados, en 5 filas según la tarea. La regla del video: escoge la fila que va con tu semana, instala uno solo, úsalo y después decides.

**Costo:** Los 30 son gratis y de código abierto. Necesitas un plan de pago de Claude (Pro o Max) para usar Claude Code, y lo que hacen gasta de tu uso normal

**Tiempo:** 2 minutos por plugin. Pruébalo una semana antes de sumar otro

## Herramientas
- Claude Code: Donde se instalan y corren los plugins (terminal o app de escritorio, pestaña Code). https://claude.com/claude-code
- Docs: cómo instalar plugins: La guía oficial de /plugin: marketplaces, instalar, actualizar y quitar. https://code.claude.com/docs/en/discover-plugins
- La Sala de IA: Aquí los probamos primero y te contamos cuáles sí valen la pena. https://lasaladeia.com/?utm_source=libreria

## Repos
- obra/superpowers: https://github.com/obra/superpowers
- mattpocock/skills: https://github.com/mattpocock/skills
- affaan-m/ECC: https://github.com/affaan-m/ECC
- multica-ai/andrej-karpathy-skills: https://github.com/multica-ai/andrej-karpathy-skills
- DietrichGebert/ponytail: https://github.com/DietrichGebert/ponytail
- addyosmani/agent-skills: https://github.com/addyosmani/agent-skills
- morluto/rea: https://github.com/morluto/rea
- Graphify-Labs/graphify: https://github.com/Graphify-Labs/graphify
- Panniantong/Agent-Reach: https://github.com/Panniantong/Agent-Reach
- Egonex-AI/Understand-Anything: https://github.com/Egonex-AI/Understand-Anything
- career-ops-hq/career-ops: https://github.com/career-ops-hq/career-ops
- mvanhorn/last30days-skill: https://github.com/mvanhorn/last30days-skill
- garrytan/gstack: https://github.com/garrytan/gstack
- JuliusBrussee/caveman: https://github.com/JuliusBrussee/caveman
- thedotmack/claude-mem: https://github.com/thedotmack/claude-mem
- headroomlabs-ai/headroom: https://github.com/headroomlabs-ai/headroom
- open-gsd/gsd-core: https://github.com/open-gsd/gsd-core
- bmad-code-org/BMAD-METHOD: https://github.com/bmad-code-org/BMAD-METHOD
- nextlevelbuilder/ui-ux-pro-max-skill: https://github.com/nextlevelbuilder/ui-ux-pro-max-skill
- Leonxlnx/taste-skill: https://github.com/Leonxlnx/taste-skill
- tt-a1i/archify: https://github.com/tt-a1i/archify
- pbakaus/impeccable: https://github.com/pbakaus/impeccable
- hugohe3/ppt-master: https://github.com/hugohe3/ppt-master
- cathrynlavery/diagram-design: https://github.com/cathrynlavery/diagram-design
- anthropics/skills: https://github.com/anthropics/skills
- OpenMontageInc/OpenMontage: https://github.com/OpenMontageInc/OpenMontage
- heygen-com/hyperframes: https://github.com/heygen-com/hyperframes
- blader/humanizer: https://github.com/blader/humanizer
- ayghri/i-have-adhd: https://github.com/ayghri/i-have-adhd
- coreyhaines31/marketingskills: https://github.com/coreyhaines31/marketingskills

## Qué hay en este kit
- instalar.md: los comandos de instalación.
- prompts/: un archivo por paso con sus prompts.
