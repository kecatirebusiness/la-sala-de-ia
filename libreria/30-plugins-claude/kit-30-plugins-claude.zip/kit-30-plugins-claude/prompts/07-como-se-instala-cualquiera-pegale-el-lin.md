# 07 · Cómo se instala cualquiera: pégale el link

No necesitas saber comandos. Copia el nombre, búscalo en GitHub y pégale el link a Claude Code con «instálame este plugin». Él lee el README y lo hace. Igual, antes de instalar algo de GitHub, revisa que sea el repo original (el de los links de arriba) y lee qué permisos pide. Al terminar escribe /reload-plugins o reinicia Claude Code.

## Prompt para Claude Code: instálame este plugin (sirve para los 30)

```
Instálame este plugin: [LINK DE GITHUB].
1. Lee su README y usa el método de instalación oficial para Claude Code (marketplace, npx o lo que diga).
2. Antes de instalar, dime en 3 líneas qué hace, qué va a instalar en mi computadora y si manda algo a internet. Espera mi sí.
3. Instálalo, recarga los plugins y pruébalo con un ejemplo corto.
4. Dime cómo se usa (comandos o frases que lo activan) y cómo lo desinstalo si no me gusta.
```

