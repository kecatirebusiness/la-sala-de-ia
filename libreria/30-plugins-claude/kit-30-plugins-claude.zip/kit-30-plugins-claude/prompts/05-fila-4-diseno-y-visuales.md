# 05 · Fila 4 · Diseño y visuales

Para cuando lo que te entrega Claude se ve genérico. UI UX Pro Max, Taste e Impeccable le dan criterio de diseño a tus páginas; Archify y Diagram Design hacen diagramas; PPT Master hace presentaciones de PowerPoint de verdad.

## Prompt para Claude Code: instálame Taste y rediseña mi página

```
Instala taste-skill (/plugin marketplace add Leonxlnx/taste-skill y /plugin install taste-skill@taste-skill). Después rediseña [RUTA O LINK DE TU PÁGINA] con esa skill: propónme primero una dirección de arte con 2 referencias, y cuando la apruebe, hazla y revísala en el navegador en escritorio y en móvil.
```

