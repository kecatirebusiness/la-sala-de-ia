# 03 · Fila 2 · Investiga y entiende

Para cuando tienes que entender algo rápido: un código ajeno (Graphify, Understand Anything, REA), lo que se dice de un tema en internet (Last 30 Days, Agent Reach) o tu búsqueda de trabajo (Career Ops).

## Prompt para Claude Code: instálame Last 30 Days para investigar un tema

```
Instala last30days-skill (https://github.com/mvanhorn/last30days-skill) siguiendo su README. Después investiga qué se dijo en los últimos 30 días sobre [TEMA DE TU NICHO] en Reddit, X, YouTube y la web. Dame: los 5 temas que más se repiten, las 3 preguntas que más hace la gente y los links de donde lo sacaste.
```

