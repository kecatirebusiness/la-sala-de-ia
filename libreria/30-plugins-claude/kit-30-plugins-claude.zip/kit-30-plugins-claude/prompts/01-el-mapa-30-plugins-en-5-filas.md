# 01 · El mapa: 30 plugins en 5 filas

Programa como un senior, Investiga y entiende, Proyectos grandes con menos tokens, Diseño y visuales, y Escritura y video. Arriba tienes los 30 con su link y su comando, marcados con su fila. No los instales todos: cada plugin agrega instrucciones que Claude lee, y si metes 30 se estorban entre ellos.

## Prompt para Claude Code: escoger tu fila

```
Te paso 5 grupos de plugins para Claude Code:
1. Programar como un senior: Superpowers, Matt Pocock Skills, ECC, Karpathy Skills, Ponytail, Agent Skills.
2. Investigar y entender: REA, Graphify, Agent Reach, Understand Anything, Career Ops, Last 30 Days.
3. Proyectos grandes, menos tokens: gstack, Caveman, Claude-Mem, Headroom, GSD, BMAD Method.
4. Diseño y visuales: UI UX Pro Max, Taste, Archify, Impeccable, PPT Master, Diagram Design.
5. Escritura y video: Skills de Anthropic, OpenMontage, HyperFrames, Humanizer, I Have ADHD, Marketing Skills.

Esta semana voy a trabajar en: [QUÉ VAS A HACER, ej. la página de mi negocio]. Mira esta carpeta y dime cuál fila me sirve y cuál UN solo plugin de esa fila instalarías primero, y por qué. No instales nada todavía.
```

