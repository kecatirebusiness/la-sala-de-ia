# 04 · Fila 3 · Proyectos grandes, menos tokens

Para cuando el proyecto crece y Claude se olvida de cosas o gasta tu límite muy rápido. Claude-Mem le da memoria entre sesiones, Caveman y Headroom recortan lo que lee y escribe, y gstack, GSD y BMAD le dan un método para proyectos largos.

## Prompt para Claude Code: instálame Claude-Mem

```
Instala Claude-Mem con "npx claude-mem install" y explícame qué guarda, dónde lo guarda (en mi computadora) y cómo apago la analítica anónima si no la quiero. Cuando esté listo, dime cómo compruebo en la próxima sesión que se acuerda de lo que hicimos hoy.
```

