# 06 · Fila 5 · Escritura y video

Para contenido. Las skills de Anthropic hacen documentos de Word, Excel, PowerPoint y PDF; Humanizer e I Have ADHD mejoran cómo escribe; Marketing Skills trae copy y SEO; OpenMontage y HyperFrames hacen video.

## Prompt para Claude Code: instálame Humanizer

```
Instala Humanizer (/plugin marketplace add blader/humanizer y /plugin install humanizer@humanizer). Después pasa este texto por la skill y enséñame qué cambiaste y por qué: [PEGA TU TEXTO].
```

