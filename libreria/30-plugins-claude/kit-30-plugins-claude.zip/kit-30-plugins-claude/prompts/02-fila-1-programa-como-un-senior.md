# 02 · Fila 1 · Programa como un senior

Para cuando Claude se lanza a escribir código sin pensar. Superpowers lo obliga a preguntar, planear y revisar; Karpathy Skills y Ponytail lo hacen más simple y cuidadoso; Matt Pocock, ECC y Agent Skills traen las mañas de equipos reales (revisiones, pruebas, requisitos).

## Prompt para Claude Code: instálame Superpowers y úsalo

```
Instala Superpowers con /plugin install superpowers@claude-plugins-official y recarga los plugins. Después, antes de tocar código, hazme las preguntas que necesites sobre esto que quiero construir: [TU IDEA]. Con mis respuestas escribe un plan en plan.md, enséñamelo y espera mi sí antes de programar.
```

