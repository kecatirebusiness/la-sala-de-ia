# Mi prueba de plugins

| Semana | Fila | Plugin | ¿Para qué lo usé? | ¿Me quedo con él? |
|---|---|---|---|---|
|  |  |  |  |  |
