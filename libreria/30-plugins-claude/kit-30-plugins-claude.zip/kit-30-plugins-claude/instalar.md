# Instalar

Los comandos que empiezan con / se escriben dentro de Claude Code. Los demás, en la terminal (o pídeselos a Claude Code). Después de instalar plugins: /reload-plugins.

## obra/superpowers
https://github.com/obra/superpowers

```
/plugin install superpowers@claude-plugins-official
```

## mattpocock/skills
https://github.com/mattpocock/skills

```
/plugin install mattpocock-skills@claude-plugins-official
```

## affaan-m/ECC
https://github.com/affaan-m/ECC

```
npx ecc-universal@2.2.3 setup
```

## multica-ai/andrej-karpathy-skills
https://github.com/multica-ai/andrej-karpathy-skills

```
/plugin marketplace add forrestchang/andrej-karpathy-skills
/plugin install andrej-karpathy-skills@karpathy-skills
```

## DietrichGebert/ponytail
https://github.com/DietrichGebert/ponytail

```
/plugin marketplace add DietrichGebert/ponytail
/plugin install ponytail@ponytail
```

## addyosmani/agent-skills
https://github.com/addyosmani/agent-skills

```
npx skills add addyosmani/agent-skills
```

## morluto/rea
https://github.com/morluto/rea

```
npx rea-agents setup
```

## Graphify-Labs/graphify
https://github.com/Graphify-Labs/graphify

```
uv tool install graphifyy
```

## Panniantong/Agent-Reach
https://github.com/Panniantong/Agent-Reach

```
Instálame Agent Reach siguiendo https://raw.githubusercontent.com/Panniantong/Agent-Reach/main/docs/install.md
```

## Egonex-AI/Understand-Anything
https://github.com/Egonex-AI/Understand-Anything

```
/plugin marketplace add Egonex-AI/Understand-Anything
/plugin install understand-anything
```

## career-ops-hq/career-ops
https://github.com/career-ops-hq/career-ops

```
npx @santifer/career-ops init
```

## mvanhorn/last30days-skill
https://github.com/mvanhorn/last30days-skill

```
/plugin marketplace add mvanhorn/last30days-skill
/plugin install last30days
```

## garrytan/gstack
https://github.com/garrytan/gstack

```
git clone --single-branch --depth 1 https://github.com/garrytan/gstack.git ~/.claude/skills/gstack && cd ~/.claude/skills/gstack && ./setup
```

## JuliusBrussee/caveman
https://github.com/JuliusBrussee/caveman

```
/plugin marketplace add JuliusBrussee/caveman
/plugin install caveman@caveman
```

## thedotmack/claude-mem
https://github.com/thedotmack/claude-mem

```
npx claude-mem install
```

## headroomlabs-ai/headroom
https://github.com/headroomlabs-ai/headroom

```
pip install "headroom-ai[all]"
```

## open-gsd/gsd-core
https://github.com/open-gsd/gsd-core

```
npx @opengsd/gsd-core@latest
```

## bmad-code-org/BMAD-METHOD
https://github.com/bmad-code-org/BMAD-METHOD

```
npx bmad-method install
```

## nextlevelbuilder/ui-ux-pro-max-skill
https://github.com/nextlevelbuilder/ui-ux-pro-max-skill

```
/plugin marketplace add nextlevelbuilder/ui-ux-pro-max-skill
/plugin install ui-ux-pro-max@ui-ux-pro-max-skill
```

## Leonxlnx/taste-skill
https://github.com/Leonxlnx/taste-skill

```
/plugin marketplace add Leonxlnx/taste-skill
/plugin install taste-skill@taste-skill
```

## tt-a1i/archify
https://github.com/tt-a1i/archify

```
npx -y skills@latest add https://archify.si --skill archify --agent claude-code --global --copy --yes
```

## pbakaus/impeccable
https://github.com/pbakaus/impeccable

```
npx impeccable install
```

## hugohe3/ppt-master
https://github.com/hugohe3/ppt-master

```
git clone https://github.com/hugohe3/ppt-master.git && cd ppt-master && pip install -r requirements.txt
```

## cathrynlavery/diagram-design
https://github.com/cathrynlavery/diagram-design

```
/plugin marketplace add cathrynlavery/diagram-design
/plugin install diagram-design@diagram-design
```

## anthropics/skills
https://github.com/anthropics/skills

```
/plugin marketplace add anthropics/skills
/plugin install document-skills@anthropic-agent-skills
```

## OpenMontageInc/OpenMontage
https://github.com/OpenMontageInc/OpenMontage

```
git clone https://github.com/OpenMontageInc/OpenMontage.git && cd OpenMontage && make setup
```

## heygen-com/hyperframes
https://github.com/heygen-com/hyperframes

```
npx skills add heygen-com/hyperframes
```

## blader/humanizer
https://github.com/blader/humanizer

```
/plugin marketplace add blader/humanizer
/plugin install humanizer@humanizer
```

## ayghri/i-have-adhd
https://github.com/ayghri/i-have-adhd

```
claude plugin marketplace add ayghri/i-have-adhd
claude plugin install i-have-adhd@i-have-adhd
```

## coreyhaines31/marketingskills
https://github.com/coreyhaines31/marketingskills

```
/plugin marketplace add coreyhaines31/marketingskills
/plugin install marketing-skills
```

