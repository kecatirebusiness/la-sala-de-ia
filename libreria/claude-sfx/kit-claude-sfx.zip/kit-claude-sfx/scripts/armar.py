import json,subprocess,os,sys
FF=os.path.expanduser("~/Library/Python/3.9/lib/python/site-packages/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1")
SRC="TU-VIDEO.mp4"; VOZ="src/df/kevin48k_DeepFilterNet3.wav"
GR="crop=2160:2160:690:0,scale=1080:1080:flags=lanczos,curves=all='0/0 0.10/0.045 0.28/0.33 0.52/0.66 0.78/0.89 1/1',eq=saturation=1.28,colorbalance=rm=0.05:bm=-0.06:rs=0.015:bs=-0.02,unsharp=5:5:0.45"
E=json.load(open('edl.json')); os.makedirs('pz',exist_ok=True)
only=sys.argv[1] if len(sys.argv)>1 else None
lst=[]
for k,p in enumerate(E):
    d=p['n']/30; v=f"pz/v{k:02d}.mp4"; a=f"pz/a{k:02d}.wav"
    if only=="test" and k!=0: continue
    subprocess.run([FF,"-nostdin","-v","error","-y","-ss",f"{p['s']:.4f}","-i",SRC,"-t",f"{d+0.2:.4f}","-an","-vf",GR+",fps=30","-frames:v",str(p['n']),
        "-c:v","h264_videotoolbox","-b:v","18M","-pix_fmt","yuv420p",v],check=True)
    subprocess.run([FF,"-nostdin","-v","error","-y","-ss",f"{p['s']:.4f}","-i",VOZ,"-t",f"{d:.4f}","-af",f"afade=t=in:d=0.012,afade=t=out:st={d-0.015:.4f}:d=0.015","-ar","48000","-ac","1",a],check=True)
    lst.append((v,a)); print(k,p['lab'],p['n'],flush=True)
if only!="test":
    open('pz/v.txt','w').write("".join(f"file '{os.path.basename(v)}'\n" for v,a in lst))
    open('pz/a.txt','w').write("".join(f"file '{os.path.basename(a)}'\n" for v,a in lst))
    subprocess.run([FF,"-v","error","-y","-f","concat","-safe","0","-i","pz/v.txt","-c","copy","aroll_v.mp4"],check=True)
    subprocess.run([FF,"-v","error","-y","-f","concat","-safe","0","-i","pz/a.txt","-c:a","pcm_s16le","aroll_a_raw.wav"],check=True)
