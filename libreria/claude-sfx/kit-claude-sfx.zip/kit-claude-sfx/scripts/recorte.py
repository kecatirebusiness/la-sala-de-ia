# recorte_vision.py IN OUT.webm : person matte with Apple Vision (VNGeneratePersonSegmentationRequest .accurate) -> VP9 alpha webm
import sys, subprocess, numpy as np, threading, time
FF="ffmpeg"
VM="./vmask"  # recortador de persona con Apple Vision (pídele a Claude Code que lo compile)
IN,OUT=sys.argv[1],sys.argv[2]; W,H=1080,1080; N=W*H*4
rd=subprocess.Popen([FF,'-v','error','-i',IN,'-f','rawvideo','-pix_fmt','bgra','-'],stdout=subprocess.PIPE)
vm=subprocess.Popen([VM,'person',str(W),str(H)],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
wr=subprocess.Popen([FF,'-v','error','-y','-f','rawvideo','-pix_fmt','bgra','-s',f'{W}x{H}','-r','30','-i','-','-c:v','libvpx-vp9','-pix_fmt','yuva420p','-b:v','0','-crf','28','-deadline','good','-cpu-used','4','-row-mt','1','-auto-alt-ref','0',OUT],stdin=subprocess.PIPE)
frames=[]
def feed():
    while True:
        b=rd.stdout.read(N)
        if len(b)<N: break
        frames.append(b); vm.stdin.write(b)
    vm.stdin.close()
threading.Thread(target=feed,daemon=True).start()
prev=None; i=0; t0=time.time()
while True:
    m=vm.stdout.read(W*H)
    if len(m)<W*H: break
    a=np.frombuffer(m,np.uint8).astype(np.float32)
    if prev is not None: a=0.8*a+0.2*prev   # tiny temporal steadiness
    prev=a
    f=np.frombuffer(frames[i],np.uint8).reshape(H,W,4).copy(); frames[i]=None
    f[...,3]=np.clip(a,0,255).astype(np.uint8).reshape(H,W)
    wr.stdin.write(f.tobytes()); i+=1
wr.stdin.close(); wr.wait()
print('frames',i,'fps',round(i/(time.time()-t0),1))
