import numpy as np, wave, json
S=json.load(open('src/segs2.json'))
wf=wave.open('src/clean16k.wav'); sr=16000
a=np.frombuffer(wf.readframes(wf.getnframes()),dtype=np.int16).astype(np.float32)/32768
hop=80; win=320
def db_at(t0,t1):
    i0=int(t0*sr); i1=int(t1*sr)
    n=(i1-i0-win)//hop
    return np.array([20*np.log10(np.sqrt(np.mean(a[i0+k*hop:i0+k*hop+win]**2))+1e-9) for k in range(n)])
THR=-62
# chosen takes: (label, seg index, optional word range)
PICK=[("hook",3),("suena",4),("hacerlo",11),("refs",12),("prompt",18),("genera",22),("importante",25),("conecta",26),("efectos",28),
      ("conectado",33),("artlist",34),("armarlo",40),("junta",41),("sincomp",42),("facil",43),("cta",54)]
MAXGAP=0.09; PRE=0.05; POST=0.07
pieces=[]
for lab,i in PICK:
    s=S[i]; t0=s['s']-0.15; t1=s['e']+0.2
    d=db_at(t0,t1); act=d>THR
    reg=[];st=None
    for k,v in enumerate(act):
        if v and st is None: st=k
        if not v and st is not None: reg.append([t0+st*hop/sr,t0+k*hop/sr]); st=None
    if st is not None: reg.append([t0+st*hop/sr,t0+len(act)*hop/sr])
    reg=[r for r in reg if r[1]-r[0]>0.04]
    m=[]
    for r in reg:
        if m and r[0]-m[-1][1]<0.22: m[-1][1]=r[1]
        else: m.append(r)
    # glue short pieces (<0.6s) to nearest neighbour
    ch=True
    while ch and len(m)>1:
        ch=False
        for k,r in enumerate(m):
            if r[1]-r[0]<0.6:
                if k==0: j=1
                elif k==len(m)-1: j=k-1
                else: j=k-1 if r[0]-m[k-1][1] <= m[k+1][0]-r[1] else k+1
                lo,hi=min(k,j),max(k,j); m[lo]=[m[lo][0],m[hi][1]]; del m[hi]; ch=True; break
    for r in m: pieces.append({"lab":lab,"seg":i,"s":round(r[0]-PRE,3),"e":round(r[1]+POST,3)})
    print(lab,i,s['text'][:50],"->",[(round(r[0],2),round(r[1],2)) for r in m])
# snap to 30fps frames
t=0
for p in pieces:
    n=round((p['e']-p['s'])*30); p['n']=n; p['e']=round(p['s']+n/30,4); p['t']=round(t/30,4); t+=n
json.dump(pieces,open('edl.json','w'),indent=1)
print(len(pieces),"pieces total",t/30,"s")
