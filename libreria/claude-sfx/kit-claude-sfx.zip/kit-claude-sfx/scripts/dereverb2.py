import pickle, numpy as np, wave, torch, warnings, json
warnings.filterwarnings('ignore')
from nara_wpe.wpe import wpe
from nara_wpe.utils import stft, istft
from df.enhance import enhance, init_df
segs,meta,sr=pickle.load(open('src/raw_pieces.pkl','rb'))
model, st, _ = init_df(post_filter=True)
def W(x):
    Y=stft(x[None], size=1024, shift=256).transpose(2,0,1)
    Z=wpe(Y, taps=18, delay=3, iterations=4, statistics_mode='full')
    z=istft(Z.transpose(1,2,0), size=1024, shift=256)[0][:len(x)]
    return np.pad(z,(0,max(0,len(x)-len(z))))
def D(z): return enhance(model, st, torch.from_numpy(z.astype(np.float32))[None], atten_lim_db=None)[0].numpy()
def env(x): 
    hop=int(sr*0.05); return np.array([20*np.log10(np.sqrt(np.mean(x[i:i+hop]**2))+1e-9) for i in range(0,len(x)-hop,hop)])
out=[]
for k,(s,(h,n)) in enumerate(zip(segs,meta)):
    x=s[:,0].astype(np.float64)
    a=D(W(x))[h:h+n]; b=D(x)[h:h+n]
    ea,eb=env(a),env(b); loud=eb>np.percentile(eb,60)
    off=np.median((ea-eb)[loud]); worst=((ea-eb)[loud]-off).min()
    use='wpe' if worst>-5 else 'df'
    e=(a if use=='wpe' else b).copy()
    # match level to the df-only version so pieces stay even
    e*=10**((np.median(eb[loud])-np.median(env(e)[loud]))/20)
    f=int(0.012*sr); e[:f]*=np.linspace(0,1,f); e[-f:]*=np.linspace(1,0,f)
    out.append(e); print(k,use,round(float(worst),1),flush=True)
v=np.concatenate(out)
w=wave.open('voz_dry_raw.wav','wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes((np.clip(v/np.abs(v).max()*0.5,-1,1)*32767).astype(np.int16).tobytes()); w.close()
