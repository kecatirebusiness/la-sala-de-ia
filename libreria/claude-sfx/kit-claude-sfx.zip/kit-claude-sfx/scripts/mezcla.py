import numpy as np, wave, json, subprocess, os
FF=os.path.expanduser("~/Library/Python/3.9/lib/python/site-packages/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1")
SR=48000; DUR=15.04
def load(n):
    w=wave.open(f'sfx/{n}.wav'); return np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).reshape(-1,2).astype(np.float32)/32768
# name, label, cat, t, src, dur, peak dB, fade in, fade out
CUES=[
 ("amb","Ambiente ciudad","amb",0,20,15.04,-25,0.3,0.5),
 ("steps","Pasos corriendo","foley",0.0,2.3,0.8,-11,0.01,0.08),
 ("whoosh","Whoosh salto","whoosh",0.15,0.65,1.5,-12,0.05,0.3),
 ("hood","Golpe capó","impact",1.0,0,0.7,-8,0.005,0.2),
 ("cloth","Ropa","foley",1.95,3.0,0.9,-17,0.03,0.15),
 ("door","Portazo","impact",2.65,0.25,1.0,-6,0.005,0.2),
 ("ignition","Encendido motor","veh",3.0,0.4,1.9,-9,0.02,0.4),
 ("shift","Palanca","foley",4.05,0.4,0.6,-11,0.005,0.1),
 ("burnout","Burnout","veh",4.5,0.3,1.6,-8,0.05,0.35),
 ("accel","Aceleración","veh",5.0,4.6,3.4,-7,0.3,0.5),
 ("passby","Whoosh pilares","whoosh",5.6,0.5,1.1,-12,0.02,0.3),
 ("siren","Sirena policía","veh",5.9,6.0,6.35,-10,0.6,0.25),
 ("bursts","Sirena toques","veh",6.85,0,1.2,-9,0.01,0.2),
 ("radio","Radio policía","amb2",8.3,0.6,2.0,-11,0.02,0.2),
 ("siren2","Sirena cerca","veh",9.2,2.0,3.0,-10,0.3,0.25),
 ("interior","Motor interior","veh",8.17,60,2.25,-10,0.05,0.15),
 ("shift","Cambio","foley",9.5,0,0.5,-11,0.005,0.1),
 ("drift","Derrape","veh",10.3,19.5,1.3,-9,0.15,0.2),
 ("crate1","Cajas madera","impact",11.3,0,1.0,-6,0.003,0.3),
 ("crate2","Astillas","foley",11.4,2.1,1.4,-10,0.005,0.3),
 ("water","Agua","impact",11.45,0.2,1.6,-10,0.01,0.5),
 ("boom","Sub impacto","whoosh",12.21,0,2.8,-5,0.003,0.8),
 ("crash","Choque barandal","impact",12.3,1.2,2.0,-7,0.003,0.5),
 ("glass","Vidrio","impact",12.45,0,1.5,-13,0.003,0.4),
 ("slowmo","Cámara lenta","whoosh",12.3,0.3,2.74,-9,0.1,0.6),
 ("debris","Escombros","foley",12.8,0.3,2.2,-15,0.1,0.5),
 ("heart","Latido","amb2",12.6,0,2.44,-10,0.01,0.3),
 ("braam","Braam","whoosh",13.3,0.5,1.74,-7,0.02,0.5),
]
mix=np.zeros((int(DUR*SR),2),np.float32); out=[]
rows={}  # track end times per cat
ORDER={"amb":[0],"veh":[1,2,3,10],"impact":[4,5],"foley":[6,7],"whoosh":[8,9],"amb2":[7]}
ends={}
for k,(n,lab,cat,t,src,d,pk,fi,fo) in enumerate(CUES):
    a=load(n)[int(src*SR):int((src+d)*SR)].copy()
    d=len(a)/SR
    a*=10**(pk/20)/(np.abs(a).max()+1e-9)
    ni=int(fi*SR); no=int(fo*SR)
    a[:ni]*=np.linspace(0,1,ni)[:,None]; a[-no:]*=np.linspace(1,0,no)[:,None]
    i0=int(t*SR); i1=min(len(mix),i0+len(a)); mix[i0:i1]+=a[:i1-i0]
    # peaks for the waveform
    m=np.abs(a).max(1); N=max(8,int(d*14)); 
    pkks=[float(m[int(j*len(m)/N):int((j+1)*len(m)/N)].max()) for j in range(N)]; mx=max(pkks)+1e-9
    tr=next((r for r in ORDER[cat] if ends.get(r,-1)<=t-0.05), ORDER[cat][-1]); ends[tr]=t+d
    out.append({"id":k,"label":lab,"cat":cat,"t":round(t,3),"d":round(min(d,DUR-t),3),"track":tr,"peaks":[round(max(0.06,p/mx),3) for p in pkks]})
mix=np.tanh(mix*1.15)*0.9
w=wave.open('film/sd_raw.wav','wb'); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes((mix*32767).astype(np.int16).tobytes()); w.close()
subprocess.run([FF,"-v","error","-y","-i","film/sd_raw.wav","-af","loudnorm=I=-15:TP=-1.5:LRA=14","-ar","48000","remo/public/film_sd.wav"],check=True)
json.dump(out,open('remo/src/sd.json','w'),ensure_ascii=False)
print(len(out),"clips; tracks",sorted(set(o['track'] for o in out)))
