import React from 'react';
import {AbsoluteFill, Img, interpolate, spring, staticFile, useCurrentFrame, continueRender, delayRender, Easing} from 'remotion';

export const FPS = 30;
export const C = {
  bg: '#0f0f10', card: '#0a0a0a', line: '#262626', text: '#f4f3ee', dim: '#8b8b86',
  claude: '#D97757', artlist: '#FFDA2A', hf: '#D1FE17', green: '#3ddc84',
};

// ---------- fuentes locales ----------
const FAM: Record<string, [string, string][]> = {
  Inter: [['300', 'Inter-normal-300'], ['500', 'Inter-normal-500'], ['700', 'Inter-normal-700']],
  InterTight: [['800', 'InterTight-normal-800'], ['900', 'InterTight-normal-900']],
  Mono: [['400', 'JetBrainsMono-normal-400'], ['700', 'JetBrainsMono-normal-700']],
  Serif: [['400', 'LibreBaskerville-normal-400'], ['700', 'LibreBaskerville-normal-700']],
  Grotesk: [['500', 'SpaceGrotesk-normal-500'], ['700', 'SpaceGrotesk-normal-700']],
  Poppins: [['500', 'Poppins-normal-500'], ['700', 'Poppins-normal-700']],
};
if (typeof document !== 'undefined') {
  for (const [fam, lista] of Object.entries(FAM)) {
    for (const [peso, archivo] of lista) {
      const h = delayRender(`font ${archivo}`);
      new FontFace(fam, `url(${staticFile(`fonts/${archivo}.woff2`)}) format('woff2')`, {weight: peso}).load()
        .then((f) => { (document.fonts as any).add(f); continueRender(h); })
        .catch(() => continueRender(h));
    }
  }
}
export const F = {ui: 'Inter, Helvetica, sans-serif', mono: 'Mono, Menlo, monospace', serif: 'Serif, Georgia, serif', grotesk: 'Grotesk, Inter, sans-serif', pop: 'Poppins, Inter, sans-serif', tight: 'InterTight, Inter, sans-serif'};

// ---------- helpers ----------
export const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
export const ease = Easing.bezier(0.22, 1, 0.36, 1);
export const ramp = (f: number, a: number, b: number, from = 0, to = 1) => interpolate(f, [a, b], [from, to], {...clamp, easing: ease});
export const pop = (f: number, at: number, cfg = {damping: 14, stiffness: 170, mass: 0.7}) => spring({frame: f - at, fps: FPS, config: cfg});
export const typed = (txt: string, f: number, a: number, b: number) => txt.slice(0, Math.round(interpolate(f, [a, b], [0, txt.length], clamp)));
// pseudo-aleatorio estable
export const rnd = (i: number) => { const x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };

export const Bg: React.FC = () => (
  <AbsoluteFill style={{background: C.bg}}>
    <AbsoluteFill style={{backgroundImage: 'radial-gradient(rgba(255,255,255,0.075) 1.6px, transparent 1.7px)', backgroundSize: '54px 54px', backgroundPosition: '27px 12px'}} />
    <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 35%, rgba(255,255,255,0.035), transparent 60%)'}} />
  </AbsoluteFill>
);

export const Cursor: React.FC<{x: number; y: number; s?: number; press?: number}> = ({x, y, s = 1, press = 0}) => (
  <svg width={46 * s} height={56 * s} viewBox="0 0 23 28" style={{position: 'absolute', left: x, top: y, transform: `scale(${1 - press * 0.16})`, transformOrigin: '0 0', filter: 'drop-shadow(0 4px 8px rgba(0,0,0,0.6))', zIndex: 50}}>
    <path d="M2 1.5 L2 22 L7.6 17.2 L11.4 26 L15 24.4 L11.3 15.8 L18.8 15.6 Z" fill="#111" stroke="#fff" strokeWidth="1.7" strokeLinejoin="round" />
  </svg>
);
// posición del cursor por tramos: [[frame,x,y],...]
export const path = (f: number, pts: [number, number, number][]) => {
  const fr = pts.map((p) => p[0]);
  return {x: interpolate(f, fr, pts.map((p) => p[1]), {...clamp, easing: Easing.inOut(Easing.cubic)}), y: interpolate(f, fr, pts.map((p) => p[2]), {...clamp, easing: Easing.inOut(Easing.cubic)})};
};
export const press = (f: number, at: number) => interpolate(f, [at - 2, at, at + 5], [0, 1, 0], clamp);

// ---------- logos ----------
export const Logo: React.FC<{src: string; h: number; style?: React.CSSProperties}> = ({src, h, style}) => <Img src={staticFile(`logos/${src}`)} style={{height: h, display: 'block', ...style}} />;

export const ArtlistTile: React.FC<{size: number}> = ({size}) => (
  <div style={{width: size, height: size, borderRadius: size * 0.16, background: '#1b1b1b', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: 'inset 0 0 0 1px rgba(255,255,255,0.06)'}}>
    <Logo src="artlist_icon.svg" h={size * 0.62} />
  </div>
);
export const HfTile: React.FC<{size: number}> = ({size}) => <Logo src="higgsfield_icon.svg" h={size} />;
export const Times: React.FC<{size?: number}> = ({size = 46}) => <div style={{fontFamily: F.ui, fontWeight: 700, color: C.text, fontSize: size, margin: '0 30px', lineHeight: 1}}>×</div>;

// cabecera "<tile> × Claude"
export const HeaderPair: React.FC<{left: React.ReactNode; f: number; at: number; y?: number}> = ({left, f, at, y = 232}) => {
  const p = pop(f, at);
  return (
    <div style={{position: 'absolute', top: y, left: 0, right: 0, display: 'flex', justifyContent: 'center', alignItems: 'center', opacity: ramp(f, at, at + 6), transform: `scale(${0.9 + 0.1 * p})`}}>
      {left}<Times /><Logo src="claude_white.svg" h={104} />
    </div>
  );
};

// tarjeta oscura tipo composer
export const Card: React.FC<{x: number; y: number; w: number; h: number; children?: React.ReactNode; glow?: string; r?: number; style?: React.CSSProperties}> = ({x, y, w, h, children, glow, r = 34, style}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: r, background: C.card, boxShadow: glow ? `0 0 0 3px ${glow}, 0 0 46px ${glow}88` : `0 0 0 2.5px ${C.line}, 0 30px 80px rgba(0,0,0,0.55)`, overflow: 'hidden', ...style}}>{children}</div>
);
export const SendBtn: React.FC<{x: number; y: number; press?: number}> = ({x, y, press: pr = 0}) => (
  <div style={{position: 'absolute', left: x, top: y, width: 60, height: 60, borderRadius: 14, background: C.claude, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${1 - pr * 0.14})`, boxShadow: pr > 0.2 ? `0 0 30px ${C.claude}` : 'none'}}>
    <svg width="30" height="30" viewBox="0 0 24 24"><path d="M12 19V6M6 11l6-6 6 6" stroke="#fff" strokeWidth="2.6" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
  </div>
);

// forma de onda dentro de un clip o fila
export const Wave: React.FC<{w: number; h: number; seed: number; color: string; n?: number; peaks?: number[]}> = ({w, h, seed, color, n, peaks}) => {
  const N = peaks ? peaks.length : (n ?? Math.max(6, Math.round(w / 5)));
  const bw = w / N;
  return (
    <svg width={w} height={h} style={{display: 'block'}}>
      {Array.from({length: N}).map((_, i) => {
        const v = peaks ? peaks[i] : Math.max(0.08, (0.25 + 0.75 * rnd(seed * 31 + i)) * (0.55 + 0.45 * Math.sin((i / N) * Math.PI)) * (0.6 + 0.4 * rnd(seed + i * 7)));
        const bh = Math.max(1.5, v * h);
        return <rect key={i} x={i * bw} y={(h - bh) / 2} width={Math.max(1, bw * 0.72)} height={bh} rx={0.6} fill={color} />;
      })}
    </svg>
  );
};
