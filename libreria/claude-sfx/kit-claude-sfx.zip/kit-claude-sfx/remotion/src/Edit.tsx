import React from 'react';
import {AbsoluteFill, Audio, Img, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {Bg, C, Card, Cursor, F, HeaderPair, HfTile, ArtlistTile, Logo, SendBtn, Wave, clamp, path, pop, press, ramp, rnd, typed} from './kit';
import SD from './sd.json';
import WORDS from './words.json';

// ---------- tiempos ----------
const HOOK_END = 218;          // fin de "pues sonaría algo así" (frames de voz)
const FILM_END = 450;          // la película dura 15 s
const OFF = FILM_END - HOOK_END;
const VO_FRAMES = 1507;
export const TOTAL = VO_FRAMES + OFF;
const v = (t: number) => Math.round(OFF + t * 30);   // tiempo de voz (s) -> frame, para todo lo que va después de la película

type Clip = {id: number; label: string; cat: string; t: number; d: number; track: number; peaks: number[]};
const CLIPS = SD as Clip[];
const COL: Record<string, {bg: string; fg: string}> = {
  amb: {bg: '#3a3833', fg: '#d8d2c2'}, veh: {bg: '#2c4a2a', fg: '#a9d79b'}, impact: {bg: '#5b2925', fg: '#f2a89c'},
  foley: {bg: '#584818', fg: '#edd47c'}, whoosh: {bg: '#482d4c', fg: '#d9a8de'}, amb2: {bg: '#4a2a24', fg: '#e8b0a0'},
};
const EN: Record<string, string> = {
  'Ambiente ciudad': 'City ambience', 'Pasos corriendo': 'Running steps', 'Whoosh salto': 'Jump whoosh', 'Golpe capó': 'Hood hit', 'Ropa': 'Cloth movement',
  'Portazo': 'Door slam', 'Encendido motor': 'Engine start', 'Palanca': 'Gear shift', 'Burnout': 'Tyre burnout', 'Aceleración': 'Acceleration', 'Whoosh pilares': 'Pass-by whoosh',
  'Sirena policía': 'Police siren', 'Motor interior': 'Engine interior', 'Cambio': 'Shift click', 'Derrape': 'Tyre skid', 'Cajas madera': 'Crate smash', 'Astillas': 'Wood splinter',
  'Agua': 'Water burst', 'Sub impacto': 'Sub impact', 'Choque barandal': 'Car crash', 'Vidrio': 'Breaking glass', 'Cámara lenta': 'Slow motion', 'Escombros': 'Falling debris', 'Latido': 'Heartbeat', 'Braam': 'Braam', 'Sirena toques': 'Siren bursts', 'Radio policía': 'Police radio', 'Sirena cerca': 'Siren close',
};
const CATEN: Record<string, string> = {amb: 'Ambience', veh: 'Vehicles', impact: 'Impacts', foley: 'Foley', whoosh: 'Whooshes', amb2: 'Foley'};

// transición de escena: entra/sale con blur
const Scene: React.FC<{from: number; to: number; children: React.ReactNode; inn?: number; out?: number}> = ({from, to, children, inn = 6, out = 5}) => {
  const f = useCurrentFrame();
  if (f < from - 1 || f > to + 1) return null;
  const a = Math.min(interpolate(f, [from, from + inn], [0, 1], clamp), interpolate(f, [to - out, to], [1, 0], clamp));
  return <AbsoluteFill style={{opacity: a, filter: a < 1 ? `blur(${(1 - a) * 16}px)` : undefined, transform: `scale(${0.965 + 0.035 * a})`}}>{children}</AbsoluteFill>;
};

// ---------- clip de timeline ----------
const ClipBox: React.FC<{c: Clip; x: number; y: number; w: number; h: number; label?: boolean; fs?: number; flash?: number}> = ({c, x, y, w, h, label = true, fs = 15, flash = 0}) => {
  const col = COL[c.cat];
  return (
    <div style={{position: 'absolute', left: x, top: y, width: w, height: h, background: flash > 0.5 ? '#fff' : col.bg, borderRadius: 4, overflow: 'hidden', boxShadow: flash > 0.05 ? `0 0 ${30 * flash}px rgba(255,255,255,${flash})` : 'inset 0 0 0 1px rgba(255,255,255,0.08)'}}>
      {label && <div style={{position: 'absolute', left: 6, top: 2, fontFamily: F.ui, fontWeight: 700, fontSize: fs, color: '#fff', whiteSpace: 'nowrap', opacity: flash > 0.5 ? 0 : 1}}>{c.label}</div>}
      <div style={{position: 'absolute', left: 4, top: label ? fs + 4 : 3, opacity: flash > 0.5 ? 0 : 1}}><Wave w={Math.max(4, w - 8)} h={h - (label ? fs + 8 : 6)} seed={c.id} color={col.fg} peaks={c.peaks} /></div>
    </div>
  );
};
const Tag: React.FC<{x: number; y: number; a: number}> = ({x, y, a}) => (
  <div style={{position: 'absolute', left: x, top: y, opacity: a, zIndex: 20}}>
    <svg width="26" height="26" viewBox="0 0 24 24" style={{position: 'absolute', left: -20, top: -18}}><path d="M3 3l7 17 2.5-7L20 10z" fill={C.claude} stroke="#fff" strokeWidth="1.4" strokeLinejoin="round" /></svg>
    <div style={{background: '#b3261e', color: '#fff', fontFamily: F.ui, fontWeight: 700, fontSize: 21, padding: '4px 12px', borderRadius: 7, whiteSpace: 'nowrap', boxShadow: '0 4px 14px rgba(0,0,0,0.5)'}}>Claude SFX</div>
  </div>
);

// timeline grande del gancho: se desplaza con la película y Claude va "poniendo" cada sonido
const BigTimeline: React.FC<{f: number}> = ({f}) => {
  const T = f / 30, PX = 150, PH = 650, TOP = 1128, RH = 62, LEAD = 1.5;
  return (
    <div style={{position: 'absolute', left: 0, top: 1110, width: 1080, height: 810, overflow: 'hidden'}}>
      <div style={{position: 'absolute', left: 0, top: 0, width: 1080, height: 12, background: '#1c1c1d'}} />
      {Array.from({length: 11}).map((_, i) => <div key={i} style={{position: 'absolute', left: 0, top: TOP - 1110 + i * RH - 4, width: 1080, height: RH - 6, background: i % 2 ? 'rgba(255,255,255,0.012)' : 'rgba(0,0,0,0.25)'}} />)}
      {CLIPS.map((c, i) => {
        const ap = Math.max(i * 0.09, c.t - LEAD) * 30;     // frame en el que Claude lo coloca
        if (f < ap) return null;
        const x = PH + (c.t - T) * PX, w = Math.max(40, c.d * PX);
        if (x > 1090 || x + w < -10) return null;
        const fl = interpolate(f, [ap, ap + 3, ap + 9], [1, 1, 0], clamp);
        const y = TOP - 1110 + c.track * RH;
        return (
          <React.Fragment key={i}>
            <ClipBox c={c} x={x} y={y} w={w} h={RH - 14} flash={fl} />
            <Tag x={Math.min(900, Math.max(40, x + 34))} y={y + 26} a={interpolate(f, [ap, ap + 2, ap + 13, ap + 17], [0, 1, 1, 0], clamp)} />
          </React.Fragment>
        );
      })}
      <div style={{position: 'absolute', left: PH - 1.5, top: 0, width: 3, height: 810, background: '#4a90ff'}} />
      <div style={{position: 'absolute', left: PH - 9, top: -2, width: 18, height: 20, background: '#4a90ff', borderRadius: '4px 4px 9px 9px'}} />
    </div>
  );
};

// subtítulo del gancho, sincronizado palabra por palabra
const HOT = /claude|grande|mundo|así/i;
const chunks = (() => {
  const ws = (WORDS as {w: string; s: number; e: number}[]).filter((w) => w.s < 7.25);
  const out: {a: number; b: number; ws: string[]}[] = [];
  let cur: typeof out[0] | null = null;
  for (const w of ws) {
    const fresh = !cur || cur.ws.length >= 3 || cur.ws.join(' ').length + w.w.length > 17 || /[?.,]$/.test(cur.ws[cur.ws.length - 1]);
    if (fresh) { cur = {a: w.s, b: w.e, ws: [w.w]}; out.push(cur); } else { cur!.ws.push(w.w); cur!.b = w.e; }
  }
  out.forEach((c, i) => { c.b = i + 1 < out.length ? out[i + 1].a : c.b + 0.25; });
  return out;
})();
const HookCaption: React.FC<{f: number}> = ({f}) => {
  const t = f / 30, c = chunks.find((k) => t >= k.a && t < k.b);
  if (!c) return null;
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: 1052, textAlign: 'center', fontFamily: F.mono, fontWeight: 700, fontSize: 31, letterSpacing: 4, color: C.text, textTransform: 'uppercase'}}>
      {c.ws.map((w, i) => <span key={i} style={{color: HOT.test(w) ? C.claude : C.text}}>{w.replace(/[¿?.,]/g, '')}{i < c.ws.length - 1 ? ' ' : ''}</span>)}
    </div>
  );
};

const Film: React.FC<{from?: number; y?: number; style?: React.CSSProperties; rate?: number; w?: number}> = ({from = 0, y = 432, style, rate = 1, w = 1080}) => (
  <div style={{position: 'absolute', left: (1080 - w) / 2, top: y, width: w, height: w * 9 / 16, overflow: 'hidden', background: '#000', ...style}}>
    <OffthreadVideo src={staticFile('film.mp4')} startFrom={from} playbackRate={rate} muted style={{width: '100%', height: '100%', objectFit: 'cover'}} />
  </div>
);

// ---------- 1. GANCHO + PELÍCULA ----------
const Hook: React.FC = () => {
  const f = useCurrentFrame();
  const out = ramp(f, 204, 222);
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', top: 226, left: 0, right: 0, display: 'flex', justifyContent: 'center', alignItems: 'center', opacity: ramp(f, 0, 5)}}>
        <Logo src="artlist_white.svg" h={58} />
        <div style={{fontFamily: F.ui, fontWeight: 700, color: C.text, fontSize: 30, margin: '0 16px'}}>×</div>
        <Logo src="claude_spark.svg" h={58} />
      </div>
      <div style={{position: 'absolute', top: 290, left: 0, right: 0, textAlign: 'center', fontFamily: F.serif, fontWeight: 700, fontSize: 108, letterSpacing: -3, lineHeight: 1.1, transform: `scale(${0.94 + 0.06 * pop(f, 1)})`}}>
        <span style={{color: C.claude}}>Claude</span> <span style={{color: '#fff'}}>SFX</span>
      </div>
      <Sequence from={0} durationInFrames={FILM_END} layout="none"><Film /></Sequence>
      <HookCaption f={f} />
      <BigTimeline f={f} />
      {f < 224 && (
        <div style={{position: 'absolute', left: -50, top: 740 + out * 1250, width: 1180, height: 1180, filter: 'drop-shadow(0 0 40px rgba(0,0,0,0.75))'}}>
          <OffthreadVideo src={staticFile('cutout.webm')} transparent muted style={{width: '100%', height: '100%'}} />
        </div>
      )}
    </AbsoluteFill>
  );
};

// ---------- presentador en tarjeta (cabeza sale del marco) ----------
const BOX = 1100, BX = -10, BY = 820, CX = 123, CY = 1200, CW = 834;
const Host: React.FC = () => {
  const f = useCurrentFrame();   // relativo a FILM_END
  const up = (1 - pop(f, 0, {damping: 16, stiffness: 120, mass: 0.8})) * 820;
  return (
    <AbsoluteFill style={{transform: `translateY(${up}px)`}}>
      <div style={{position: 'absolute', left: CX, top: CY, width: CW, height: 1920 - CY + 60, borderRadius: 54, overflow: 'hidden', boxShadow: '0 0 0 2px rgba(255,255,255,0.08), 0 -20px 80px rgba(0,0,0,0.6)'}}>
        <OffthreadVideo src={staticFile('aroll.mp4')} startFrom={HOOK_END} muted style={{position: 'absolute', left: BX - CX, top: BY - CY, width: BOX, height: BOX}} />
      </div>
      <div style={{position: 'absolute', left: CX, top: CY - 200, width: CW, height: 200, overflow: 'hidden'}}>
        <OffthreadVideo src={staticFile('cutout.webm')} startFrom={HOOK_END} transparent muted style={{position: 'absolute', left: BX - CX, top: BY - (CY - 200), width: BOX, height: BOX}} />
      </div>
    </AbsoluteFill>
  );
};

// ---------- 2. CLAUDE: ideas + referencias -> prompt ----------
const MSG = 'Usa estas cuatro referencias para escribir un prompt de Seedance 2.5 de una persecución de cine al atardecer. Abre conmigo corriendo hacia mi muscle car negro bajo el puente; me persiguen dos patrullas y termino saltando al mar. Mantén la calle, la luz y la dirección de pantalla en cada corte.';
const REFS = ['ref_street.jpg', 'ref_police.jpg', 'ref_car.jpg', 'ref_kevin.jpg'];
const PROMPT = [
  'SCENE CONTEXT',
  'A 15-second high-octane getaway through a tropical coastal city at golden hour. KEVIN sprints to his parked muscle car under a concrete highway overpass, launches it down the street with two police cruisers chasing, and sends it off the end of a waterfront road into the bay.',
  '',
  'ACTIVE REFERENCES',
  '@image1 = KEVIN: wavy dark brown hair, light stubble, thin gold chain, black t-shirt. Face 100% matches the reference.',
  '@image2 = KEVIN\'S CAR: 1970s matte-black muscle coupe with two emerald-green racing stripes and a hood scoop.',
  '@image3 = THE POLICE CARS: black-and-white sedans, light bars flashing red and blue.',
  '@image4 = THE STREET: the road under the overpass, palms and the bay in the distance.',
  '',
  'FORMAT MODE',
  'Timed multishot, 7 shots, HARD CUTs only at the stated seconds.',
  '0.0s to 2.0s — Low wide tracking shot. KEVIN sprints to the car and slides across the hood.',
];
const Hi: React.FC<{on: number; children: React.ReactNode}> = ({on, children}) => <span style={{background: `rgba(255,196,0,${0.9 * on})`, color: on > 0.5 ? '#111' : 'inherit', borderRadius: 4, padding: '0 3px', fontWeight: on > 0.5 ? 700 : 400}}>{children}</span>;
const ChatPrompt: React.FC = () => {
  const f = useCurrentFrame();
  const A = v(7.45), IMG0 = v(10.15), TXT2 = v(12.2), HL = v(13.46), SEND = v(14.35), OUT = SEND + 6;
  const txt = typed(MSG, f, A, IMG0 - 4);
  const inImgs = f >= IMG0 && f < TXT2;
  const hl = ramp(f, HL, HL + 5);
  const k = txt.indexOf('prompt de Seedance 2.5');
  const cardOut = ramp(f, OUT, OUT + 6);
  const cur = path(f, [[SEND - 16, 700, 1000], [SEND - 3, 912, 930]]);
  return (
    <AbsoluteFill>
      <HeaderPair left={<HfTile size={112} />} f={f} at={FILM_END} />
      <div style={{opacity: 1 - cardOut, filter: cardOut > 0 ? `blur(${cardOut * 14}px)` : undefined, transform: `scale(${1 + cardOut * 0.04})`}}>
        <Card x={90} y={430} w={900} h={590}>
          {f < A + 2 && <div style={{position: 'absolute', left: 34, top: 30, fontFamily: F.serif, fontSize: 28, color: '#5c5c58'}}>Escribe un mensaje…</div>}
          <div style={{position: 'absolute', left: 34, top: 28, width: 832, fontFamily: F.serif, fontSize: 29, lineHeight: 1.42, color: C.text, opacity: inImgs ? 0.12 : 1}}>
            {k >= 0 && txt.length >= k + 22 ? <>{txt.slice(0, k)}<Hi on={hl}>prompt de Seedance 2.5</Hi>{txt.slice(k + 22)}</> : txt}
            {f < IMG0 - 2 && f % 14 < 8 && <span style={{color: C.claude}}>▍</span>}
          </div>
          {REFS.map((r, i) => {
            const at = IMG0 + i * 15;
            if (f < at) return null;
            const p = pop(f, at), sh = ramp(f, at + 9, at + 15);
            const W = interpolate(sh, [0, 1], [832, 150]), X = interpolate(sh, [0, 1], [34, 34 + i * 96]), Y = interpolate(sh, [0, 1], [60, 478]);
            return <Img key={r} src={staticFile(`refs/${r}`)} style={{position: 'absolute', left: X, top: Y, width: W, height: W * 9 / 16, objectFit: 'cover', borderRadius: 10, transform: `scale(${0.8 + 0.2 * p}) rotate(${(1 - sh) * 0 + sh * (i - 1.5) * 1.5}deg)`, opacity: p, boxShadow: '0 10px 30px rgba(0,0,0,0.6), 0 0 0 2px rgba(255,255,255,0.12)'}} />;
          })}
          <SendBtn x={812} y={500} press={press(f, SEND)} />
        </Card>
        {f > SEND - 18 && f < OUT + 4 && <Cursor x={cur.x} y={cur.y} press={press(f, SEND)} />}
      </div>
      {f >= OUT && (
        <div style={{position: 'absolute', left: 84, top: 430, width: 912, fontFamily: F.serif, fontSize: 25.5, lineHeight: 1.36, color: C.text}}>
          {PROMPT.map((l, i) => {
            const a = OUT + 2 + i * 1.6, on = ramp(f, a, a + 3), sweep = interpolate(f, [a, a + 5, a + 12], [0, 1, 0], clamp);
            return <div key={i} style={{opacity: on, minHeight: 14, background: `rgba(217,119,87,${sweep * 0.55})`, fontWeight: /^[A-Z ]+$/.test(l) ? 700 : 400, color: /^[A-Z ]+$/.test(l) ? C.claude : C.text}}>{l}</div>;
          })}
        </div>
      )}
    </AbsoluteFill>
  );
};

// ---------- 3. HIGGSFIELD: Seedance 2.5 -> Generate ----------
const Bars: React.FC = () => <Logo src="seedance.png" h={26} style={{opacity: 0.95}} />;
const HfGenerate: React.FC = () => {
  const f = useCurrentFrame();
  const S = v(15.6), OPEN = v(16.55), PICK = v(17.75), GEN = v(18.55), END = v(19.0);
  const open = f >= OPEN && f < PICK + 5, picked = f >= PICK;
  const z = interpolate(f, [OPEN - 6, OPEN + 6, GEN - 12, GEN + 2], [1, 1.42, 1.42, 1.3], clamp);
  const ox = interpolate(f, [PICK + 4, GEN - 4], [16, 88], clamp);
  const cur = path(f, [[S + 6, 760, 940], [OPEN - 3, 240, 968], [OPEN + 12, 330, 830], [PICK - 3, 350, 838], [PICK + 8, 400, 900], [GEN - 3, 872, 972]]);
  const chips = [['Calle', REFS[0]], ['Patrulla', REFS[1]], ['Muscle car', REFS[2]], ['Personaje', REFS[3]]];
  const glow = pop(f, PICK);
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', top: 236, left: 0, right: 0, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 22, transform: `scale(${0.9 + 0.1 * pop(f, S)})`, opacity: 1 - ramp(f, OPEN - 6, OPEN)}}>
        <Logo src="higgsfield_glyph.svg" h={104} />
        <div style={{fontFamily: F.grotesk, fontWeight: 700, fontSize: 104, color: '#fff', letterSpacing: -3, lineHeight: 1}}>Higgsfield</div>
      </div>
      <div style={{position: 'absolute', inset: 0, transform: `scale(${z})`, transformOrigin: `${ox}% 53%`}}>
        <Card x={70} y={440} w={940} h={620} r={30} style={{background: '#0c0c0d'}}>
          <div style={{position: 'absolute', left: 26, top: 24, display: 'flex', gap: 12, alignItems: 'center'}}>
            <div style={{color: '#777', fontFamily: F.ui, fontSize: 34, width: 30}}>+</div>
            {chips.map(([n, r]) => (
              <div key={n} style={{display: 'flex', alignItems: 'center', gap: 10, background: '#161617', border: '1.5px solid #29292b', borderRadius: 12, padding: '7px 14px 7px 7px'}}>
                <Img src={staticFile(`refs/${r}`)} style={{width: 62, height: 38, objectFit: 'cover', borderRadius: 6}} />
                <div style={{fontFamily: F.ui, fontWeight: 500, fontSize: 23, color: '#e8e8e6', whiteSpace: 'nowrap'}}>{n}</div>
              </div>
            ))}
          </div>
          <div style={{position: 'absolute', left: 30, top: 112, width: 880, fontFamily: F.ui, fontWeight: 500, fontSize: 25.5, lineHeight: 1.42, color: '#e4e4e1'}}>
            A 15-second high-octane getaway through a tropical coastal city at golden hour. KEVIN sprints to his parked muscle car under a concrete highway overpass, launches it down the street with two police cruisers chasing, and sends it off the end of a waterfront road into the bay, leaping clear in mid-air. Timed multishot, 7 shots, anamorphic prime character, oval bokeh, real motion blur, photoreal stunt cinematography.
          </div>
          <div style={{position: 'absolute', left: 26, top: 498, width: 888, height: 1.5, background: '#232325'}} />
          <div style={{position: 'absolute', left: 30, top: 524, height: 64, padding: '0 26px', borderRadius: 34, display: 'flex', alignItems: 'center', gap: 12, fontFamily: F.ui, fontWeight: 700, fontSize: 27,
            background: picked ? '#141500' : '#161617', color: picked ? C.hf : '#e8e8e6', boxShadow: picked ? `0 0 0 ${3 + glow}px ${C.hf}, 0 0 ${40 * glow}px ${C.hf}99` : '0 0 0 1.5px #2b2b2d', transform: `scale(${1 - press(f, OPEN) * 0.06})`}}>
            <span style={{fontSize: 24}}>{picked ? '✓' : '⌄'}</span>{picked ? 'Seedance 2.5' : 'Seleccionar modelo'}
          </div>
          <div style={{position: 'absolute', right: 30, top: 524, height: 64, padding: '0 34px', borderRadius: 34, display: 'flex', alignItems: 'center', background: '#f2f2f0', color: '#0b0b0b', fontFamily: F.ui, fontWeight: 700, fontSize: 27, transform: `scale(${1 - press(f, GEN) * 0.1})`, boxShadow: f >= GEN ? `0 0 ${interpolate(f, [GEN, GEN + 8], [0, 60], clamp)}px #fff` : 'none'}}>Generate</div>
          {open && (
            <div style={{position: 'absolute', left: 30, top: 196, width: 520, borderRadius: 18, background: '#121213', border: '1.5px solid #2a2a2c', padding: 14, boxShadow: '0 24px 60px rgba(0,0,0,0.8)', opacity: ramp(f, OPEN, OPEN + 4), transform: `translateY(${(1 - ramp(f, OPEN, OPEN + 5)) * 14}px)`}}>
              <div style={{height: 50, borderRadius: 12, border: '1.5px solid #2a2a2c', display: 'flex', alignItems: 'center', padding: '0 16px', fontFamily: F.ui, fontSize: 22, color: '#77777a'}}>Search all models</div>
              <div style={{fontFamily: F.ui, fontSize: 19, color: '#77777a', margin: '14px 6px 6px'}}>Recent</div>
              {['Kling 3.0', 'Seedance 2.5', 'Seedance 2.0'].map((m, i) => (
                <div key={m} style={{height: 60, borderRadius: 12, display: 'flex', alignItems: 'center', gap: 16, padding: '0 12px', background: i === 1 && f >= OPEN + 12 ? '#1f1f21' : 'transparent', fontFamily: F.ui, fontWeight: 700, fontSize: 26, color: '#f0f0ee'}}>
                  <div style={{width: 36, height: 36, borderRadius: 8, background: '#1b1b1d', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{i === 0 ? <span style={{color: '#aaa', fontSize: 22}}>◇</span> : <Bars />}</div>
                  {m}{i === 1 && f >= PICK && <span style={{marginLeft: 'auto', color: '#fff'}}>✓</span>}
                </div>
              ))}
            </div>
          )}
        </Card>
        {f > S + 4 && f < END && <Cursor x={cur.x} y={cur.y} press={Math.max(press(f, OPEN), press(f, PICK), press(f, GEN))} />}
      </div>
    </AbsoluteFill>
  );
};

// resultado generado: la película aparece con barrido
const Generated: React.FC<{from: number; to: number; start: number; tag: string}> = ({from, to, start, tag}) => {
  const f = useCurrentFrame();
  const w = ramp(f, from, from + 14);
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 0, top: 432, width: 1080 * w, height: 608, overflow: 'hidden'}}>
        <Sequence from={from} layout="none"><Film from={start} y={0} /></Sequence>
      </div>
      <div style={{position: 'absolute', left: 1080 * w - 3, top: 420, width: 4, height: 632, background: C.claude, opacity: w < 1 ? 1 : 0, boxShadow: `0 0 24px ${C.claude}`}} />
      <div style={{position: 'absolute', left: 0, top: 428, width: 1080, height: 2, background: C.claude, opacity: 0.6}} /><div style={{position: 'absolute', left: 0, top: 1042, width: 1080, height: 2, background: C.claude, opacity: 0.6}} />
      <div style={{position: 'absolute', left: 0, right: 0, top: 1066, textAlign: 'center', fontFamily: F.mono, fontWeight: 700, fontSize: 25, letterSpacing: 3, color: C.dim, opacity: ramp(f, from + 8, from + 14)}}>{tag}</div>
    </AbsoluteFill>
  );
};

// ---------- 4. CONECTOR MCP DE ARTLIST ----------
const Field: React.FC<{label: string; val: string; y: number; focus: boolean}> = ({label, val, y, focus}) => (
  <>
    <div style={{position: 'absolute', left: 36, top: y, fontFamily: F.ui, fontWeight: 500, fontSize: 25, color: '#a5a5a1'}}>{label}</div>
    <div style={{position: 'absolute', left: 36, top: y + 38, width: 708, height: 62, borderRadius: 10, background: '#050505', boxShadow: focus ? `0 0 0 2.5px ${C.claude}` : '0 0 0 1.5px #262626', display: 'flex', alignItems: 'center', padding: '0 18px', fontFamily: F.ui, fontWeight: 500, fontSize: 28, color: C.text}}>{val}{focus && <span style={{color: C.claude, marginLeft: 2}}>|</span>}</div>
  </>
);
const Connector: React.FC = () => {
  const f = useCurrentFrame();
  const S = v(20.8), N0 = v(21.0), N1 = v(21.8), U0 = v(21.95), U1 = v(23.5), CLK = v(23.9);
  const name = typed('Artlist', f, N0, N1), url = typed('https://mcp.artlist.io/mcp', f, U0, U1);
  const ok = f >= CLK + 2, g = pop(f, CLK + 2);
  const cur = path(f, [[U1 - 4, 560, 980], [CLK - 2, 700, 804]]);
  return (
    <AbsoluteFill>
      <HeaderPair left={<ArtlistTile size={112} />} f={f} at={S} />
      <Card x={150} y={450} w={780} h={440} r={22} glow={ok ? C.claude : undefined} style={{background: ok ? '#1a100d' : '#0b0b0b', transform: `scale(${1 + 0.03 * g * (ok ? 1 : 0)})`}}>
        <div style={{position: 'absolute', left: 36, top: 30, fontFamily: F.ui, fontWeight: 700, fontSize: 30, color: C.text}}>{ok ? 'Artlist connected' : 'Add custom connector'}</div>
        <div style={{position: 'absolute', right: 30, top: 26, fontFamily: F.ui, fontSize: 30, color: '#888'}}>×</div>
        <Field label="Name" val={name} y={92} focus={f >= N0 - 2 && f < U0 - 2} />
        <Field label="MCP server URL" val={url} y={212} focus={f >= U0 - 2 && f < CLK} />
        {!ok && <div style={{position: 'absolute', left: 36, top: 348, height: 60, padding: '0 28px', borderRadius: 10, boxShadow: '0 0 0 1.5px #333', display: 'flex', alignItems: 'center', fontFamily: F.ui, fontWeight: 500, fontSize: 26, color: C.text}}>Cancel</div>}
        {ok && <div style={{position: 'absolute', left: 40, top: 356, fontSize: 36, color: C.green, transform: `scale(${g})`}}>✓</div>}
        <div style={{position: 'absolute', right: 36, top: 348, height: 60, padding: '0 30px', borderRadius: 10, display: 'flex', alignItems: 'center', fontFamily: F.ui, fontWeight: 700, fontSize: 26, background: ok ? '#1f8f52' : '#f2f2f0', color: ok ? '#fff' : '#0b0b0b', transform: `scale(${1 - press(f, CLK) * 0.1})`}}>{ok ? 'Connected' : 'Connect'}</div>
      </Card>
      {f > U1 - 4 && f < CLK + 12 && <Cursor x={cur.x} y={cur.y} press={press(f, CLK)} />}
    </AbsoluteFill>
  );
};

// ---------- 5. LIBRERÍA DE EFECTOS ----------
const Library: React.FC<{from: number}> = ({from}) => {
  const f = useCurrentFrame();
  const sc = (f - from) * 3.4, RH = 92;
  const rows = [...CLIPS.slice(6), ...CLIPS, ...CLIPS];
  const act = Math.floor((f - from) / 9);
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', top: 232, left: 0, right: 0, display: 'flex', justifyContent: 'center', transform: `scale(${0.88 + 0.12 * pop(f, from)})`}}><Logo src="artlist.svg" h={112} /></div>
      <Card x={30} y={410} w={1020} h={700} r={28}>
        <div style={{position: 'absolute', left: 40, top: 30, fontFamily: F.ui, fontWeight: 700, fontSize: 52, color: '#fff', letterSpacing: -1}}>Sound effects</div>
        <div style={{position: 'absolute', right: 40, top: 44, padding: '6px 20px', borderRadius: 20, background: '#0f2a1b', color: '#5fe39a', fontFamily: F.ui, fontWeight: 700, fontSize: 21}}>Connected</div>
        <div style={{position: 'absolute', left: 40, top: 116, display: 'flex', gap: 54, fontFamily: F.ui, fontWeight: 500, fontSize: 24, color: '#7c7c79'}}>
          <span style={{color: '#fff', fontWeight: 700, borderBottom: `3px solid ${C.artlist}`, paddingBottom: 10}}>All sounds</span><span>Vehicles</span><span>Impacts</span><span>Foley</span>
        </div>
        <div style={{position: 'absolute', left: 30, top: 164, width: 960, height: 1.5, background: '#222'}} />
        <div style={{position: 'absolute', left: 0, top: 168, width: 1020, height: 532, overflow: 'hidden'}}>
          <div style={{position: 'absolute', top: -sc, left: 0, width: 1020}}>
            {rows.map((c, i) => {
              const on = i === act + 1 || i === act + 4;
              return (
                <div key={i} style={{height: RH, display: 'flex', alignItems: 'center', borderBottom: '1.5px solid #1b1b1b', margin: '0 40px'}}>
                  <div style={{width: 36, height: 36, borderRadius: 18, background: '#1b1b1c', marginRight: 22}} />
                  <div style={{width: 300}}>
                    <div style={{fontFamily: F.ui, fontWeight: 700, fontSize: 27, color: '#f2f2f0'}}>{EN[c.label] ?? c.label}</div>
                    <div style={{fontFamily: F.ui, fontWeight: 500, fontSize: 19, color: '#77777a'}}>{CATEN[c.cat]}</div>
                  </div>
                  <Wave w={400} h={44} seed={c.id + i} color={on ? C.artlist : '#55555a'} n={90} />
                  <div style={{width: 90, textAlign: 'right', fontFamily: F.ui, fontWeight: 500, fontSize: 22, color: '#8a8a87'}}>{c.d.toFixed(1)}s</div>
                  <svg width="30" height="30" viewBox="0 0 24 24" style={{marginLeft: 34}}><path d="M12 4v11m0 0l-4-4m4 4l4-4M5 20h14" stroke="#9a9a97" strokeWidth="1.8" fill="none" strokeLinecap="round" /></svg>
                </div>
              );
            })}
          </div>
        </div>
      </Card>
    </AbsoluteFill>
  );
};

// ---------- mini timeline dentro de la tarjeta ----------
const MiniTL: React.FC<{x: number; y: number; w: number; h: number; f: number; start: number; play?: number; rows?: number}> = ({x, y, w, h, f, start, play = -1}) => {
  const RH = h / 11, PX = (w - 46) / 15.04;
  return (
    <div style={{position: 'absolute', left: x, top: y, width: w, height: h, background: '#0d130d', overflow: 'hidden'}}>
      {Array.from({length: 11}).map((_, i) => (
        <div key={i} style={{position: 'absolute', left: 0, top: i * RH, width: w, height: RH - 2, background: i % 2 ? 'rgba(255,255,255,0.02)' : 'transparent'}}>
          <svg width="18" height="18" viewBox="0 0 24 24" style={{position: 'absolute', left: 12, top: RH / 2 - 10}}><path d="M4 9v6h4l5 4V5L8 9z" fill="#8a8a87" /></svg>
        </div>
      ))}
      {CLIPS.map((c, i) => {
        const at = start + i * 3;
        if (f < at) return null;
        const fl = interpolate(f, [at, at + 2, at + 7], [1, 1, 0], clamp);
        return <ClipBox key={i} c={c} x={42 + c.t * PX} y={c.track * RH + 2} w={Math.max(10, c.d * PX)} h={RH - 6} fs={11} label={c.d * PX > 70} flash={fl} />;
      })}
      {play >= 0 && <div style={{position: 'absolute', left: 42 + Math.min(15.04, play) * PX, top: 0, width: 3, height: h, background: C.artlist, boxShadow: `0 0 12px ${C.artlist}`}} />}
    </div>
  );
};

// ---------- 6. PEDIR EL DISEÑO DE SONIDO ----------
const ASK = 'Haz todo el diseño de sonido de este video con la librería de efectos de Artlist.';
const AskSound: React.FC = () => {
  const f = useCurrentFrame();
  const S = v(28.05), T0 = v(29.35), T1 = v(31.45), G = v(31.75);
  const sh = ramp(f, S + 16, S + 26);
  const W = interpolate(sh, [0, 1], [832, 132]), X = interpolate(sh, [0, 1], [34, 34]), Y = interpolate(sh, [0, 1], [50, 482]);
  const txt = typed(ASK, f, T0, T1);
  return (
    <AbsoluteFill>
      <HeaderPair left={<ArtlistTile size={112} />} f={f} at={S} />
      <Card x={90} y={430} w={900} h={590}>
        <div style={{position: 'absolute', left: 34, top: 28, width: 832, fontFamily: F.ui, fontWeight: 500, fontSize: 31, lineHeight: 1.38, color: C.text}}>{txt}{f > T0 && f < T1 + 6 && f % 14 < 8 && <span style={{color: C.claude}}>▍</span>}</div>
        <div style={{position: 'absolute', left: 34, top: 132, width: 832, display: 'flex', flexWrap: 'wrap', gap: 7}}>
          {CLIPS.map((c, i) => {
            const at = G + i * 2.4;
            if (f < at) return null;
            const p = pop(f, at), col = COL[c.cat];
            return (
              <div key={i} style={{width: 158, height: 50, borderRadius: 7, background: col.bg, position: 'relative', transform: `scale(${0.6 + 0.4 * p})`, opacity: p, overflow: 'hidden'}}>
                <div style={{position: 'absolute', left: 7, top: 3, fontFamily: F.ui, fontWeight: 700, fontSize: 14, color: '#fff', whiteSpace: 'nowrap'}}>{c.label}</div>
                <div style={{position: 'absolute', left: 7, top: 22}}><Wave w={112} h={23} seed={c.id} color={col.fg} peaks={c.peaks.slice(0, 28)} /></div>
                <div style={{position: 'absolute', right: 6, top: 15, width: 21, height: 21, borderRadius: 5, background: C.artlist, color: '#111', fontSize: 16, fontWeight: 900, textAlign: 'center', lineHeight: '21px', transform: `scale(${pop(f, at + 4)})`}}>✓</div>
              </div>
            );
          })}
        </div>
        <div style={{position: 'absolute', left: X, top: Y, width: W, height: W * 9 / 16, borderRadius: 10, overflow: 'hidden', opacity: ramp(f, S, S + 5), boxShadow: '0 0 0 2px rgba(255,255,255,0.14)'}}>
          <Sequence from={S} layout="none"><OffthreadVideo src={staticFile('film.mp4')} startFrom={150} muted style={{width: '100%', height: '100%', objectFit: 'cover'}} /></Sequence>
        </div>
        <SendBtn x={812} y={500} press={press(f, T1 + 6)} />
      </Card>
    </AbsoluteFill>
  );
};

// ---------- 7. CLAUDE LO ARMA TODO ----------
const Assemble: React.FC = () => {
  const f = useCurrentFrame();
  const S = v(34.13), J = v(37.5), X1 = v(41.4), END = v(42.47);
  const j = ramp(f, J, J + 14);
  const play = f >= J + 10 ? (f - J - 10) / 30 * 3.6 : f > S + 84 ? (f - S - 84) / 30 * 7 : -1;
  const filmH = 427 * j;
  const ex = pop(f, X1);
  return (
    <AbsoluteFill>
      <HeaderPair left={<ArtlistTile size={112} />} f={f} at={0} />
      <Card x={90} y={420} w={900} h={670}>
        <div style={{position: 'absolute', left: 34, top: 22, fontFamily: F.ui, fontWeight: 500, fontSize: 34, color: C.text}}>{Math.min(CLIPS.length, Math.max(0, Math.floor((f - S) / 3)))} sonidos seleccionados</div>
        <div style={{position: 'absolute', left: 70, top: 84, width: 760, height: filmH, overflow: 'hidden', borderRadius: 8, opacity: j}}>
          <Sequence from={J} layout="none"><OffthreadVideo src={staticFile('film.mp4')} startFrom={0} playbackRate={3.6} muted style={{width: 760, height: 427, objectFit: 'cover'}} /></Sequence>
        </div>
        <MiniTL x={24} y={84 + filmH + (j > 0 ? 10 : 0)} w={852} h={interpolate(j, [0, 1], [470, 72])} f={f} start={S + 2} play={play} />
        <div style={{position: 'absolute', left: 34, top: 610, display: 'flex', alignItems: 'center', gap: 12, fontFamily: F.mono, fontWeight: 700, fontSize: 22, color: C.dim}}>
          <Logo src="claude_spark.svg" h={26} /> Claude Code · editando
        </div>
        <SendBtn x={812} y={594} />
      </Card>
      {f >= X1 && (
        <div style={{position: 'absolute', left: 0, right: 0, top: 716, display: 'flex', justifyContent: 'center', transform: `scale(${0.7 + 0.3 * ex})`, opacity: Math.min(1, ex * 1.4) * (1 - ramp(f, END - 5, END))}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 18, padding: '22px 40px', borderRadius: 60, background: '#0e2318', boxShadow: `0 0 0 3px ${C.green}, 0 0 60px ${C.green}66`, fontFamily: F.ui, fontWeight: 700, fontSize: 40, color: '#fff'}}>
            <span style={{color: C.green}}>✓</span> video-final.mp4
          </div>
        </div>
      )}
    </AbsoluteFill>
  );
};

// ---------- 8. CTA ----------
const Pill: React.FC<{t: string; f: number; at: number}> = ({t, f, at}) => f < at ? null : (
  <div style={{padding: '9px 26px', borderRadius: 30, background: 'rgba(8,8,8,0.92)', color: '#fff', fontFamily: F.ui, fontWeight: 500, fontSize: 30, transform: `scale(${pop(f, at)})`, boxShadow: '0 0 0 1.5px rgba(255,255,255,0.12)'}}>{t}</div>
);
const CTA: React.FC = () => {
  const f = useCurrentFrame();
  const S = v(42.47), C1 = v(43.5), AI = v(44.5), P1 = v(45.45), P2 = v(46.55);
  const rise = ramp(f, S, S + 10);
  const g = 'linear-gradient(180deg,#ffffff 30%,#b9b6b0 100%)';
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 0, top: 432, width: 1080, height: 608, overflow: 'hidden', opacity: rise, transform: `scale(${1.06 - 0.06 * rise})`}}>
        <Sequence from={S} layout="none"><OffthreadVideo src={staticFile('film.mp4')} startFrom={370} playbackRate={0.33} muted style={{width: '100%', height: '100%', objectFit: 'cover', filter: 'brightness(0.62) saturate(1.1)'}} /></Sequence>
        <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at center, rgba(0,0,0,0.1), rgba(0,0,0,0.55))'}} />
        {f >= C1 && <div style={{position: 'absolute', left: 0, right: 0, top: 118, textAlign: 'center', fontFamily: F.pop, fontWeight: 700, fontSize: 168, lineHeight: 1, letterSpacing: -6, background: g, WebkitBackgroundClip: 'text', color: 'transparent', transform: `scale(${0.7 + 0.3 * pop(f, C1)})`, filter: 'drop-shadow(0 8px 30px rgba(0,0,0,0.5))'}}>Comenta</div>}
        {f >= AI && <div style={{position: 'absolute', left: 0, right: 0, top: 286, textAlign: 'center', fontFamily: F.pop, fontWeight: 700, fontSize: 168, lineHeight: 1, letterSpacing: -4, background: g, WebkitBackgroundClip: 'text', color: 'transparent', transform: `scale(${0.6 + 0.4 * pop(f, AI)})`, filter: 'drop-shadow(0 8px 30px rgba(0,0,0,0.5))'}}>“AI”</div>}
        <div style={{position: 'absolute', left: 0, right: 0, top: 500, display: 'flex', justifyContent: 'center', gap: 16}}>
          <Pill t="Herramientas" f={f} at={P1} /><Pill t="Guía de instalación" f={f} at={P2} />
        </div>
      </div>
    </AbsoluteFill>
  );
};

// ---------- sonidos de interfaz (SND Sine) ----------
const ui: [number, string, number][] = [];
const tap = (fr: number, n = 'tap_01', vol = 0.5) => ui.push([fr, n, vol]);
const typing = (a: number, b: number, step = 4) => { for (let fr = a, i = 0; fr < b; fr += step, i++) ui.push([fr, `type_0${1 + (i * 7) % 5}`, 0.2]); };
tap(FILM_END - 2, 'swipe_01', 0.4);
typing(v(7.45), v(10.0));
[0, 1, 2, 3].forEach((i) => tap(v(10.15) + i * 15, `tap_0${2 + i}`, 0.45));
tap(v(13.46), 'select', 0.4); tap(v(14.35), 'button', 0.55); tap(v(14.35) + 6, 'transition_up', 0.35);
tap(v(15.6) - 2, 'swipe_02', 0.4); tap(v(16.55), 'tap_01', 0.55); tap(v(17.75), 'toggle_on', 0.5); tap(v(18.55), 'button', 0.6);
tap(v(19.0), 'transition_up', 0.4);
tap(v(20.8) - 2, 'swipe_03', 0.4); typing(v(21.0), v(21.8)); typing(v(21.95), v(23.5), 3); tap(v(23.9), 'tap_01', 0.55); tap(v(23.9) + 3, 'celebration', 0.33);
tap(v(24.45), 'swipe_04', 0.4); [0, 1, 2, 3, 4, 5, 6].forEach((i) => tap(v(24.6) + i * 9, 'tap_04', 0.22));
tap(v(26.9), 'swipe_05', 0.4); tap(v(28.05), 'swipe_01', 0.35); tap(v(28.05) + 18, 'tap_03', 0.45); typing(v(29.35), v(31.45));
tap(v(31.6), 'button', 0.5); CLIPS.forEach((_, i) => { if (i % 2 === 0) tap(Math.round(v(31.75) + i * 2.4), `tap_0${1 + i % 5}`, 0.2); });
tap(v(34.13) - 2, 'swipe_02', 0.4); CLIPS.forEach((_, i) => { if (i % 3 === 0) tap(v(34.13) + 2 + i * 3, 'tap_02', 0.18); });
tap(v(37.5), 'transition_up', 0.4); tap(v(41.4), 'notification', 0.42);
tap(v(42.47), 'swipe_03', 0.45); tap(v(43.5), 'tap_05', 0.5); tap(v(44.5), 'button', 0.6); tap(v(45.45), 'tap_02', 0.45); tap(v(46.55), 'tap_03', 0.45);

export const Edit: React.FC = () => {
  const f = useCurrentFrame();
  const LIB = v(24.45), GEN2 = v(26.9);
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <Bg />
      {f < FILM_END + 2 && <div style={{opacity: 1 - ramp(f, FILM_END - 5, FILM_END)}}><Hook /></div>}
      <Scene from={FILM_END} to={v(15.6)} inn={7}><ChatPrompt /></Scene>
      <Scene from={v(15.6)} to={v(19.0)}><HfGenerate /></Scene>
      <Scene from={v(19.0)} to={v(20.8)}><Generated from={v(19.0)} to={v(20.8)} start={135} tag="SEEDANCE 2.5 · 15 S · HIGGSFIELD" /></Scene>
      <Scene from={v(20.8)} to={LIB}><Connector /></Scene>
      <Scene from={LIB} to={GEN2}><Library from={LIB} /></Scene>
      <Scene from={GEN2} to={v(28.05)}><Generated from={GEN2} to={v(28.05)} start={245} tag="TU VIDEO · SIN SONIDO" /></Scene>
      <Scene from={v(28.05)} to={v(34.13)}><AskSound /></Scene>
      <Scene from={v(34.13)} to={v(42.47)}><Assemble /></Scene>
      <Scene from={v(42.47)} to={TOTAL + 10}><CTA /></Scene>
      <Sequence from={FILM_END}><Host /></Sequence>

      {/* audio */}
      <Sequence from={0} durationInFrames={HOOK_END}><Audio src={staticFile('voz.wav')} /></Sequence>
      <Sequence from={FILM_END}><Audio src={staticFile('voz.wav')} startFrom={HOOK_END} /></Sequence>
      <Audio src={staticFile('film_sd.wav')} endAt={FILM_END + 2} volume={(fr) => interpolate(fr, [0, 6, 200, 224, FILM_END - 8, FILM_END + 1], [0, 0.3, 0.3, 1, 1, 0], clamp)} />
      <Sequence from={v(42.47)} durationInFrames={110}><Audio src={staticFile('siren_cta.wav')} volume={(fr) => interpolate(fr, [0, 12, 80, 110], [0, 0.22, 0.22, 0], clamp)} /></Sequence>
      {ui.map(([fr, n, vol], i) => <Sequence key={i} from={Math.max(0, fr)} durationInFrames={45}><Audio src={staticFile(`snd/${n}.wav`)} volume={vol} /></Sequence>)}
    </AbsoluteFill>
  );
};
