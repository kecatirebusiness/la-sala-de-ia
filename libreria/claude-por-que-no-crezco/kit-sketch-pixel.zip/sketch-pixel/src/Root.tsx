import React from 'react';
import {Composition} from 'remotion';
import {KevinVideo, DUR_K} from './Kevin';
export const Root: React.FC = () => <Composition id="Kevin" component={KevinVideo} durationInFrames={DUR_K} fps={30} width={1080} height={1920} />;
