import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {ANTON, Barra, Linea, MONO, Personaje, Pop, Prompt, SANS, Sfx, TINTA, Ventana, ease, enPalabra, f} from './kit';
import {CAPS, DUR, LIP_C, LIP_K, WORDS} from './datos';

export const DUR_K = DUR;
const ROJO = '#E63B2E';
const AMA = '#FFD43B';
const VERDE = '#00D26A';
const t = (w: string, n = 0) => enPalabra(WORDS, w, n);

// ---------- logos reales (Simple Icons) ----------
const SalaLogo: React.FC<{s: number}> = ({s}) => (
  <svg width={s} height={s} viewBox="0 0 40 40">
    <circle cx="20" cy="20" r="18" fill={VERDE} />
    <circle cx="15.4" cy="17" r="1.9" fill="#04120b" />
    <circle cx="24.6" cy="17" r="1.9" fill="#04120b" />
    <line x1="16.4" y1="23.4" x2="23.6" y2="23.4" stroke="#04120b" strokeWidth="2.1" strokeLinecap="round" />
  </svg>
);
const Logo: React.FC<{m: string; s?: number}> = ({m, s = 40}) =>
  m === 'sala' ? <SalaLogo s={s} /> : <Img src={staticFile(`logos/${m}.svg`)} style={{width: s, height: s}} />;
// palabra dicha → logo
const MARCA: Record<string, string> = {instagram: 'instagram', meta: 'meta', claude: 'claude', sala: 'sala'};

type Esc = {t: number; tag: string; l1: string; l2?: string; kw?: string; ama?: boolean; card: string; pk: string; pc: string; rayos?: boolean; logo?: string};
const ESC: Esc[] = [
  {t: 0, tag: 'KEVIN DICE', l1: 'MI INSTAGRAM', l2: 'NO', kw: 'CRECE', card: 'ig', pk: 'hombros', pc: 'brazos', logo: 'instagram'},
  {t: t('algoritmo'), tag: 'KEVIN DICE', l1: 'EL ALGORITMO', l2: 'ME', kw: 'ODIA', card: 'odia', pk: 'apunta_cam', pc: 'brazos'},
  {t: t('no', 1), tag: 'CLAUDE', l1: 'NO ES', kw: 'ASÍ', ama: true, card: 'whap', pk: 'cachete', pc: 'cachetada', rayos: true},
  {t: t('pasaste'), tag: 'LA VERDAD', l1: 'SE VAN EN EL', l2: 'SEGUNDO', kw: '2', ama: true, card: 'retencion', pk: 'asustado', pc: 'senala', logo: 'instagram'},
  {t: t('ok'), tag: 'KEVIN DICE', l1: '30', kw: 'HASHTAGS', card: 'hashtags', pk: 'dedo_arriba', pc: 'brazos'},
  {t: t('que'), tag: 'CLAUDE', l1: 'NO TE', kw: 'SALVAN', ama: true, card: 'whap2', pk: 'cachete', pc: 'cachetada', rayos: true},
  {t: t('lo'), tag: 'LO QUE RETIENE', l1: 'EL GANCHO', l2: 'DE', kw: '3 SEG', ama: true, card: 'gancho', pk: 'rasca', pc: 'dedo_arriba'},
  {t: t('pero'), tag: 'KEVIN DICE', l1: 'PUBLICO', l2: 'TODOS LOS', kw: 'DÍAS', card: 'diario', pk: 'pulgar', pc: 'brazos'},
  {t: t('publicar'), tag: 'CLAUDE', l1: 'NADIE LO', kw: 'COMPARTE', ama: true, card: 'whap3', pk: 'cachete', pc: 'cachetada', rayos: true},
  {t: t('tus', 1), tag: 'LO QUE SÍ FUNCIONA', l1: 'ENSEÑA', kw: 'ALGO', ama: true, card: 'compartidos', pk: 'asustado', pc: 'senala'},
  {t: t('y', 2), tag: 'KEVIN', l1: '¿CÓMO LO', kw: 'SABES?', card: 'pregunta', pk: 'rasca', pc: 'brazos'},
  {t: t('bajaste'), tag: 'RECURSO 1', l1: 'EXPORTA TUS', kw: 'MÉTRICAS', ama: true, card: 'meta', pk: 'idle', pc: 'dedo_arriba', logo: 'meta'},
  {t: t('me', 2), tag: 'RECURSO 2', l1: 'PÁSASELAS A', kw: 'CLAUDE', ama: true, card: 'claudecode', pk: 'asustado', pc: 'senala', logo: 'claude'},
  {t: t('escribí'), tag: 'RESULTADO', l1: '10 GANCHOS', kw: 'NUEVOS', ama: true, card: 'ganchos', pk: 'ok', pc: 'aplaude'},
  {t: t('ok', 2), tag: 'OK, OK', l1: 'KEVIN SE', kw: 'RINDE', card: 'rinde', pk: 'hombros', pc: 'brazos'},
  {t: t('te', 3), tag: '', l1: '', card: 'cta', pk: 'cachete', pc: 'pulgar', rayos: true},
];

const Rayos: React.FC<{on: boolean}> = ({on}) => {
  const fr = useCurrentFrame();
  return (
    <svg width={1080} height={1920} style={{position: 'absolute', inset: 0, opacity: on ? 0.55 : 0.18}}>
      <g transform={`translate(540 760) rotate(${fr * 0.15})`}>
        {Array.from({length: 36}).map((_, i) => (
          <polygon key={i} points="0,0 -40,-1500 40,-1500" fill="#EDEDED" transform={`rotate(${i * 10})`} />
        ))}
      </g>
    </svg>
  );
};

const Kw: React.FC<{kw: string; caja: boolean}> = ({kw, caja}) => (
  <span style={caja ? {background: ROJO, color: '#fff', padding: '0 12px', marginLeft: 16, display: 'inline-block'} : {color: ROJO, marginLeft: 18}}>{kw}</span>
);

const Titulo: React.FC<{e: Esc}> = ({e}) => {
  const fr = useCurrentFrame();
  const {fps} = useVideoConfig();
  if (!e.l1) return null;
  const s = spring({frame: fr, fps, config: {damping: 13, stiffness: 240}});
  const ls = spring({frame: fr - 6, fps, config: {damping: 9, stiffness: 260}});
  const kwBox = !e.ama;
  return (
    <div style={{position: 'absolute', top: 236, left: 56, transform: `rotate(-1.5deg) scale(${0.9 + 0.1 * s})`, transformOrigin: '0% 50%'}}>
      {e.tag ? (
        <div style={{display: 'inline-flex', alignItems: 'center', gap: 8, background: e.tag === 'CLAUDE' ? '#D97757' : ROJO, color: '#fff', fontFamily: ANTON, fontSize: 24, padding: '2px 10px', marginLeft: 6, letterSpacing: 1}}>
          {e.tag === 'CLAUDE' ? <Img src={staticFile('logos/claude.svg')} style={{width: 22, height: 22, filter: 'brightness(0) invert(1)'}} /> : null}
          {e.tag}
        </div>
      ) : null}
      <div style={{position: 'relative', background: e.ama ? AMA : '#fff', border: `5px solid ${TINTA}`, boxShadow: `9px 9px 0 ${TINTA}`, padding: '6px 20px 10px', fontFamily: ANTON, fontSize: 92, lineHeight: 1.0, color: TINTA, textTransform: 'uppercase'}}>
        <div>
          {e.l1}
          {!e.l2 && e.kw ? <Kw kw={e.kw} caja={kwBox} /> : null}
        </div>
        {e.l2 ? (
          <div>
            {e.l2}
            {e.kw ? <Kw kw={e.kw} caja={kwBox} /> : null}
          </div>
        ) : null}
        {e.logo ? (
          <div style={{position: 'absolute', right: -58, top: -52, width: 84, height: 84, borderRadius: 22, background: '#fff', border: `4px solid ${TINTA}`, boxShadow: `5px 5px 0 ${TINTA}`, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${ls}) rotate(10deg)`}}>
            <Logo m={e.logo} s={52} />
          </div>
        ) : null}
      </div>
    </div>
  );
};

const Burst: React.FC<{texto: string; at: number; size?: number}> = ({texto, at, size = 620}) => {
  const fr = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: fr - at, fps, config: {damping: 8, stiffness: 260, mass: 0.6}});
  const pts = Array.from({length: 28}).map((_, i) => {
    const a = (i / 28) * Math.PI * 2;
    const r = i % 2 ? 0.62 : 1;
    return `${50 + Math.cos(a) * 48 * r},${50 + Math.sin(a) * 40 * r}`;
  });
  const pts2 = pts.map((p) => p.split(',').map((v) => 50 + (Number(v) - 50) * 0.78).join(','));
  return (
    <div style={{width: size, height: size * 0.8, position: 'relative', transform: `scale(${s}) rotate(${-8 + 4 * Math.sin(fr / 3)}deg)`, margin: '0 auto'}}>
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" style={{position: 'absolute', inset: 0, width: '100%', height: '100%'}}>
        <polygon points={pts.join(' ')} fill={ROJO} stroke={TINTA} strokeWidth="1.2" />
        <polygon points={pts2.join(' ')} fill={AMA} stroke={TINTA} strokeWidth="0.8" />
      </svg>
      <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: ANTON, fontSize: size * 0.22, color: AMA, WebkitTextStroke: `6px ${TINTA}`, paintOrder: 'stroke fill', textShadow: `6px 6px 0 ${TINTA}`, transform: 'rotate(-6deg)'}}>{texto}</div>
    </div>
  );
};

const caja: React.CSSProperties = {background: '#fff', border: `4px solid ${TINTA}`, boxShadow: `8px 8px 0 ${TINTA}`, borderRadius: 14};
const Chip: React.FC<{children: React.ReactNode; bg?: string; style?: React.CSSProperties}> = ({children, bg = '#fff', style}) => (
  <div style={{display: 'inline-flex', alignItems: 'center', gap: 10, background: bg, border: `4px solid ${TINTA}`, borderRadius: 12, boxShadow: `5px 5px 0 ${TINTA}`, padding: '10px 18px', fontFamily: SANS, fontWeight: 800, fontSize: 28, color: TINTA, ...style}}>{children}</div>
);

// gráfica de línea (seguidores o retención)
const Curva: React.FC<{pts: number[]; at: number; color: string; w?: number; h?: number; marca?: number; etiqueta?: string}> = ({pts, at, color, w = 640, h = 220, marca, etiqueta}) => {
  const fr = useCurrentFrame();
  const p = ease(fr, at, 24);
  const xy = pts.map((v, i) => [(i / (pts.length - 1)) * w, h - v * h]);
  const n = Math.max(2, Math.ceil(p * xy.length));
  const d = xy.slice(0, n).map(([x, y], i) => `${i ? 'L' : 'M'}${x},${y}`).join(' ');
  return (
    <svg width={w} height={h + 10} style={{overflow: 'visible'}}>
      <path d={d} fill="none" stroke={color} strokeWidth={8} strokeLinejoin="round" strokeLinecap="round" />
      {marca !== undefined && p > 0.5 ? (
        <g>
          <line x1={marca * w} x2={marca * w} y1={0} y2={h} stroke={ROJO} strokeWidth={4} strokeDasharray="10 8" />
          <rect x={marca * w + 12} y={h * 0.55} width={250} height={50} rx={10} fill={ROJO} stroke={TINTA} strokeWidth={3} />
          <text x={marca * w + 24} y={h * 0.55 + 35} fontFamily={SANS} fontWeight={800} fontSize={26} fill="#fff">{etiqueta}</text>
        </g>
      ) : null}
    </svg>
  );
};

const Card: React.FC<{id: string; at: number}> = ({id, at}) => {
  const fr = useCurrentFrame();
  const a = (x: number) => f(x) - at;
  switch (id) {
    case 'ig':
    case 'odia':
      return (
        <Pop at={0} style={{display: 'flex', justifyContent: 'center'}}>
          <div style={{...caja, width: 780, padding: 22, position: 'relative'}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 16}}>
              <div style={{width: 92, height: 92, borderRadius: 46, padding: 4, background: 'linear-gradient(45deg,#FEDA75,#FA7E1E,#D62976,#962FBF,#4F5BD5)'}}>
                <div style={{width: '100%', height: '100%', borderRadius: 42, background: '#fff', overflow: 'hidden', display: 'flex', justifyContent: 'center'}}>
                  <Img src={staticFile('kevin/idle_c.png')} style={{width: 120, marginTop: -6, imageRendering: 'pixelated'}} />
                </div>
              </div>
              <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 32}}>@kecatire</div>
              <div style={{marginLeft: 'auto'}}><Logo m="instagram" s={56} /></div>
            </div>
            <div style={{display: 'flex', justifyContent: 'space-around', margin: '16px 0 10px', fontFamily: SANS, textAlign: 'center'}}>
              {[['412', 'posts'], ['1,204', 'seguidores'], ['+0', 'este mes']].map(([n, l], i) => (
                <div key={l}><div style={{fontWeight: 800, fontSize: 38, color: i === 2 ? ROJO : TINTA}}>{n}</div><div style={{fontSize: 22, color: '#666'}}>{l}</div></div>
              ))}
            </div>
            <Curva pts={[0.42, 0.44, 0.41, 0.43, 0.42, 0.4, 0.42, 0.41, 0.4]} at={4} color="#999" w={730} h={150} />
            {id === 'odia' ? (
              <Pop at={3} style={{position: 'absolute', right: -30, bottom: -40}}>
                <Chip bg={ROJO} style={{color: '#fff', transform: 'rotate(-6deg)', fontSize: 34}}>🤖 algoritmo = 😈</Chip>
              </Pop>
            ) : null}
          </div>
        </Pop>
      );
    case 'whap':
      return <Burst texto="¡ZAS!" at={0} />;
    case 'whap2':
      return <Burst texto="¡ZAS!!" at={0} />;
    case 'whap3':
      return <Burst texto="¡PLAF!" at={0} />;
    case 'retencion':
      return (
        <Pop at={0} style={{display: 'flex', justifyContent: 'center'}}>
          <div style={{...caja, width: 780, padding: 22}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 12, fontFamily: SANS, fontWeight: 800, fontSize: 28, marginBottom: 12}}>
              <Logo m="instagram" s={40} /> Insights · Retención del reel
            </div>
            <Curva pts={[1, 0.62, 0.3, 0.2, 0.17, 0.15, 0.14, 0.13, 0.12]} at={3} color="#D62976" w={720} h={230} marca={0.25} etiqueta="se van aquí: 2 s" />
            <div style={{display: 'flex', justifyContent: 'space-between', fontFamily: MONO, fontSize: 20, color: '#777', marginTop: 4}}><span>0s</span><span>15s</span><span>30s</span></div>
          </div>
        </Pop>
      );
    case 'hashtags': {
      const hs = ['#viral', '#fyp', '#reels', '#explore', '#parati', '#instagood', '#trending', '#ia', '#contenido', '#emprender', '#marketing', '#tips'];
      return (
        <div style={{display: 'flex', flexWrap: 'wrap', gap: 14, justifyContent: 'center', padding: '0 20px'}}>
          {hs.map((h, i) => (
            <Pop key={h} at={i * 1.6}>
              <Chip bg={i % 3 === 0 ? '#E8EEFB' : '#fff'} style={{fontSize: 32, color: '#2F6FEB', transform: `rotate(${((i * 37) % 9) - 4}deg)`}}>{h}</Chip>
            </Pop>
          ))}
        </div>
      );
    }
    case 'gancho':
      return (
        <Pop at={0} style={{display: 'flex', justifyContent: 'center'}}>
          <div style={{...caja, width: 800, padding: 24}}>
            <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 28, marginBottom: 16}}>▶ Tu reel</div>
            <div style={{display: 'flex', height: 90, border: `4px solid ${TINTA}`, borderRadius: 10, overflow: 'hidden'}}>
              <div style={{width: `${10 + 20 * ease(fr, a(t('gancho')), 10)}%`, background: AMA, borderRight: `4px solid ${TINTA}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: ANTON, fontSize: 40}}>GANCHO</div>
              <div style={{flex: 1, background: '#F1F2F4', display: 'flex', alignItems: 'center', paddingLeft: 20, fontFamily: SANS, fontSize: 26, color: '#888'}}>el resto del video</div>
            </div>
            <div style={{display: 'flex', justifyContent: 'space-between', fontFamily: MONO, fontSize: 22, marginTop: 8}}><span>0s</span><span style={{color: ROJO, fontWeight: 700}}>3s</span><span>30s</span></div>
            <Pop at={a(t('segundos'))} style={{marginTop: 14}}>
              <Chip bg={VERDE}>✓ Si el gancho atrapa, se quedan</Chip>
            </Pop>
          </div>
        </Pop>
      );
    case 'diario': {
      const d = ['L', 'M', 'M', 'J', 'V', 'S', 'D'];
      return (
        <Pop at={0} style={{display: 'flex', justifyContent: 'center'}}>
          <div style={{...caja, padding: 24, display: 'flex', gap: 12}}>
            {d.map((x, i) => (
              <Pop key={i} at={3 + i * 2.5}>
                <div style={{width: 92, height: 120, border: `4px solid ${TINTA}`, borderRadius: 10, background: '#fff', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'space-around', fontFamily: ANTON, fontSize: 34}}>
                  {x}
                  <span style={{fontSize: 40, color: VERDE}}>✓</span>
                </div>
              </Pop>
            ))}
          </div>
        </Pop>
      );
    }
    case 'compartidos': {
      const ps: [string, number, string][] = [['📚 Tutorial', 1, '1.4K'], ['😂 Meme', 0.12, '38'], ['🤳 Selfie', 0.05, '9']];
      return (
        <Pop at={0} style={{display: 'flex', justifyContent: 'center'}}>
          <div style={{...caja, width: 800, padding: 24}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 12, fontFamily: SANS, fontWeight: 800, fontSize: 28, marginBottom: 18}}>
              <Logo m="instagram" s={40} /> Veces compartido ✈️
            </div>
            {ps.map(([n, v, l], i) => (
              <div key={n} style={{display: 'flex', alignItems: 'center', gap: 14, marginBottom: 14}}>
                <div style={{width: 210, fontFamily: SANS, fontWeight: 800, fontSize: 28}}>{n}</div>
                <div style={{flex: 1, height: 48, background: '#F1F2F4', borderRadius: 8, border: `3px solid ${TINTA}`, overflow: 'hidden'}}>
                  <div style={{width: `${Math.max(4, v * 100 * ease(fr, 4 + i * 4, 18))}%`, height: '100%', background: i ? '#C9CDD4' : VERDE}} />
                </div>
                <div style={{width: 80, fontFamily: ANTON, fontSize: 34, color: i ? '#888' : TINTA}}>{l}</div>
              </div>
            ))}
          </div>
        </Pop>
      );
    }
    case 'pregunta':
      return (
        <Pop at={0} style={{textAlign: 'center'}}>
          <div style={{fontFamily: ANTON, fontSize: 300, color: AMA, WebkitTextStroke: `10px ${TINTA}`, paintOrder: 'stroke fill', textShadow: `12px 12px 0 ${TINTA}`, lineHeight: 1}}>?</div>
        </Pop>
      );
    case 'meta':
      return (
        <Pop at={0}>
          <div style={{...caja, overflow: 'hidden'}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 14, padding: '14px 20px', borderBottom: `3px solid ${TINTA}`, background: '#F5F8FF'}}>
              <Logo m="meta" s={48} />
              <span style={{fontFamily: SANS, fontWeight: 800, fontSize: 30}}>Meta Business Suite</span>
            </div>
            <div style={{padding: '18px 24px', fontFamily: MONO, fontSize: 28, lineHeight: 1.7}}>
              <Linea at={a(t('métricas', 1))}>Insights › Contenido</Linea>
              <Linea at={a(t('business'))}>Últimos 30 posts</Linea>
              <Linea at={a(t('csv')) - 6} ok>Exportar datos</Linea>
              <Pop at={a(t('csv'))} style={{marginTop: 10}}>
                <Chip bg="#D8F5E3"><span style={{fontSize: 34}}>📄</span> metricas-instagram.csv</Chip>
              </Pop>
            </div>
          </div>
        </Pop>
      );
    case 'claudecode':
      return (
        <Pop at={0}>
          <Ventana titulo="Claude Code">
            <Prompt texto="analiza mis últimos 30 posts: ¿por qué no crezco?" at={2} />
            <Linea at={a(t('code'))}>leyendo metricas-instagram.csv</Linea>
            <Linea at={a(t('revisé'))}>retención · guardados · compartidos</Linea>
            <Barra at={a(t('revisé'))} len={36} color={VERDE} />
            <Linea at={a(t('posts', 1))} ok>30 posts analizados</Linea>
          </Ventana>
        </Pop>
      );
    case 'ganchos': {
      const g = ['"Nadie te dice esto de…"', '"Deja de hacer X si…"', '"Probé Y por 30 días"'];
      return (
        <Pop at={0}>
          <Ventana titulo="Claude Code · ganchos.md">
            {g.map((x, i) => (
              <Linea key={x} at={4 + i * 4} ok>{`${i + 1}. ${x}`}</Linea>
            ))}
            <Pop at={18} style={{marginTop: 10}}>
              <Chip bg={AMA}>+ 7 ganchos más</Chip>
            </Pop>
          </Ventana>
        </Pop>
      );
    }
    case 'rinde':
      return (
        <Pop at={0} style={{textAlign: 'center'}}>
          <div style={{fontSize: 200}}>🏳️</div>
          <div style={{fontFamily: ANTON, fontSize: 64, color: TINTA}}>CLAUDE 3 · KEVIN 0</div>
        </Pop>
      );
    case 'cta':
      return (
        <div style={{textAlign: 'center', marginTop: -200}}>
          <Pop at={0}>
            <div style={{fontFamily: ANTON, fontSize: 180, color: '#fff', WebkitTextStroke: `10px ${TINTA}`, paintOrder: 'stroke fill', textShadow: `10px 10px 0 ${TINTA}`, lineHeight: 1}}>COMENTA</div>
          </Pop>
          <Pop at={a(t('sala', 2)) - 8}>
            <div style={{display: 'inline-flex', alignItems: 'center', gap: 20, background: VERDE, color: TINTA, border: `6px solid ${TINTA}`, borderRadius: 80, padding: '4px 60px', fontFamily: ANTON, fontSize: 120, boxShadow: `8px 8px 0 ${TINTA}`, marginTop: 10}}>
              SALA
            </div>
          </Pop>
          <Pop at={a(t('sala', 1))}>
            <div style={{display: 'inline-flex', alignItems: 'center', gap: 14, fontFamily: ANTON, fontSize: 44, color: TINTA, marginTop: 26}}>
              <SalaLogo s={56} /> LA SALA DE IA · LISTA DE ESPERA GEN 02
            </div>
          </Pop>
          <div style={{display: 'flex', justifyContent: 'center', gap: 16, marginTop: 20}}>
            {[
              ['instagram', 'Instagram'],
              ['meta', 'Business Suite'],
              ['claude', 'Claude Code'],
            ].map(([m, n], i) => (
              <Pop key={n} at={a(t('sala', 1)) + 8 + i * 3}>
                <Chip style={{fontSize: 24, padding: '8px 14px'}}><Logo m={m} s={30} />{n}</Chip>
              </Pop>
            ))}
          </div>
        </div>
      );
  }
  return null;
};

// globo: nube para Kevin, explosión amarilla para Claude. Las marcas salen con su logo real.
const Globo: React.FC = () => {
  const fr = useCurrentFrame();
  const {fps} = useVideoConfig();
  const tt = fr / 30;
  const c = CAPS.find((x) => tt >= x.s - 0.03 && tt < x.e);
  if (!c) return null;
  const ini = Math.round(c.s * 30);
  const s = spring({frame: fr - ini, fps, config: {damping: 11, stiffness: 260, mass: 0.5}});
  const esC = c.who === 'claude';
  const KW = ['instagram', 'algoritmo', 'odia', 'humano', 'métricas', 'segundo', 'dos', 'hashtags', '30', 'gancho', 'tres', 'segundos', 'todos', 'días', 'comparte', 'enseñan', 'meta', 'business', 'suite', 'csv', 'claude', 'code', 'diez', 'ganchos', 'sala', 'ia'];
  const txt = c.w.map(([w], i) => {
    const limpio = w.toLowerCase().replace(/[¡!¿?,.']/g, '');
    const m = MARCA[limpio];
    return (
      <React.Fragment key={i}>
        <span style={{color: KW.includes(limpio) ? ROJO : TINTA, whiteSpace: 'nowrap'}}>
          {m ? <span style={{display: 'inline-block', verticalAlign: '-6px', marginRight: 6}}><Logo m={m} s={40} /></span> : null}
          {w.toUpperCase()}
        </span>
        {i < c.w.length - 1 ? ' ' : ''}
      </React.Fragment>
    );
  });
  const pos: React.CSSProperties = esC ? {left: 520, top: 960} : {left: 60, top: 880};
  return (
    <div style={{position: 'absolute', ...pos, width: 440, height: 180, transform: `scale(${0.7 + 0.3 * s})`, transformOrigin: esC ? '50% 100%' : '40% 100%'}}>
      {esC ? (
        <svg viewBox="0 0 100 50" preserveAspectRatio="none" style={{position: 'absolute', inset: 0, width: '100%', height: '100%', overflow: 'visible'}}>
          <polygon
            points={Array.from({length: 24})
              .map((_, i) => {
                const a = (i / 24) * Math.PI * 2;
                const r = i % 2 ? 0.8 : 1;
                return `${50 + Math.cos(a) * 50 * r},${25 + Math.sin(a) * 25 * r}`;
              })
              .join(' ')}
            fill={AMA}
            stroke={TINTA}
            strokeWidth="1.2"
          />
          <polygon points="46,47 54,47 52,62" fill={AMA} stroke={TINTA} strokeWidth="1.2" />
        </svg>
      ) : (
        <svg viewBox="0 0 100 50" preserveAspectRatio="none" style={{position: 'absolute', inset: 0, width: '100%', height: '100%', overflow: 'visible'}}>
          <ellipse cx="50" cy="25" rx="49" ry="23" fill="#fff" stroke={TINTA} strokeWidth="1.2" />
          <circle cx="44" cy="55" r="3.5" fill="#fff" stroke={TINTA} strokeWidth="1" />
          <circle cx="40" cy="64" r="2.2" fill="#fff" stroke={TINTA} strokeWidth="1" />
        </svg>
      )}
      <div style={{position: 'absolute', inset: esC ? '0 78px' : '0 46px', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
        <div style={{textAlign: 'center', fontFamily: ANTON, fontSize: esC ? 38 : 42, lineHeight: 1.08, maxWidth: '100%'}}>{txt}</div>
      </div>
    </div>
  );
};

export const KevinVideo: React.FC = () => {
  const fr = useCurrentFrame();
  const i = ESC.reduce((acc, e, k) => (fr >= f(e.t) ? k : acc), 0);
  const e = ESC[i];
  const whap = e.card.startsWith('whap') ? fr - f(e.t) : 99;
  const shake = whap < 12 ? Math.sin(whap * 2.2) * (12 - whap) * 2.2 : 0;
  const sfx: [number, string, number?][] = [];
  ESC.forEach((x, k) => {
    if (x.card.startsWith('whap')) {
      sfx.push([x.t, 'impacto_03.ogg', 0.7]);
      sfx.push([x.t + 0.02, 'whoosh_05.ogg', 0.4]);
    } else if (k > 0) sfx.push([x.t, ['pop_04.ogg', 'pop_09.ogg', 'pop_13.ogg'][k % 3], 0.3]);
  });
  return (
    <AbsoluteFill style={{background: '#fff', transform: `translate(${shake}px, ${shake * 0.4}px)`}}>
      <Audio src={staticFile('voz.wav')} />
      <Sfx lista={sfx} />
      <Rayos on={!!e.rayos} />
      {ESC.map((x, k) => {
        const ini = f(x.t);
        const fin = k + 1 < ESC.length ? f(ESC[k + 1].t) : DUR;
        const mismoTit = k > 0 && ESC[k - 1].l1 === x.l1 && ESC[k - 1].kw === x.kw;
        return (
          <Sequence key={k} from={ini} durationInFrames={Math.max(1, fin - ini)}>
            {mismoTit ? (
              <Sequence from={-30}>
                <Titulo e={x} />
              </Sequence>
            ) : (
              <Titulo e={x} />
            )}
            <div style={{position: 'absolute', top: x.l2 ? 560 : 470, left: 90, right: 90, transform: 'scale(0.92)', transformOrigin: '50% 0%'}}>
              <Card id={x.card} at={ini} />
            </div>
          </Sequence>
        );
      })}
      <Personaje dir="kevin" pose={e.pk} lip={LIP_K} desde={f(e.t)} style={{left: -10, top: 1060, width: 570, height: 760}} />
      <Personaje dir="claude" pose={e.pc} lip={LIP_C} desde={f(e.t)} style={{left: 470, top: 1150, width: 500, height: 500}} filtro="none" />
      <Globo />
    </AbsoluteFill>
  );
};
