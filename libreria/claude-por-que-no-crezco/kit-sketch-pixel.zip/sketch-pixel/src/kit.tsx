import React from 'react';
import {Audio, Img, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont as anton} from '@remotion/google-fonts/Anton';
import {loadFont as inter} from '@remotion/google-fonts/Inter';
import {loadFont as mono} from '@remotion/google-fonts/JetBrainsMono';

export const {fontFamily: ANTON} = anton('normal', {weights: ['400'], subsets: ['latin', 'latin-ext']});
export const {fontFamily: SANS} = inter('normal', {weights: ['500', '700', '800'], subsets: ['latin', 'latin-ext']});
export const {fontFamily: MONO} = mono('normal', {weights: ['400', '700'], subsets: ['latin', 'latin-ext']});

export const FPS = 30;
export const TINTA = '#16181D';
export const LINEA = '#E2E5EA';
export const f = (t: number) => Math.round(t * FPS);

// tiempo de la n-ésima palabra que empieza con `w`
export const enPalabra = (W: [string, number][], w: string, n = 0) => {
  const k = w.toLowerCase();
  const hits = W.filter(([x]) => x.toLowerCase().replace(/[¡!¿?,.']/g, '') === k);
  return hits[Math.min(n, hits.length - 1)]?.[1] ?? 0;
};

export const ease = (fr: number, start: number, len = 8) =>
  interpolate(fr, [start, start + len], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

export const Pop: React.FC<{at?: number; children: React.ReactNode; style?: React.CSSProperties; desde?: number}> = ({at = 0, children, style, desde = 0.6}) => {
  const fr = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: fr - at, fps, config: {damping: 12, stiffness: 220, mass: 0.6}});
  return <div style={{transform: `scale(${desde + (1 - desde) * s})`, opacity: fr < at ? 0 : Math.min(1, s * 1.6), ...style}}>{children}</div>;
};

export const Tipea: React.FC<{texto: string; at: number; cps?: number}> = ({texto, at, cps = 34}) => {
  const fr = useCurrentFrame();
  if (fr < at) return null;
  const n = Math.max(0, Math.floor(((fr - at) / FPS) * cps));
  const on = n < texto.length + 10 && Math.floor(fr / 8) % 2 === 0;
  return (
    <span>
      {texto.slice(0, n)}
      {on ? <span style={{background: TINTA, color: TINTA}}>_</span> : null}
    </span>
  );
};

export const Ventana: React.FC<{titulo?: string; children?: React.ReactNode; acento?: string; alto?: number}> = ({titulo = 'Claude Code', children, acento = '#D97757', alto}) => (
  <div style={{background: '#fff', border: `3px solid ${TINTA}`, borderRadius: 12, overflow: 'hidden', boxShadow: `8px 8px 0 ${TINTA}`, minHeight: alto}}>
    <div style={{display: 'flex', alignItems: 'center', gap: 10, padding: '12px 18px', borderBottom: `3px solid ${TINTA}`, background: '#FAFAFA'}}>
      {['#FF5F57', '#FEBC2E', '#28C840'].map((c) => (
        <div key={c} style={{width: 15, height: 15, borderRadius: 8, background: c, border: `1.5px solid ${TINTA}`}} />
      ))}
      <span style={{marginLeft: 8, fontFamily: SANS, fontWeight: 800, fontSize: 22, color: TINTA}}>
        <span style={{color: acento}}>✳</span> {titulo}
      </span>
    </div>
    <div style={{padding: '16px 22px', fontFamily: MONO, fontSize: 26, color: TINTA, lineHeight: 1.55}}>{children}</div>
  </div>
);

export const Prompt: React.FC<{texto: string; at: number; acento?: string}> = ({texto, at, acento = '#D97757'}) => {
  const fr = useCurrentFrame();
  if (fr < at) return null;
  return (
    <div style={{background: '#F3F4F6', border: `2px solid ${LINEA}`, borderRadius: 6, padding: '8px 14px', margin: '2px 0 8px'}}>
      <span style={{color: acento}}>› </span>
      <Tipea texto={texto} at={at} />
    </div>
  );
};

export const Linea: React.FC<{at: number; ok?: boolean; color?: string; children: React.ReactNode}> = ({at, ok, color = '#1A9E4B', children}) => {
  const fr = useCurrentFrame();
  if (fr < at) return null;
  const o = ease(fr, at, 5);
  return (
    <div style={{opacity: o, transform: `translateY(${(1 - o) * 8}px)`, color: ok ? color : TINTA}}>
      {ok ? '✓ ' : '● '}
      {children}
    </div>
  );
};

export const Barra: React.FC<{at: number; len: number; color: string}> = ({at, len, color}) => {
  const fr = useCurrentFrame();
  if (fr < at) return null;
  return (
    <div style={{height: 16, background: '#E6E8EC', borderRadius: 8, overflow: 'hidden', marginTop: 8, border: `2px solid ${TINTA}`}}>
      <div style={{width: `${ease(fr, at, len) * 100}%`, height: '100%', background: color}} />
    </div>
  );
};

// personaje con boca sincronizada: sprite <pose>_c / <pose>_o
export const Personaje: React.FC<{dir: string; pose: string; lip: number[]; desde: number; style: React.CSSProperties; filtro?: string}> = ({dir, pose, lip, desde, style, filtro}) => {
  const fr = useCurrentFrame();
  const abierta = (lip[Math.min(fr, lip.length - 1)] ?? 0) === 1;
  const k = fr - desde;
  const sq = k >= 0 && k < 6 ? [1.05, 0.97, 1.02, 0.99, 1.005, 1][k] : 1;
  return (
    <div style={{position: 'absolute', transform: `scale(${sq})`, transformOrigin: '50% 100%', ...style}}>
      <Img src={staticFile(`${dir}/${pose}_${abierta ? 'o' : 'c'}.png`)} style={{width: '100%', height: '100%', imageRendering: 'pixelated', filter: filtro}} />
    </div>
  );
};

export const Sfx: React.FC<{lista: [number, string, number?][]}> = ({lista}) => (
  <>
    {lista.map(([t, file, v], i) => (
      <Sequence key={i} from={f(t)} durationInFrames={60}>
        <Audio src={staticFile(`sfx3/${file}`)} volume={v ?? 0.35} />
      </Sequence>
    ))}
  </>
);

export const cuadro = (n: number) => (n < 0 ? 0 : n);
