"""Limpia cada línea (voice isolation + pausas <= 0.09 s), sube el tono de Claude, arma el diálogo,
transcribe palabra por palabra y saca LIP por personaje. Escribe proj/public/voz.wav y proj/src/datos.ts"""
import json, os, subprocess, sys
import numpy as np, imageio_ffmpeg
from faster_whisper import WhisperModel

FF = imageio_ffmpeg.get_ffmpeg_exe()
D = os.path.dirname(os.path.abspath(__file__)); A = os.path.join(D, 'aud'); P = D
SR, FPS = 44100, 30
ORDEN = [('kevin', 'k1.wav'), ('claude', 'c1.mp3'), ('kevin', 'k2.wav'), ('claude', 'c2.mp3'), ('kevin', 'k3.wav'),
         ('claude', 'c3.mp3'), ('kevin', 'k4.wav'), ('claude', 'c4.mp3'), ('kevin', 'k5.wav'), ('claude', 'c5.mp3')]
CADENA = 'highpass=f=90,lowpass=f=11000,afftdn=nf=-25,anlmdn=s=4,agate=threshold=0.02:ratio=3,acompressor=threshold=-18dB:ratio=3:attack=5:release=80,equalizer=f=3000:t=q:w=1:g=3,deesser'


def leer(path, extra='', limpio=True):
    f = (CADENA if limpio else 'highpass=f=60') + (',' + extra if extra else '')
    raw = subprocess.run([FF, '-v', 'error', '-i', path, '-af', f, '-ac', '1', '-ar', str(SR), '-f', 'f32le', '-'], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32).copy()


def sin_pausas(x, maxp=0.09):
    win = int(SR * 0.01); n = len(x) // win
    e = np.sqrt(np.mean(x[:n * win].reshape(n, win) ** 2, axis=1))
    voz = e > max(0.012, e.max() * 0.06)
    idx = np.where(voz)[0]
    if not len(idx): return x
    voz[:idx[0]] = False; voz[idx[-1] + 1:] = False
    out, k, mx = [], idx[0], int(maxp / 0.01)
    while k <= idx[-1]:
        if voz[k]: out.append(x[k * win:(k + 1) * win]); k += 1; continue
        j = k
        while j <= idx[-1] and not voz[j]: j += 1
        out.append(x[k * win:(k + min(j - k, mx)) * win]); k = j
    y = np.concatenate(out)
    pad = np.zeros(int(SR * 0.03), np.float32)
    return np.concatenate([pad, y, pad])


segs, t, mezcla, quien = [], 0.0, [], []
for who, fn in ORDEN:
    x = leer(os.path.join(A, fn), 'asetrate=%d,aresample=%d' % (int(SR * 1.16), SR) if who == 'claude' else '', limpio=(who == 'claude'))  # la voz clonada de Kevin ya viene limpia: sin filtros
    x = sin_pausas(x)
    x = x / (np.abs(x).max() + 1e-9) * 0.89
    segs.append({'who': who, 's': t, 'e': t + len(x) / SR})
    mezcla.append(x); quien.append(np.full(len(x), 1 if who == 'claude' else 0, np.int8))
    gap = np.zeros(int(SR * 0.06), np.float32); mezcla.append(gap); quien.append(np.full(len(gap), -1, np.int8))
    t += (len(x) + len(gap)) / SR
y = np.concatenate(mezcla); q = np.concatenate(quien)
tail = np.zeros(int(SR * 1.6), np.float32); y = np.concatenate([y, tail]); q = np.concatenate([q, np.full(len(tail), -1, np.int8)])
subprocess.run([FF, '-v', 'error', '-y', '-f', 'f32le', '-ar', str(SR), '-ac', '1', '-i', '-', '-af', 'loudnorm=I=-16:TP=-1.5:LRA=11', '-ar', str(SR), os.path.join(P, 'public', 'voz.wav')], input=y.tobytes(), check=True)

# lip por cuadro y personaje
nf = int(len(y) / SR * FPS) + 1
LIP = {'kevin': [0] * nf, 'claude': [0] * nf}
spf = SR // FPS
for i in range(nf):
    a, b = i * spf, min(len(y), (i + 1) * spf)
    if b <= a: continue
    rms = float(np.sqrt(np.mean(y[a:b] ** 2))); w = np.bincount(q[a:b][q[a:b] >= 0], minlength=2)
    if w.sum() == 0 or rms < 0.035: continue
    LIP['claude' if w[1] > w[0] else 'kevin'][i] = 1
for k in LIP:  # boca: abre/cierra con ritmo (como antes): fuerza a cerrar cada 4º cuadro abierto
    run = 0
    for i, v in enumerate(LIP[k]):
        run = run + 1 if v else 0
        if run and run % 4 == 0: LIP[k][i] = 0

m = WhisperModel('medium', compute_type='int8')
res, _ = m.transcribe(os.path.join(P, 'public', 'voz.wav'), language='es', word_timestamps=True, initial_prompt='Claude, Claude Code, Instagram, Meta Business Suite, CSV, hashtags, La Sala de IA, SALA.')
W = [[w.word.strip(), round(w.start, 2), round(w.end, 2)] for s in res for w in s.words]
FIX = {'cloud': 'Claude', 'clod': 'Claude', 'claud': 'Claude', 'csv': 'CSV', 'sala': 'SALA', 'sala.': 'SALA.'}
for w in W:
    k = w[0].lower()
    if k in FIX: w[0] = FIX[k]
# subtítulos: grupos de <= 4 palabras, sin cruzar de personaje
def who_at(tt):
    for s in segs:
        if s['s'] - 0.05 <= tt < s['e'] + 0.03: return s['who']
    return 'kevin'
CAPS, cur = [], None
for w in W:
    h = who_at(w[1])
    if cur and (cur['who'] != h or len(cur['w']) >= 4 or w[1] - cur['e'] > 0.35 or cur['w'][-1][0][-1] in '.?!'):
        CAPS.append(cur); cur = None
    if not cur: cur = {'s': w[1], 'e': w[2], 'who': h, 'w': []}
    cur['w'].append([w[0], w[1]]); cur['e'] = w[2]
if cur: CAPS.append(cur)
for i in range(len(CAPS) - 1): CAPS[i]['e'] = min(CAPS[i + 1]['s'], CAPS[i]['e'] + 0.4)
dur = int(len(y) / SR * FPS)
open(os.path.join(P, 'src', 'datos.ts'), 'w').write(
    f"export const DUR={dur};\nexport const SEGS={json.dumps(segs)};\nexport const LIP_K={json.dumps(LIP['kevin'])};\nexport const LIP_C={json.dumps(LIP['claude'])};\n"
    f"export const CAPS:{{s:number;e:number;who:string;w:[string,number][]}}[]={json.dumps(CAPS, ensure_ascii=False)};\n"
    f"export const WORDS:[string,number][]={json.dumps([[w[0], w[1]] for w in W], ensure_ascii=False)};\n")
print('dur', dur / FPS)
for s in segs: print(s['who'], round(s['s'], 2), round(s['e'], 2))
print(' '.join(f"{w[0]}@{w[1]}" for w in W))
