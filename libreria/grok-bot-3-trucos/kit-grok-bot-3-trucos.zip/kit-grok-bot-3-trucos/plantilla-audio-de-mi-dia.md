# Mi día (para grabarlo en audio y pasárselo a tu bot jefe)

Habla 10 minutos respondiendo esto:

1. ¿Qué hago desde que abro la laptop hasta que la cierro?
2. ¿Qué herramientas uso (correo, calendario, Slack, CRM…)?
3. ¿Qué tareas repito cada día o cada semana?
4. ¿Qué me encanta hacer y quiero seguir haciendo yo?
5. ¿Qué me quita tiempo y odio hacer?
6. ¿Qué NO quiero que se automatice nunca?
7. ¿Qué cosas se me olvidan o se me escapan?

Transcríbelo y pégalo en el prompt 01.
