# Mi estilo (la nota que el bot de escritura va llenando)

- Saludo: 
- Largo máximo: 
- Tono: 
- Palabras que sí uso: 
- Palabras que nunca uso: 
- Cómo cierro: 

## Lo que aprendió de mis correcciones
- (fecha) …
