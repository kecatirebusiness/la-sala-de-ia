# 01 · Arranca con un solo bot jefe

En la guía, la autora cuenta que intentó manejar 20 bots a la vez y fue un caos. Ahora habla con uno solo, Gus, que reparte el trabajo a los demás (seguimientos, escritura, preguntas de clientes…). Haz lo mismo: crea primero tu bot jefe. Ella empezó grabando un audio de 10 minutos contando su día: qué le gusta hacer, qué no y qué no quiere automatizar nunca.

## Prompt para tu bot jefe (pégalo en Grok Bot)

```
Vas a ser mi jefe de equipo. Te llamas [NOMBRE]. Te cuento mi día de trabajo:
[PEGA LA TRANSCRIPCIÓN DE TU AUDIO O ESCRIBE: qué hago cada día, qué herramientas uso, qué me quita más tiempo, qué me encanta hacer y qué NO quiero que automatices nunca].

Con eso: 1) dime qué 3 tareas repetidas te puedo pasar primero; 2) propón qué bots especialistas haría falta crear (uno por trabajo) y qué rutina tendría cada uno; 3) tú eres el único con el que hablo: los demás te reportan a ti y tú decides qué necesita mi atención. Antes de mandar nada con mi nombre, pídeme el sí.
```

