# 05 · Empieza por uno solo

No montes los tres el mismo día. Escoge el que más trabajo repetido te quite (si tienes muchas llamadas, el truco 2; si escribes muchos correos, el 3). Con el tiempo el bot sabe mejor qué vale la pena automatizar, cuándo ayudarte y cómo escribes. La rutina semanal del truco 1 se encarga de ir sumando lo demás.

## Prompt para escoger por dónde empezar

```
Mira mi calendario y mis correos de la última semana. Dime cuál de estos tres me ahorraría más tiempo y por qué, con números: 1) revisión semanal de cómo te uso, 2) ficha antes de cada llamada, 3) aprender de mis correcciones en los correos. Configura solo ese y dime cómo lo pauso si no me gusta.
```

