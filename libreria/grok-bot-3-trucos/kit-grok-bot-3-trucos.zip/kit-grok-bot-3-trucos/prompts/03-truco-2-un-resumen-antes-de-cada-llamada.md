# 03 · Truco 2: un resumen antes de cada llamada

Conéctalo a tu calendario. El bot revisa la agenda cada 15 minutos, pero solo escribe cuando falta entre 15 y 35 minutos para una llamada, así la ficha te llega justo a tiempo: quién confirmó, qué tienes que lograr, de qué hablar y qué evitar. Si no hay llamada, no te escribe nada.

## Prompt para la rutina antes de cada llamada

```
Conéctate a mi calendario [GOOGLE CALENDAR / OUTLOOK]. Crea una rutina que revise mi agenda cada 15 minutos. Solo cuando una llamada empiece en 15 a 35 minutos, mándame una ficha corta:
- Quién está invitado y quién confirmó de verdad.
- La única cosa que tengo que lograr en esta llamada.
- 3 temas para hablar, con links a los correos, notas o transcripciones donde salen.
- Qué evitar (temas delicados, promesas que no puedo cumplir).
Si no hay llamada en esa ventana, no me escribas nada. Mándamela por [SLACK / LA APP / CORREO].
```

