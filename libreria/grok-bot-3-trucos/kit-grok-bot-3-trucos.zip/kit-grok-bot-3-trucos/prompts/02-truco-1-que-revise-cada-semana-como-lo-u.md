# 02 · Truco 1: que revise cada semana cómo lo usas

Una rutina semanal donde el bot se audita a sí mismo: qué le pediste a mano tres veces (eso debería ser una rutina), qué avisos te manda que nunca abres (eso sobra) y qué falta. Él te propone los cambios y tú apruebas lo que se queda. En la guía corre los miércoles.

## Prompt para la rutina semanal

```
Crea una rutina que corra todos los [MIÉRCOLES] a las [9:00]. En ella revisa la última semana:
1. Qué te pedí a mano 3 veces o más → propón convertirlo en una rutina.
2. Qué rutinas o avisos corrieron y yo nunca abrí → propón pausarlos o cambiarlos.
3. Qué debería existir y todavía no existe.
Mándame una lista corta con cada propuesta y un botón o respuesta de sí/no. No cambies nada hasta que yo apruebe.
```

