# 3 trucos de Grok Bot que usa su propio equipo

Una revisión semanal que mejora tus rutinas, un resumen antes de cada llamada y un bot que aprende de tus correcciones. Sale de la guía oficial de Grok Bot; aquí tienes cada rutina con su prompt listo para pegar.

Receta completa: https://lasaladeia.com/libreria/grok-bot-3-trucos/

Grok Bot te da agentes que trabajan dentro de tus apps, se acuerdan de tus instrucciones y siguen trabajando aunque cierres la laptop. En su guía para post-venta, el equipo de x.ai cuenta cómo lo usan: un bot jefe de equipo (Gus) que maneja a los demás, rutinas que corren solas y un bot de escritura (Ink) que aprende de lo que corriges. De ahí salen los 3 trucos del video. Los nombres de clientes del video (Maya Chen, Harbor, Atlas Q4) son ejemplos.

**Costo:** Grok Bot viene con los planes de Grok: Premium 30 USD/mes, Super 100 y Ultra 200 (revisa x.ai/bot). Los bots compartidos en Slack y Teams son de los planes Teams y Enterprise

**Tiempo:** 10 minutos por truco. Empieza por uno

## Herramientas
- Grok Bot: Los agentes de xAI: app de escritorio e iOS, Slack y Teams, y entran a llamadas de Meet, Zoom y Teams. https://x.ai/bot
- Guía «Grok Bot for Post-Sales»: La guía del equipo de Grok Bot de donde salen los 3 trucos (en inglés). https://x.ai/bot/guides/grok-bot-for-post-sales
- La Sala de IA: Aquí probamos estas herramientas primero y te contamos lo que sí sirve. https://lasaladeia.com/?utm_source=libreria

## Qué hay en este kit
- instalar.md: los comandos de instalación.
- prompts/: un archivo por paso con sus prompts.
