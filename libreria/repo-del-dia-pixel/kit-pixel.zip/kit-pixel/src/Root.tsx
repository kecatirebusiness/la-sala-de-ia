import React from 'react';
import {Composition} from 'remotion';
import {Pixel, DUR} from './Pixel';
export const Root: React.FC = () => (
  <Composition id="Pixel" component={Pixel} durationInFrames={DUR} fps={30} width={1080} height={1920} />
);
