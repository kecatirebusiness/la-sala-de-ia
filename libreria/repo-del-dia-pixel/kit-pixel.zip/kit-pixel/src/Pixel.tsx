import React from 'react';
import {AbsoluteFill, Audio, Img, Sequence, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont as inter} from '@remotion/google-fonts/Inter';
import {loadFont as mono} from '@remotion/google-fonts/JetBrainsMono';
import {LIP} from './lip';

const {fontFamily: SANS} = inter('normal', {weights: ['500', '700', '800'], subsets: ['latin', 'latin-ext']});
const {fontFamily: MONO} = mono('normal', {weights: ['400', '600', '700'], subsets: ['latin', 'latin-ext']});

export const DUR = 1575;
const FPS = 30;
const VERDE = '#00B85C';
const VERDE_CLARO = '#00D26A';
const BG = '#F5F6F8';
const TINTA = '#16181D';
const GRIS = '#8A8F98';
const LINEA = '#E2E5EA';

const f = (t: number) => Math.round(t * FPS);

// ---------- piezas ----------
const ease = (fr: number, start: number, len = 8) =>
  interpolate(fr, [start, start + len], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

const Pop: React.FC<{at?: number; children: React.ReactNode; style?: React.CSSProperties}> = ({at = 0, children, style}) => {
  const fr = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: fr - at, fps, config: {damping: 13, stiffness: 220, mass: 0.6}});
  return (
    <div style={{transform: `scale(${0.6 + 0.4 * s})`, opacity: fr < at ? 0 : Math.min(1, s * 1.6), transformOrigin: 'center', ...style}}>
      {children}
    </div>
  );
};

const Ventana: React.FC<{titulo?: string; icono?: 'claude' | 'carpeta'; children?: React.ReactNode; alto?: number}> = ({titulo = 'Claude Code', icono = 'claude', children, alto}) => (
  <div style={{background: '#fff', border: `2px solid ${LINEA}`, borderRadius: 10, boxShadow: '0 6px 18px rgba(20,25,35,.06)', overflow: 'hidden', minHeight: alto}}>
    <div style={{display: 'flex', alignItems: 'center', gap: 10, padding: '14px 18px', borderBottom: `2px solid ${LINEA}`, background: '#FAFBFC'}}>
      {['#FF5F57', '#FEBC2E', '#28C840'].map((c) => (
        <div key={c} style={{width: 14, height: 14, borderRadius: 7, background: c}} />
      ))}
      <span style={{marginLeft: 10, fontFamily: SANS, fontWeight: 700, fontSize: 22, color: TINTA, display: 'flex', alignItems: 'center', gap: 8}}>
        {icono === 'claude' ? <span style={{color: '#D97757', fontSize: 26}}>✳</span> : <span style={{fontSize: 22}}>📁</span>}
        {titulo}
      </span>
    </div>
    <div style={{padding: '18px 22px', fontFamily: MONO, fontSize: 25, color: TINTA, lineHeight: 1.55}}>{children}</div>
  </div>
);

const Tipea: React.FC<{texto: string; at: number; cps?: number; cursor?: boolean}> = ({texto, at, cps = 38, cursor = true}) => {
  const fr = useCurrentFrame();
  const n = Math.max(0, Math.floor(((fr - at) / FPS) * cps));
  const vis = texto.slice(0, n);
  const on = fr >= at && n < texto.length + 8 && cursor && Math.floor(fr / 8) % 2 === 0;
  if (fr < at) return null;
  return (
    <span>
      {vis}
      {on ? <span style={{background: TINTA, color: TINTA}}>_</span> : null}
    </span>
  );
};

const Prompt: React.FC<{texto: string; at: number}> = ({texto, at}) => {
  const fr = useCurrentFrame();
  if (fr < at) return null;
  return (
    <div style={{background: '#F3F4F6', border: `2px solid ${LINEA}`, borderRadius: 6, padding: '10px 14px', margin: '4px 0 8px'}}>
      <span style={{color: '#D97757'}}>&gt; </span>
      <Tipea texto={texto} at={at} />
    </div>
  );
};

const Linea: React.FC<{at: number; tipo?: 'punto' | 'ok' | 'cmd'; children: React.ReactNode}> = ({at, tipo = 'punto', children}) => {
  const fr = useCurrentFrame();
  if (fr < at) return null;
  const o = ease(fr, at, 5);
  const marca = tipo === 'ok' ? <span style={{color: VERDE}}>✓ </span> : tipo === 'cmd' ? <span style={{color: VERDE}}>$ </span> : <span>● </span>;
  return (
    <div style={{opacity: o, transform: `translateY(${(1 - o) * 8}px)`, color: tipo === 'ok' ? VERDE : TINTA}}>
      {marca}
      {children}
    </div>
  );
};

const Chip: React.FC<{children: React.ReactNode; at: number}> = ({children, at}) => {
  const fr = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: fr - at, fps, config: {damping: 11, stiffness: 200}});
  if (fr < at) return null;
  return (
    <div style={{display: 'flex', justifyContent: 'center', marginBottom: 18, transform: `translateY(${(1 - s) * -60}px)`, opacity: Math.min(1, s * 2)}}>
      <div style={{background: '#EAF9F1', border: `2px solid ${VERDE_CLARO}`, color: '#0B8A48', borderRadius: 30, padding: '8px 22px', fontFamily: MONO, fontWeight: 700, fontSize: 24, boxShadow: '0 4px 0 rgba(0,184,92,.15)'}}>
        {children}
      </div>
    </div>
  );
};

const Barra: React.FC<{at: number; len: number}> = ({at, len}) => {
  const fr = useCurrentFrame();
  if (fr < at) return null;
  const p = ease(fr, at, len);
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 14}}>
      <span>instalando</span>
      <div style={{flex: 1, height: 14, background: '#E6E8EC', borderRadius: 7, overflow: 'hidden'}}>
        <div style={{width: `${p * 100}%`, height: '100%', background: VERDE_CLARO}} />
      </div>
    </div>
  );
};

// figurita de palitos pixel
const Palito: React.FC<{reloj?: boolean}> = ({reloj}) => (
  <svg width="170" height="300" viewBox="0 0 34 60" shapeRendering="crispEdges">
    <g fill="none" stroke={TINTA} strokeWidth="1.6">
      {reloj ? (
        <>
          <circle cx="17" cy="6" r="5" />
          <line x1="17" y1="6" x2="17" y2="3" />
          <line x1="17" y1="6" x2="19.5" y2="6" />
          <line x1="15" y1="0.4" x2="19" y2="0.4" />
        </>
      ) : null}
      <circle cx="17" cy={reloj ? 19 : 10} r="5" />
      <line x1="17" y1={reloj ? 24 : 15} x2="17" y2="42" />
      <line x1="17" y1="30" x2="8" y2="36" />
      <line x1="17" y1="30" x2="26" y2="36" />
      <line x1="17" y1="42" x2="10" y2="56" />
      <line x1="17" y1="42" x2="24" y2="56" />
    </g>
    <g fill={TINTA}>
      <rect x="14.6" y={reloj ? 17.4 : 8.4} width="1.3" height="1.3" />
      <rect x="18.2" y={reloj ? 17.4 : 8.4} width="1.3" height="1.3" />
    </g>
    <path d={reloj ? 'M14.6 22 Q17 20.4 19.4 22' : 'M14.6 13 Q17 11.4 19.4 13'} stroke={TINTA} strokeWidth="1" fill="none" />
  </svg>
);

// boca pixel para Rhubarb (8 formas)
const BOCAS: number[][] = [
  [0, 0, 1, 1, 1, 1, 0, 0],
  [0, 1, 1, 1, 1, 1, 1, 0],
  [1, 1, 1, 1, 1, 1, 1, 1],
  [0, 1, 1, 1, 1, 1, 1, 0],
  [0, 0, 1, 1, 1, 1, 0, 0],
  [0, 0, 0, 1, 1, 0, 0, 0],
  [0, 1, 1, 1, 1, 1, 1, 0],
  [0, 0, 1, 1, 1, 1, 0, 0],
];
const ALTOS = [1, 2, 4, 3, 3, 2, 1, 2];
const Boca: React.FC<{i: number; activa?: boolean}> = ({i, activa}) => {
  const fila = BOCAS[i];
  const h = ALTOS[i];
  return (
    <div style={{width: 74, height: 54, borderRadius: 8, border: `3px solid ${activa ? VERDE_CLARO : '#D9DCE1'}`, background: activa ? '#EAF9F1' : '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', transform: activa ? 'scale(1.12)' : 'none'}}>
      <div style={{display: 'grid', gridTemplateColumns: 'repeat(8, 6px)'}}>
        {Array.from({length: h}).map((_, r) =>
          fila.map((v, c) => (
            <div key={`${r}-${c}`} style={{width: 6, height: 6, background: v ? (r === 0 && h > 2 ? '#fff' : r === h - 1 && h > 2 ? '#B0485A' : '#3A1218') : 'transparent', outline: v ? '0.5px solid #3A1218' : 'none'}} />
          )),
        )}
      </div>
    </div>
  );
};

const Rhubarb: React.FC<{animar?: boolean; at: number}> = ({animar, at}) => {
  const fr = useCurrentFrame();
  const act = animar ? Math.floor((fr - at) / 4) % 8 : -1;
  return (
    <div style={{background: '#fff', border: `2px solid ${LINEA}`, borderRadius: 10, padding: '26px 20px 30px'}}>
      <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 16, marginBottom: 26}}>
        <svg width="70" height="56" viewBox="0 0 14 11" shapeRendering="crispEdges">
          <path d="M0 0h2v2h2v2h6v-2h2v-2h2v5h-1v2h-1v2h-2v1h-6v-1h-2v-2h-1v-2h-1z" fill={TINTA} />
          <path d="M3 5h8v2h-1v1h-6v-1h-1z" fill="#E8457A" />
        </svg>
        <div style={{fontFamily: SANS}}>
          <div style={{fontWeight: 800, fontSize: 40, color: TINTA, lineHeight: 1}}>Rhubarb</div>
          <div style={{fontWeight: 500, fontSize: 22, color: '#E8457A'}}>Lip Sync</div>
        </div>
      </div>
      <div style={{display: 'flex', justifyContent: 'center', gap: 12}}>
        {BOCAS.map((_, i) => (
          <Boca key={i} i={i} activa={i === act} />
        ))}
      </div>
      {animar ? (
        <div style={{display: 'flex', justifyContent: 'center', gap: 22, marginTop: 24, fontFamily: SANS, fontWeight: 700, fontSize: 30}}>
          {['la', 'boca', 'se', 'mueve'].map((w, i) => {
            const on = Math.floor((fr - at) / 9) % 4 === i;
            return (
              <span key={w} style={{background: on ? VERDE_CLARO : 'transparent', color: on ? '#fff' : TINTA, padding: '2px 12px', borderRadius: 6}}>
                {w}
              </span>
            );
          })}
        </div>
      ) : null}
    </div>
  );
};

const Onda: React.FC<{color?: string; n?: number; at: number}> = ({color = VERDE_CLARO, n = 42, at}) => {
  const fr = useCurrentFrame();
  return (
    <div style={{display: 'flex', alignItems: 'center', gap: 5, height: 120}}>
      {Array.from({length: n}).map((_, i) => {
        const h = 14 + Math.abs(Math.sin(i * 1.7 + (fr - at) * 0.35) * Math.cos(i * 0.6)) * 100;
        const vis = fr - at > i * 0.6;
        return <div key={i} style={{width: 9, height: vis ? h : 6, background: color, borderRadius: 2}} />;
      })}
    </div>
  );
};

// ---------- tarjetas por escena ----------
const Card: React.FC<{id: string; at: number}> = ({id, at}) => {
  const fr = useCurrentFrame();
  const a = (t: number) => f(t) - at; // tiempo absoluto -> frame local
  switch (id) {
    case 'github':
      return fr < a(1.0) ? (
        <Pop at={0} style={{display: 'flex', justifyContent: 'center', paddingTop: 30}}>
          <div style={{width: 230, height: 230, borderRadius: 40, background: '#B9BDC4', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <Img src={staticFile('logos/github.svg')} style={{width: 150, filter: 'invert(1)'}} />
          </div>
        </Pop>
      ) : (
        <Pop at={a(1.0)}>
          <div style={{background: '#fff', border: `2px solid ${LINEA}`, borderRadius: 10, overflow: 'hidden'}}>
            <div style={{padding: '12px 18px', borderBottom: `2px solid ${LINEA}`, fontFamily: SANS, fontWeight: 700, fontSize: 20, color: TINTA}}>📖 README</div>
            <div style={{padding: '26px 20px 30px', textAlign: 'center', fontFamily: SANS}}>
              <div style={{fontWeight: 800, fontSize: 64, color: TINTA, letterSpacing: -1}}>
                <span style={{color: '#E8457A'}}>◈</span> hypit
              </div>
              <div style={{fontWeight: 500, fontSize: 26, color: '#444', marginTop: 6}}>Clona cualquier video viral con agentes de IA</div>
              <div style={{display: 'inline-block', marginTop: 18, border: `2px solid #333`, borderRadius: 8, padding: '6px 16px', fontWeight: 700, fontSize: 24}}>🏅 #1 Repositorio del día</div>
            </div>
          </div>
        </Pop>
      );
    case 'agente':
      return (
        <Pop at={0}>
          <Ventana>
            <Prompt texto="Convierte este reel en una plantilla 1:1" at={a(6.9)} />
          </Ventana>
        </Pop>
      );
    case 'terminal':
      return (
        <div>
          <Chip at={0}>🎬 kevin-reel.mp4</Chip>
          <Ventana>
            <Linea at={a(9.0)}>Leyendo el reel</Linea>
            <Linea at={a(9.5)}>Mapeando cada corte</Linea>
            <Linea at={a(10.1)} tipo="ok">Plantilla lista</Linea>
          </Ventana>
        </div>
      );
    case 'palito':
      return (
        <div style={{display: 'flex', alignItems: 'center', gap: 20, paddingLeft: 40}}>
          <Palito reloj />
          {fr >= a(12.44) ? (
            <Pop at={a(12.44)}>
              <div style={{border: `3px solid ${TINTA}`, borderRadius: 14, padding: '18px 26px', background: '#fff', fontFamily: SANS, fontWeight: 800, fontSize: 40, color: TINTA, lineHeight: 1.1}}>
                No tengo
                <br />
                tiempo
              </div>
            </Pop>
          ) : null}
        </div>
      );
    case 'ahora':
      return (
        <div style={{display: 'flex', alignItems: 'center', gap: 20, paddingLeft: 40}}>
          <Palito />
          <Pop at={0}>
            <div style={{border: `3px solid ${VERDE_CLARO}`, borderRadius: 14, padding: '18px 26px', background: '#EAF9F1', fontFamily: SANS, fontWeight: 800, fontSize: 40, color: '#0B8A48', lineHeight: 1.1}}>
              ¡Ahora sí
              <br />
              tengo! ⏱
            </div>
          </Pop>
        </div>
      );
    case 'bienvenido':
      return (
        <Pop at={0}>
          <Ventana>
            <Linea at={4}>Bienvenido a Claude Code</Linea>
          </Ventana>
        </Pop>
      );
    case 'repo':
      return (
        <div>
          <Chip at={0}>🔗 github.com/hypit-ai/hypit</Chip>
          <Ventana>
            <Prompt texto="Instala github.com/hypit-ai/hypit" at={8} />
            <Linea at={a(18.9)} tipo="cmd">npx skills add hypit-ai/hypit -g</Linea>
            <Barra at={a(19.2)} len={22} />
          </Ventana>
        </div>
      );
    case 'reels':
      return (
        <Pop at={0}>
          <Ventana titulo="@kecatire · reels top" icono="carpeta">
            <div style={{display: 'flex', gap: 14, justifyContent: 'center'}}>
              {['r1', 'r2', 'r3', 'r4'].map((r, i) => (
                <Pop key={r} at={6 + i * 6}>
                  <div style={{textAlign: 'center', fontFamily: SANS, fontSize: 20, fontWeight: 700}}>
                    <Img src={staticFile(`img/${r}.jpg`)} style={{width: 200, height: 300, objectFit: 'cover', borderRadius: 8, border: `2px solid ${LINEA}`}} />
                    <div>reel-{i + 1}</div>
                  </div>
                </Pop>
              ))}
            </div>
          </Ventana>
        </Pop>
      );
    case 'hyper':
      return (
        <Pop at={0}>
          <Ventana>
            <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 20, padding: '40px 0', fontFamily: SANS}}>
              <div>
                <div style={{fontWeight: 700, fontSize: 30, color: TINTA}}>HeyGen</div>
                <div style={{fontWeight: 800, fontSize: 66, color: TINTA, letterSpacing: -2, lineHeight: 1}}>HyperFrames</div>
              </div>
              <svg width="100" height="80" viewBox="0 0 10 8">
                <path d="M0 4 L3 0 L5 4 L3 8Z" fill={VERDE_CLARO} />
                <path d="M5 4 L7 0 L10 4 L7 8Z" fill={VERDE_CLARO} />
              </svg>
            </div>
          </Ventana>
        </Pop>
      );
    case 'hazvideo':
      return (
        <Pop at={0}>
          <Ventana>
            <Prompt texto="Hazme el video" at={3} />
            <Linea at={a(26.9)}>Listo, cuando quieras</Linea>
          </Ventana>
        </Pop>
      );
    case 'clona':
      return (
        <Pop at={0}>
          <div style={{background: '#fff', border: `2px solid ${LINEA}`, borderRadius: 10, padding: '18px 24px'}}>
            <div style={{display: 'flex', justifyContent: 'space-between', fontFamily: SANS, fontWeight: 700, fontSize: 24}}>
              <span>🐟 Higgsfield Voice</span>
              <span style={{background: '#EAF9F1', color: '#0B8A48', border: `2px solid ${VERDE_CLARO}`, borderRadius: 20, padding: '2px 14px', fontSize: 20}}>Clon de voz</span>
            </div>
            <div style={{display: 'flex', justifyContent: 'center', margin: '14px 0'}}>
              <Onda at={0} />
            </div>
            <div style={{fontFamily: SANS, fontWeight: 700, fontSize: 24}}>Clonando tu voz</div>
            <div style={{height: 12, background: '#E6E8EC', borderRadius: 6, marginTop: 10, overflow: 'hidden'}}>
              <div style={{width: `${ease(fr, 0, 30) * 70}%`, height: '100%', background: VERDE_CLARO}} />
            </div>
          </div>
        </Pop>
      );
    case 'graba':
      return (
        <Pop at={0}>
          <div style={{background: '#fff', border: `2px solid ${LINEA}`, borderRadius: 10, padding: '24px', display: 'flex', alignItems: 'center', gap: 26}}>
            <svg width="120" height="180" viewBox="0 0 12 18" fill="none" stroke={TINTA} strokeWidth="0.9">
              <rect x="3" y="1" width="6" height="10" rx="3" />
              <path d="M1 8 Q1 14 6 14 Q11 14 11 8" />
              <line x1="6" y1="14" x2="6" y2="17" />
              <line x1="3" y1="17" x2="9" y2="17" />
            </svg>
            <div>
              <div style={{fontFamily: SANS, fontWeight: 800, color: '#E5484D', fontSize: 26, opacity: Math.floor(fr / 10) % 2 ? 1 : 0.35}}>● REC</div>
              <Onda at={0} n={26} color="#E5484D" />
              <div style={{fontFamily: SANS, fontWeight: 700, fontSize: 24}}>Grabando tu guion</div>
            </div>
          </div>
        </Pop>
      );
    case 'audio':
      return (
        <div>
          <Chip at={0}>🔊 voz.wav</Chip>
          <Ventana>
            <Prompt texto="Usa esta pista de audio" at={6} />
            <Linea at={a(31.2)} tipo="ok">Pista de audio cargada</Linea>
          </Ventana>
        </div>
      );
    case 'munequito': {
      const ps = ['saluda', 'apunta_cam', 'pulgar', 'hombros', 'paz', 'puno'];
      return (
        <div>
          <Pop at={0}>
            <Ventana titulo="pixel-kevin" icono="carpeta">
              <div style={{display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6}}>
                {ps.map((p, i) => (
                  <Pop key={p} at={3 + i * 4} style={{display: 'flex', justifyContent: 'center'}}>
                    <div style={{width: 150, height: 130, overflow: 'hidden', display: 'flex', justifyContent: 'center'}}>
                      <Img src={staticFile(`sprites/${p}_c.png`)} style={{width: 170, height: 227, imageRendering: 'pixelated', marginTop: -6}} />
                    </div>
                  </Pop>
                ))}
              </div>
            </Ventana>
          </Pop>
          <Chip at={a(33.2)}>✦ Hecho con Higgsfield</Chip>
        </div>
      );
    }
    case 'rhubarb':
      return (
        <Pop at={0}>
          <Rhubarb at={0} />
        </Pop>
      );
    case 'sync':
      return <Rhubarb animar at={0} />;
    case 'recursos': {
      const ls = ['github', 'instagram', 'claude', 'elevenlabs', 'tiktok', 'youtube', 'figma', 'notion', 'spotify', 'whatsapp'];
      return (
        <div>
          <div style={{display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 14, marginBottom: 18}}>
            {ls.map((l, i) => (
              <Pop key={l} at={i * 2} style={{display: 'flex', justifyContent: 'center'}}>
                <div style={{width: 100, height: 100, borderRadius: 18, background: '#fff', border: `2px solid ${LINEA}`, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                  <Img src={staticFile(`logos/${l}.svg`)} style={{width: 56, height: 56}} />
                </div>
              </Pop>
            ))}
          </div>
          <Ventana>
            <Prompt texto="Usa todos estos recursos" at={a(38.3)} />
          </Ventana>
        </div>
      );
    }
    case 'dictado':
      return (
        <div>
          <Pop at={0} style={{display: 'flex', justifyContent: 'center', marginBottom: 18}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 14, background: TINTA, color: '#fff', borderRadius: 40, padding: '12px 26px', fontFamily: SANS, fontWeight: 700, fontSize: 26}}>
              <span style={{width: 20, height: 20, borderRadius: 10, background: '#E5484D', opacity: Math.floor(fr / 8) % 2 ? 1 : 0.4}} />
              <Tipea texto="nuevo titular en cada frase…" at={6} cps={22} cursor={false} />
            </div>
          </Pop>
          <Ventana>
            <Prompt texto="Abre con el logo de GitHub, mete un titular nuevo en cada frase" at={a(40.4)} />
          </Ventana>
        </div>
      );
    case 'exacto':
      return (
        <Ventana>
          <Prompt texto="Hazlo con mi audio" at={0} />
          <Linea at={a(42.2)} tipo="ok">Pista de audio</Linea>
          <Linea at={a(42.6)} tipo="ok">Formas de boca</Linea>
          <Linea at={a(43.0)} tipo="ok">Escenas</Linea>
        </Ventana>
      );
    case 'final': {
      const sel = fr > a(44.8);
      const cur = interpolate(fr, [a(44.0), a(44.8)], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
      return (
        <Pop at={0}>
          <Ventana titulo="renders" icono="carpeta" alto={380}>
            <div style={{fontFamily: SANS, fontSize: 26, position: 'relative'}}>
              {['borrador-01.mp4', 'borrador-02.mp4', 'final.mp4'].map((n, i) => (
                <div key={n} style={{padding: '10px 14px', borderRadius: 6, marginBottom: 6, background: sel && i === 2 ? '#1F6FEB' : 'transparent', color: sel && i === 2 ? '#fff' : TINTA, fontWeight: 600}}>
                  🎞 {n}
                </div>
              ))}
              <div style={{position: 'absolute', left: 380 - cur * 120, top: 240 - cur * 70 + 70, fontSize: 40}}>➤</div>
            </div>
          </Ventana>
        </Pop>
      );
    }
    case 'acceso':
      return (
        <Pop at={0} style={{display: 'flex', justifyContent: 'center', paddingTop: 20}}>
          <div style={{width: 260, height: 260, borderRadius: 30, background: TINTA, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <Img src={staticFile('img/lasala.png')} style={{width: 200}} />
          </div>
        </Pop>
      );
    case 'comenta':
      return (
        <div>
          <Pop at={0}>
            <div style={{background: '#fff', border: `2px solid ${LINEA}`, borderRadius: 10, overflow: 'hidden'}}>
              <div style={{display: 'flex', gap: 24, padding: '12px 20px', borderBottom: `2px solid ${LINEA}`, fontFamily: SANS, fontSize: 22}}>
                <b>Escribir</b>
                <span style={{color: GRIS}}>Vista previa</span>
              </div>
              <div style={{padding: 20}}>
                <div style={{border: `3px solid #1F6FEB`, borderRadius: 8, padding: '18px 22px', fontFamily: MONO, fontWeight: 700, fontSize: 92, letterSpacing: 6, color: TINTA, minHeight: 120}}>
                  <Tipea texto="VIDEO" at={4} cps={9} />
                </div>
                <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 16, fontFamily: SANS, fontSize: 22, color: GRIS}}>
                  <span>Deja un comentario</span>
                  <span style={{background: fr > a(50.1) ? '#1A7F37' : '#2DA44E', color: '#fff', fontWeight: 700, borderRadius: 8, padding: '10px 24px', transform: fr > a(50.1) && fr < a(50.4) ? 'scale(.94)' : 'none'}}>Comentar</span>
                </div>
              </div>
            </div>
          </Pop>
          {fr > a(50.2) ? (
            <Pop at={a(50.2)} style={{textAlign: 'center', marginTop: 22, fontFamily: SANS, fontWeight: 800, fontSize: 36, color: TINTA}}>
              Te mando todos los recursos
            </Pop>
          ) : null}
        </div>
      );
  }
  return null;
};

// ---------- guion ----------
type Esc = {t: number; paso: number; l1: string; l2?: string; pose: string; card?: string; grande?: boolean};
const ESC: Esc[] = [
  {t: 0, paso: 1, l1: 'Número uno', l2: 'Repo del día', pose: 'apunta_cam', card: 'github'},
  {t: 2.72, paso: 1, l1: 'Esto lo', l2: 'cambia todo', pose: 'dedo_arriba', grande: true},
  {t: 5.12, paso: 2, l1: 'Tu agente', l2: 'de IA', pose: 'hombros', card: 'agente'},
  {t: 8.6, paso: 2, l1: 'Directo a', l2: 'la terminal', pose: 'apunta_der', card: 'terminal'},
  {t: 10.98, paso: 3, l1: 'Si tú dices…', pose: 'brazos', card: 'palito'},
  {t: 14.1, paso: 3, l1: 'Pues ahora', l2: 'sí lo tienes', pose: 'ok', card: 'ahora'},
  {t: 15.48, paso: 4, l1: '¿Usas', l2: 'Claude Code?', pose: 'hombros', card: 'bienvenido'},
  {t: 17.46, paso: 4, l1: 'Dale', l2: 'este repo', pose: 'dedo_arriba', card: 'repo'},
  {t: 20.06, paso: 5, l1: 'Reels que', l2: 'están pegando', pose: 'ok', card: 'reels'},
  {t: 23.9, paso: 6, l1: 'Suma', l2: 'HyperFrames', pose: 'paz', card: 'hyper'},
  {t: 25.72, paso: 6, l1: 'Claude te hace', l2: 'el video', pose: 'puno', card: 'hazvideo'},
  {t: 27.48, paso: 7, l1: 'Clona', l2: 'tu voz', pose: 'hombros', card: 'clona'},
  {t: 28.48, paso: 7, l1: 'O grábala', l2: 'tú mismo', pose: 'dedo_arriba', card: 'graba'},
  {t: 29.92, paso: 7, l1: 'Pásale', l2: 'el audio', pose: 'apunta_der', card: 'audio'},
  {t: 31.74, paso: 8, l1: 'Tu muñequito', l2: 'digital', pose: 'saluda', card: 'munequito'},
  {t: 34.14, paso: 8, l1: 'Usa', l2: 'Rhubarb', pose: 'apunta_der', card: 'rhubarb'},
  {t: 35.5, paso: 8, l1: 'Boca sincronizada', l2: 'con tu voz', pose: 'apunta_der', card: 'sync'},
  {t: 37.32, paso: 9, l1: 'Un montón', l2: 'de recursos', pose: 'puno', card: 'recursos'},
  {t: 39.54, paso: 10, l1: 'Voz', l2: 'a texto', pose: 'hombros', card: 'dictado'},
  {t: 41.44, paso: 10, l1: 'Exactamente', l2: 'cómo va', pose: 'apunta_cam', card: 'exacto'},
  {t: 43.7, paso: 11, l1: 'El resultado', l2: 'final', pose: 'apunta_der', card: 'final'},
  {t: 46.5, paso: 12, l1: '¿Quieres', l2: 'acceso?', pose: 'apunta_cam', card: 'acceso'},
  {t: 47.3, paso: 12, l1: 'El truco más', l2: 'fácil del mundo', pose: 'dedo_arriba', card: 'acceso'},
  {t: 49.24, paso: 12, l1: 'Comenta', pose: 'pulgar', card: 'comenta'},
];
const TOTAL_PASOS = 12;

const Titulo: React.FC<{e: Esc}> = ({e}) => {
  const fr = useCurrentFrame();
  const s1 = ease(fr, 0, 5);
  const s2 = ease(fr, 3, 5);
  const fs = e.grande ? 104 : 74;
  return (
    <div style={{fontFamily: SANS, fontWeight: 800, fontSize: fs, lineHeight: 1.04, letterSpacing: -2.5}}>
      <div style={{color: TINTA, opacity: s1, transform: `translateY(${(1 - s1) * 20}px)`}}>{e.l1}</div>
      {e.l2 ? <div style={{color: VERDE, opacity: s2, transform: `translateY(${(1 - s2) * 20}px)`}}>{e.l2}</div> : null}
    </div>
  );
};

const Cabecera: React.FC<{paso: number}> = ({paso}) => (
  <div style={{position: 'absolute', top: 92, left: 48, right: 48, display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontFamily: MONO, fontSize: 24}}>
    <span style={{background: '#E3F7EC', color: '#0B8A48', borderRadius: 6, padding: '4px 12px', fontWeight: 700}}>
      $ {String(paso).padStart(2, '0')}/{TOTAL_PASOS}
    </span>
    <span style={{color: GRIS}}>
      kecatire / <b style={{color: VERDE}}>la-sala</b>
    </span>
  </div>
);

// cuadrícula tipo contribuciones de GitHub
const Grilla: React.FC<{paso: number}> = ({paso}) => {
  const cols = 8;
  const rows = 5;
  const llenas = Math.round((paso / TOTAL_PASOS) * cols * rows);
  const tonos = ['#9BE9A8', '#40C463', '#30A14E', '#216E39'];
  return (
    <div style={{position: 'absolute', right: 40, bottom: 70, display: 'grid', gridTemplateColumns: `repeat(${cols}, 30px)`, gap: 5}}>
      {Array.from({length: cols * rows}).map((_, i) => {
        const c = i % cols;
        const r = Math.floor(i / cols);
        const idx = c * rows + r; // llena por columnas
        const on = idx < llenas;
        return <div key={i} style={{width: 30, height: 30, borderRadius: 3, background: on ? tonos[(i * 7 + r) % 4] : '#E4E7EB'}} />;
      })}
    </div>
  );
};

const Mascota: React.FC<{pose: string; desde: number}> = ({pose, desde}) => {
  const fr = useCurrentFrame();
  const lip = LIP[Math.min(fr, LIP.length - 1)] ?? 0;
  const abierta = fr < LIP.length && lip === 1;
  const k = fr - desde;
  const sq = k < 6 ? [1.04, 0.97, 1.02, 0.99, 1.005, 1][k] : 1;
  return (
    <div style={{position: 'absolute', left: -70, top: 1010, width: 780, height: 1040, transform: `scale(${sq})`, transformOrigin: '50% 100%'}}>
      <Img src={staticFile(`sprites/${pose}_${abierta ? 'o' : 'c'}.png`)} style={{width: '100%', height: '100%', imageRendering: 'pixelated'}} />
    </div>
  );
};

const SFX: React.FC = () => {
  const s: React.ReactNode[] = [];
  const add = (t: number, file: string, v = 0.35) =>
    s.push(
      <Sequence key={`${file}-${t}`} from={f(t)} durationInFrames={45}>
        <Audio src={staticFile(`sfx3/${file}`)} volume={v} />
      </Sequence>,
    );
  const pops = ['pop_03.ogg', 'pop_07.ogg', 'pop_11.ogg', 'pop_15.ogg'];
  ESC.forEach((e, i) => add(e.t, pops[i % pops.length], 0.32));
  [6.9, 17.75, 26.0, 30.3, 38.3, 40.4, 41.44].forEach((t) => {
    for (let k = 0; k < 6; k++) add(t + k * 0.11, `tecla_0${(k % 5) + 1}.ogg`, 0.18);
  });
  [10.1, 31.2, 42.2, 42.6, 43.0].forEach((t) => add(t, 'exito_02.ogg', 0.22));
  [8.6, 17.46, 29.92, 33.2].forEach((t) => add(t, 'whoosh_03.ogg', 0.25));
  [44.8, 50.1].forEach((t) => add(t, 'click_04.ogg', 0.4));
  [49.4, 49.5, 49.6, 49.7, 49.8].forEach((t, k) => add(t, `tecla_0${k + 1}.ogg`, 0.25));
  return <>{s}</>;
};

export const Pixel: React.FC = () => {
  const fr = useCurrentFrame();
  const i = ESC.reduce((acc, e, k) => (fr >= f(e.t) ? k : acc), 0);
  const e = ESC[i];
  return (
    <AbsoluteFill style={{background: BG}}>
      <Audio src={staticFile('voz.wav')} />
      <SFX />
      <Cabecera paso={e.paso} />
      {ESC.map((x, k) => {
        const ini = f(x.t);
        const fin = k + 1 < ESC.length ? f(ESC[k + 1].t) : DUR;
        const mismoTit = k > 0 && ESC[k - 1].l1 === x.l1;
        return (
          <Sequence key={k} from={ini} durationInFrames={fin - ini}>
            <div style={{position: 'absolute', top: 150, left: 48, right: 48}}>
              <Titulo e={x} />
              <div style={{height: 3, background: LINEA, marginTop: 22}} />
            </div>
            {x.card ? (
              <div style={{position: 'absolute', top: x.grande ? 430 : 385, left: 100, right: 100, transform: 'scale(1.15)', transformOrigin: '50% 0%'}}>
                <Card id={x.card} at={ini} />
              </div>
            ) : null}
            {mismoTit ? null : null}
          </Sequence>
        );
      })}
      <Mascota pose={e.pose} desde={f(e.t)} />
      <Grilla paso={e.paso} />
    </AbsoluteFill>
  );
};
