# Kit · Muñequito pixel que habla (La Sala de IA)

Proyecto de Remotion del video "Repo del día" en formato pixel.

## Qué trae
- `src/Pixel.tsx`: el video completo. Todas las escenas están en el array `ESC`: tiempo, título, pose y tarjeta.
- `src/lip.ts`: qué fotograma tiene la boca abierta. Se genera desde tu audio con `lip.py`.
- `public/sprites/`: 11 poses de ejemplo, cada una con la boca cerrada (`_c`) y abierta (`_o`). Reemplázalas por las tuyas con los mismos nombres.

## Cómo usarlo
1. Instala Node 20 o más nuevo. Luego, en esta carpeta, corre `npm i`.
2. Pon tu voz en `public/voz.wav`. Después corre `python3 lip.py public/voz.wav` (necesita numpy).
3. Cambia los tiempos y textos de `ESC` según tu guion. Pídeselo a Claude Code y pásale la transcripción con tiempos.
4. Faltan dos carpetas: `public/sfx3/` (sonidos .ogg) y `public/logos/` (íconos .svg). Pon tus propios archivos ahí o pídele a Claude que quite esas partes.
5. Previsualiza con `npx remotion studio src/index.ts`.
6. Renderiza con `npx remotion render src/index.ts Pixel out/video.mp4`.
