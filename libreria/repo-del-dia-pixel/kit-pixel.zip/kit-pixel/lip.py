# Genera src/lip.ts (boca abierta/cerrada por fotograma a 30 fps) desde un .wav
import sys, wave, json, numpy as np
w = wave.open(sys.argv[1]); sr = w.getframerate(); ch = w.getnchannels()
x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(float)
if ch > 1: x = x.reshape(-1, ch).mean(1)
hop = sr // 30
r = np.array([np.sqrt((x[i*hop:(i+1)*hop]**2).mean()) for i in range(len(x)//hop)]); r /= np.percentile(r, 95)
out, run = [], 0
for v in np.where(r > 0.45, 1, 0):
    run = run + 1 if v else 0
    out.append(0 if (v and run % 5 == 4) else int(v))
open('src/lip.ts', 'w').write('export const LIP=%s;\n' % json.dumps(out))
print(len(out), 'frames')
