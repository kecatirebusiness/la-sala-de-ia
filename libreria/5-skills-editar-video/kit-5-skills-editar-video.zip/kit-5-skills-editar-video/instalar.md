# Instalar

Los comandos que empiezan con / se escriben dentro de Claude Code. Los demás, en la terminal (o pídeselos a Claude Code). Después de instalar plugins: /reload-plugins.

## kurbaitaev/ghost-editor
https://github.com/kurbaitaev/ghost-editor

```
Install the ghost-editor skill: clone https://github.com/kurbaitaev/ghost-editor into ~/.claude/skills/ghost-editor and follow its docs/INSTALL.md.
```

## AgriciDaniel/claude-shorts
https://github.com/AgriciDaniel/claude-shorts

```
git clone https://github.com/AgriciDaniel/claude-shorts.git && cd claude-shorts && bash setup.sh && bash install.sh
```

## OpenMontageInc/OpenMontage
https://github.com/OpenMontageInc/OpenMontage

```
git clone https://github.com/OpenMontageInc/OpenMontage.git && cd OpenMontage && make setup
```

## kajisho5/ffmpeg-skill
https://github.com/kajisho5/ffmpeg-skill

```
npx ffmpeg-skill setup
```

