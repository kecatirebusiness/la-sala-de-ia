# 02 · ¿Tienes un video largo? Claude Shorts

Un podcast o un live: encuentra los mejores momentos y te los devuelve como clips verticales con subtítulos. Tú decides cuáles se quedan antes de que los renderice.

## Prompt para Claude Code: sacar clips

```
Instala claude-shorts (https://github.com/AgriciDaniel/claude-shorts) siguiendo su README: git clone, bash setup.sh y bash install.sh. Después busca los 5 mejores momentos de [RUTA/A/TU-PODCAST.mp4] para clips verticales de 30 a 60 segundos. Enséñame la lista con el minuto de inicio, el gancho de cada uno y su nota, y renderiza solo los que yo apruebe.
```

