# 01 · ¿Te grabaste hablando a cámara? Ghost Editor

Le das tu toma cruda y escoge la mejor versión de cada frase, pone subtítulos que nunca te tapan la cara y añade gráficos y efectos de sonido. Trae 19 estilos. Solo Mac con chip Apple y unos 4 GB de disco.

## Prompt para Claude Code: instalar y editar con Ghost Editor

```
Install the ghost-editor skill: clone https://github.com/kurbaitaev/ghost-editor into ~/.claude/skills/ghost-editor and follow its docs/INSTALL.md.

Cuando esté instalado: edita [RUTA/A/TU-VIDEO.mov] en un reel vertical. Quédate con la mejor toma de cada frase, subtítulos que no me tapen la cara y gráficos donde ayuden. Antes de renderizar enséñame la página de aprobación con un fotograma en cada corte.
```

