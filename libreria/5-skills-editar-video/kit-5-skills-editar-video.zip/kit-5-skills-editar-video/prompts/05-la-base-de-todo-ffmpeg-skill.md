# 05 · La base de todo: FFmpeg Skill

42 herramientas para cortar silencios, poner subtítulos, pasar a vertical y nivelar el audio. No decide qué cortar: ejecuta y comprueba lo que Claude decide. Corre en tu computadora y es gratis. Las otras skills se apoyan en FFmpeg, así que instálala primero.

## Comando

```
npx ffmpeg-skill setup
```

## Prompt para Claude Code: limpieza básica

```
Con ffmpeg-skill, toma [RUTA/A/TU-VIDEO.mp4]: corta los silencios de más de medio segundo, pásalo a vertical 1080×1920 centrado en mi cara, nivela el audio para Instagram y expórtalo. Al final enséñame la página de revisión.
```

