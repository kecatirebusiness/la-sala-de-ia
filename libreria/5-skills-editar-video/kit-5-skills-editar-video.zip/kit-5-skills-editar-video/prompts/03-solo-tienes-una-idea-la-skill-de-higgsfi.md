# 03 · ¿Solo tienes una idea? La skill de Higgsfield

«Editorial motion graphics» de Higgsfield: le das el tema y te arma un video animado con escenas, voz en off y subtítulos, sin grabarte. Necesita el conector (MCP) de Higgsfield en Claude y gasta créditos de Higgsfield. En Higgsfield la encuentras en Skills → Editorial motion graphics.

## Comando: conectar Higgsfield a Claude Code

```
claude mcp add --transport http higgsfield https://mcp.higgsfield.ai/mcp
```

## Prompt para Claude (con Higgsfield conectado)

```
Create a faceless explainer video in an editorial motion graphics style about [TU TEMA, ej. cómo se forma un huracán], using cutout illustrations, labels and quick visual transitions. Narración en español latino, subtítulos y formato vertical 9:16. Antes de generar, dime cuántos créditos va a gastar.
```

