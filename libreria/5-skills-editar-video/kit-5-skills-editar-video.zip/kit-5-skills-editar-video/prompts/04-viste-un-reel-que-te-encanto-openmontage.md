# 04 · ¿Viste un reel que te encantó? OpenMontage

Estudia su gancho, su ritmo y su edición y usa esa estructura para un video de tu tema. Se queda con la estructura y el estilo del gancho, no con el contenido: inspiración, no copia.

## Prompt para Claude Code: estructura de un reel, tu tema

```
Instala OpenMontage (https://github.com/OpenMontageInc/OpenMontage) siguiendo su README. Después analiza este reel que me gustó: [RUTA O LINK]. Dime su gancho, el ritmo de los cortes y la estructura escena por escena. Con esa estructura, arma un video de mi tema: [TU TEMA]. No copies sus textos, imágenes ni música.
```

