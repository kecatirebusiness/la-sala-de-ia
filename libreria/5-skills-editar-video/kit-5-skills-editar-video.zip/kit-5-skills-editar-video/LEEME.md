# 5 skills que convierten a Claude en tu editor de video

Cuál usar depende de lo que tengas: una toma hablando a cámara, un podcast largo, solo una idea, un reel que te encantó o material para cortar. Cada una con su link real y cómo instalarla.

Receta completa: https://lasaladeia.com/libreria/5-skills-editar-video/

Una skill le enseña a Claude un trabajo completo. Ghost Editor es para tu toma a cámara (solo Mac con chip Apple), Claude Shorts saca clips verticales de un video largo, la skill de Higgsfield arma un video animado desde una idea, OpenMontage estudia un reel que te gustó y usa su estructura para tu tema, y FFmpeg Skill es la base que corta, subtitula y exporta en tu computadora.

**Costo:** Ghost Editor, Claude Shorts, OpenMontage y FFmpeg Skill son gratis y de código abierto. La skill de Higgsfield gasta créditos de Higgsfield. Para todas necesitas un plan de pago de Claude

**Tiempo:** 10 a 20 minutos por skill (Ghost Editor baja unos 4 GB la primera vez)

## Herramientas
- Higgsfield: La skill «Editorial motion graphics»: le das un tema y arma el video animado con escenas, voz y subtítulos. Se usa con el conector (MCP) de Higgsfield. https://higgsfield.ai?fpr=kecatire
- Claude Code: Donde corren las skills. https://claude.com/claude-code
- La Sala de IA: Aquí editamos así nuestros reels y te enseñamos el proceso en vivo. https://lasaladeia.com/?utm_source=libreria

## Repos
- kurbaitaev/ghost-editor: https://github.com/kurbaitaev/ghost-editor
- AgriciDaniel/claude-shorts: https://github.com/AgriciDaniel/claude-shorts
- OpenMontageInc/OpenMontage: https://github.com/OpenMontageInc/OpenMontage
- kajisho5/ffmpeg-skill: https://github.com/kajisho5/ffmpeg-skill

## Qué hay en este kit
- instalar.md: los comandos de instalación.
- prompts/: un archivo por paso con sus prompts.
