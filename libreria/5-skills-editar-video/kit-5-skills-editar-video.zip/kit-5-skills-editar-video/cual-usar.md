# ¿Cuál skill uso?

| Lo que tienes | Skill | Ojo |
|---|---|---|
| Una toma hablando a cámara | Ghost Editor | Solo Mac con chip Apple; ~4 GB; probado en inglés y ruso |
| Un video largo (podcast, live) | Claude Shorts | Windows: WSL 2; mejor con tarjeta NVIDIA |
| Solo una idea | Editorial motion graphics (Higgsfield) | Gasta créditos de Higgsfield; necesita su conector MCP |
| Un reel que te encantó | OpenMontage | Usa la estructura, no copia el contenido |
| Material para cortar, subtitular, pasar a vertical | FFmpeg Skill | Instálala primero: es la base |
