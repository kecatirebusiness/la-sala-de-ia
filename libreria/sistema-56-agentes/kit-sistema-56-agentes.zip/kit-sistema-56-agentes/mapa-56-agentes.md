# Mapa de los 56 agentes

Cada agente es UNA tarea pequeña con una o dos herramientas. No los montes todos: marca los 5 que más tiempo te quitan y empieza por ahí.

## Módulo 01 · Marketing (28 agentes)

### Investigación y tendencias · 7 agentes

| Agente | Herramientas | ¿Lo monto? |
|---|---|---|
| Detector de tendencias | Google Trends | [ ] |
| Analista de keywords | Semrush + Claude | [ ] |
| Investigador de audiencia | SparkToro + Semrush | [ ] |
| Agente de compradores | Google Drive + Claude | [ ] |
| Vigilante de competencia | X + Claude | [ ] |
| Escucha social | TikTok + YouTube | [ ] |
| Redactor de briefs | Notion + Claude | [ ] |

### Estudio de contenido · 8 agentes

| Agente | Herramientas | ¿Lo monto? |
|---|---|---|
| Copywriter | Claude | [ ] |
| Diseñador visual | Higgsfield + Canva | [ ] |
| Editor de cortos | Remotion + Higgsfield | [ ] |
| Voz en off | ElevenLabs + Claude | [ ] |
| Escritor de hooks | Claude + X | [ ] |
| Escritor de captions | Claude + Metricool | [ ] |
| Miniaturas | Higgsfield + Canva | [ ] |
| Verificador de datos | Claude + Google Drive | [ ] |

### Distribución · 5 agentes

| Agente | Herramientas | ¿Lo monto? |
|---|---|---|
| Programador | Metricool + Claude | [ ] |
| Optimizador de horario | Metricool + Google Analytics | [ ] |
| Reciclador | Claude + Remotion | [ ] |
| Rastreador de links | Bitly + Google Analytics | [ ] |
| Agente de newsletter | Claude | [ ] |

### Comunidad y DMs · 4 agentes

| Agente | Herramientas | ¿Lo monto? |
|---|---|---|
| Respuesta de DMs | ManyChat + Claude | [ ] |
| Respuesta a comentarios | Metricool + Claude | [ ] |
| Agente de escalamiento | ManyChat + Slack | [ ] |
| Respuesta a reseñas | Google Business + Claude | [ ] |

### Anuncios pagados · 4 agentes

| Agente | Herramientas | ¿Lo monto? |
|---|---|---|
| Operador de anuncios | Meta Ads + Claude | [ ] |
| Probador de creativos | Higgsfield + Meta Ads | [ ] |
| Retargeting | Meta Ads | [ ] |
| Guardián del gasto | Google Sheets + Slack | [ ] |

## Módulo 02 · Ventas (22 agentes)

### Captura de leads · 5 agentes

| Agente | Herramientas | ¿Lo monto? |
|---|---|---|
| Rastreador de llamadas | CallRail + Claude | [ ] |
| Atrapa DMs | ManyChat + HubSpot | [ ] |
| Atrapa formularios | Typeform + HubSpot | [ ] |
| Anti-duplicados | HubSpot + Claude | [ ] |
| Etiqueta de origen | HubSpot + Google Analytics | [ ] |

### Calificación y ruteo · 5 agentes

| Agente | Herramientas | ¿Lo monto? |
|---|---|---|
| Enriquecedor de leads | Apollo + Clearbit | [ ] |
| Calificador | HubSpot + Claude | [ ] |
| Ficha de contacto | HubSpot + Slack | [ ] |
| Ruteador | HubSpot + Claude | [ ] |
| Agente de nutrición | HubSpot + X | [ ] |

### Citas y confirmaciones · 5 agentes

| Agente | Herramientas | ¿Lo monto? |
|---|---|---|
| Agente de citas | Calendly + Google Calendar | [ ] |
| Confirmaciones | Twilio + Claude | [ ] |
| Recordatorios | Twilio + Gmail | [ ] |
| Rescate de ausencias | Calendly + Twilio | [ ] |
| Prepara la llamada | HubSpot + Claude | [ ] |

### Cotizaciones y depósitos · 5 agentes

| Agente | Herramientas | ¿Lo monto? |
|---|---|---|
| Cotizaciones | PandaDoc + Claude | [ ] |
| Cobra depósitos | Stripe + HubSpot | [ ] |
| Seguimiento | HubSpot + Gmail | [ ] |
| Contratos | PandaDoc + Google Drive | [ ] |
| Facturación | Stripe + QuickBooks | [ ] |

### Reseñas y referidos · 2 agentes

| Agente | Herramientas | ¿Lo monto? |
|---|---|---|
| Pide reseñas | Google Business + Twilio | [ ] |
| Agente de referidos | Stripe + HubSpot | [ ] |

## Módulo 03 · Orquestador (6 piezas)

| Pieza | Qué hace |
|---|---|
| Claude Code | Lee conocimiento/ antes de cada tarea y le asigna cada trabajo al agente que toca |
| Conexiones MCP | HubSpot, Stripe, Calendly, Slack, Drive: Claude entra a cada una sin copiar y pegar |
| Bandeja de aprobación | Todo lo que reglas.md marca como "necesita tu sí" te llega por Slack |
| Resumen de las 8:00 | posts, leads, llamadas, ventas y lo que te está esperando |
| Ciclo semanal | lee lo que de verdad cerró y se lo devuelve a investigación |
| Tablero | Looker Studio con ventas por ángulo y por canal |
