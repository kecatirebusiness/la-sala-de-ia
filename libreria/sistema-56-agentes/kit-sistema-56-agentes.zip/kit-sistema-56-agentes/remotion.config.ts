// Lo genera scripts/nuevo_proyecto.sh
import {Config} from '@remotion/cli/config';
Config.setConcurrency(7);
