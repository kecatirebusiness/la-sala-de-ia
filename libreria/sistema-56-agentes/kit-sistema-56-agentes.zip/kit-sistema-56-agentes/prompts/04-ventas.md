# Ventas: todo cae en una sola bandeja

Llamadas (CallRail), formularios (Typeform) y DMs (ManyChat) caen en HubSpot. HubSpot califica cada lead, te pasa la ficha de los que están listos y nutre al resto. Cuando dicen que sí, Calendly agenda la llamada en tu calendario y Twilio les escribe para confirmar. Después la cotización (PandaDoc) y el depósito (Stripe). Nadie persigue a nadie.

## Prompt para Claude Code: reglas de calificación de leads

```
Lee conocimiento/oferta.md y conocimiento/clientes.md. Escríbeme las reglas para calificar leads de 0 a 100 (qué suma y qué resta: presupuesto, urgencia, encaje con lo que vendo, si pidió llamada). Con 80 o más → me mandas su ficha por Slack y le mandas mi link de Calendly [TU LINK]. De 50 a 79 → secuencia de nutrición de 3 mensajes con mi voz. Menos de 50 → respuesta amable y cierre. Guárdalo en conocimiento/calificacion.md y dime qué propiedades tengo que crear en HubSpot.
```

## Prompt para Claude Code: de la cita al depósito

```
Cuando un lead agenda en Calendly: 1) mándale una confirmación por mensaje con mi voz y un recordatorio 24 h antes y 1 h antes; 2) si no se presenta, escríbele a los 15 minutos para reagendar; 3) antes de la llamada prepárame una ficha de 5 líneas con lo que sabemos de él (HubSpot) y qué paquete de conocimiento/oferta.md le encaja; 4) si dice que sí, crea el link de pago de Stripe del depósito de [MONTO] y déjalo en borradores/ para que yo lo apruebe antes de mandarlo.
```
