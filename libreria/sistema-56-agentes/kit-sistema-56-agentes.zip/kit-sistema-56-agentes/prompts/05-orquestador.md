# El orquestador: el ciclo semanal

Claude Code va arriba y lo conecta todo: antes de cada tarea lee tus archivos y le pasa el trabajo al agente que toca. Cada venta se anota con su origen (qué post, qué ángulo, qué canal). El lunes el orquestador lee qué cerró de verdad y se lo devuelve a investigación, así la semana siguiente hace más de lo que funcionó. Cero hojas de cálculo.

## Prompt para Claude Code: el ciclo semanal

```
Cada lunes a las 8:00: 1) lee las ventas cerradas y perdidas de la semana en [HUBSPOT / TU CRM]; 2) dime qué tipo de cliente y qué ángulo cerró más (con números); 3) actualiza conocimiento/tendencias.md con lo que funcionó; 4) planifica los 5 posts de la próxima semana dándole más espacio al ángulo ganador; 5) mándame por Slack un resumen de 5 líneas: posts listos, leads, llamadas, ventas y lo que está esperando mi sí. No hagas nada que conocimiento/reglas.md diga que necesita mi permiso.
```
