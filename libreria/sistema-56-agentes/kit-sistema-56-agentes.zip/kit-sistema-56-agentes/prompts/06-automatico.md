# Tu sí final y ponerlo en automático

El sistema trabaja solo, pero hay 8 cosas que siempre te llegan para que digas sí: un post listo, un dato delicado, un comentario molesto, un lead caliente que pide llamada, una cotización especial, un depósito que falla, alguien que escribe STOP y el gasto en anuncios que llega al tope. Todo lo demás corre a su hora: el resumen de las 8:00 y el ciclo de los lunes.

## Prompt para Claude Code: CLAUDE.md del orquestador + horarios

```
Crea un CLAUDE.md en la raíz de esta carpeta con las reglas del orquestador: antes de cualquier tarea leer conocimiento/, usar siempre mi voz, no inventar precios, todo lead va al CRM, y si conocimiento/reglas.md dice que algo necesita mi sí, dejarlo en borradores/ y avisarme por Slack. Después prográmame dos tareas: 1) todos los días a las 8:00, un resumen de 5 líneas (posts publicados, leads, llamadas agendadas, ventas, lo que me espera); 2) los lunes a las 8:30, el ciclo semanal. Dime cómo quedaron programadas y cómo las pauso.
```
