# Conecta tus herramientas por MCP

MCP es el enchufe que deja a Claude Code entrar a tus herramientas sin que copies y pegues nada: tu CRM, tu calendario, tus cobros, tu Drive y tu Slack. Conecta solo las que ya usas. Las 6 del centro de la rueda son las que mueven el ciclo.

## Prompt para Claude Code: conectar tus herramientas

```
Estas son las herramientas que uso en mi negocio: [EJ: HubSpot, Google Calendar, Calendly, Stripe, Google Drive, Slack, ManyChat]. Para cada una: 1) dime si tiene un servidor MCP oficial y el comando exacto de "claude mcp add" para conectarla; 2) si no tiene, dime la alternativa (Zapier, su API o un webhook); 3) conéctame las que tengan MCP una por una y prueba cada conexión leyendo algo sin modificar nada (ej: mis 5 últimos contactos, mis citas de mañana). Al final dame una tabla: herramienta, cómo quedó conectada y qué puede hacer Claude con ella.
```
