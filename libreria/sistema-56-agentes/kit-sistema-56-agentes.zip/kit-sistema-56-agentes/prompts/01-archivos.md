# Escribe tus archivos una sola vez

Todo el sistema lee los mismos archivos de texto: cómo hablas, qué vendes, a quién le vendes y qué necesita tu permiso. No es una base de datos, son archivos simples en una carpeta. Pídele a Claude que te los arme haciéndote preguntas.

## Prompt para Claude Code: crear tus archivos de conocimiento

```
Quiero montar un sistema de agentes para mi negocio. Antes de nada, hazme una entrevista corta (una pregunta a la vez, máximo 12 preguntas) y con mis respuestas crea esta carpeta:

conocimiento/
  voz.md       → cómo hablo: tono, frases que uso, palabras que nunca uso, ejemplos de mis mejores posts
  oferta.md    → qué vendo, precios, paquetes, garantías, tiempos de entrega
  clientes.md  → quién me compra, qué le importa, objeciones típicas, palabras que usa
  reglas.md    → qué puede hacer el sistema solo y qué necesita mi sí (ej: cotizaciones de más de $[MONTO], publicar, responder quejas)
  tendencias.md → temas de mi nicho que vale la pena vigilar

Mi negocio: [DESCRIBE TU NEGOCIO EN 2 LÍNEAS]. Escribe todo en español, corto y concreto.
```
