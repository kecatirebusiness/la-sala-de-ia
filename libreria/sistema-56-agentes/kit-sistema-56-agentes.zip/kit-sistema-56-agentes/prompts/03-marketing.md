# Marketing: de la tendencia al post publicado

Un tema se dispara en Google Trends, Semrush o SparkToro y el sistema lo cruza con clientes.md para sacar 3 ángulos. Claude escribe el post, Higgsfield crea el visual y Metricool lo publica en cada red a la hora en que pega. ManyChat responde comentarios y DMs con tu voz y le pasa los interesados a ventas. Nada sale sin tu sí.

## Prompt para Claude Code: agente de investigación + contenido

```
Lee conocimiento/clientes.md y conocimiento/tendencias.md. Busca qué temas de mi nicho están subiendo esta semana [PEGA AQUÍ LO QUE TE DIO GOOGLE TRENDS / SEMRUSH] y crúzalos con lo que le importa a mis clientes. Dame 3 ángulos para esta semana, y por cada ángulo: un hook de una línea, el guion de un reel de 30 segundos con mi voz (conocimiento/voz.md) y el prompt de imagen en inglés para el visual. No publiques nada: déjalo en borradores/ y avísame por Slack con un resumen para que yo diga sí o editar.
```

## Prompt de imagen para el visual del post (Higgsfield · Nano Banana Pro · 3:4)

```
Interior photo of [TU PRODUCTO O RESULTADO, ej. a small narrow modern kitchen with sage green cabinets and a white quartz worktop], soft daylight from a window, clean and minimal, realistic architectural photography, natural light, no text.
```

## Prompt para Claude Code: respuestas de DMs y comentarios (ManyChat)

```
Lee conocimiento/voz.md, conocimiento/oferta.md y conocimiento/reglas.md. Escríbeme las respuestas para ManyChat: 1) las 10 preguntas que más me hacen por DM con su respuesta en mi voz (máximo 3 líneas cada una); 2) 3 respuestas cortas para comentarios positivos; 3) qué hacer con un comentario molesto (no responder, avisarme por Slack); 4) cuándo pedirle al lead su nombre, email y qué necesita para pasarlo a HubSpot. Dámelo listo para copiar en cada bloque de ManyChat.
```
