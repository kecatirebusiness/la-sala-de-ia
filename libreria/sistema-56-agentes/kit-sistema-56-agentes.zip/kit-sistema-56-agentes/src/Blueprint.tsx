import React from 'react';
import {Img, staticFile} from 'remotion';
import {C, Ico, MONO, SANS} from './theme';

// El "plano" completo: 56 agentes. Coordenadas en el espacio 720x1280 de la referencia.
type Row = [string, string | null, string];
const MKT: {t: string; n: number; x: number; rows: Row[]}[] = [
  {t: 'Investigación\ny tendencias', n: 7, x: 65, rows: [['gtrends', 'gtrends', 'Detector de tendencias'], ['semrush', 'claude', 'Analista de keywords'], ['sparktoro', 'semrush', 'Investigador de audiencia'], ['gdrive', 'claude', 'Agente de compradores'], ['x', 'claude', 'Vigilante de competencia'], ['tiktok', 'youtube', 'Escucha social'], ['notion', 'claude', 'Redactor de briefs']]},
  {t: 'Estudio de\ncontenido', n: 8, x: 186, rows: [['claude', 'claude', 'Copywriter'], ['higgsfield', 'canva', 'Diseñador visual'], ['remotion', 'higgsfield', 'Editor de cortos'], ['elevenlabs', 'claude', 'Voz en off'], ['claude', 'x', 'Escritor de hooks'], ['claude', 'metricool', 'Escritor de captions'], ['higgsfield', 'canva', 'Miniaturas'], ['claude', 'gdrive', 'Verificador de datos']]},
  {t: 'Distribución', n: 5, x: 306, rows: [['metricool', 'claude', 'Programador'], ['metricool', 'ganalytics', 'Optimizador de horario'], ['claude', 'remotion', 'Reciclador'], ['bitly', 'ganalytics', 'Rastreador de links'], ['claude', 'claude', 'Agente de newsletter']]},
  {t: 'Comunidad\ny DMs', n: 4, x: 427, rows: [['manychat', 'claude', 'Respuesta de DMs'], ['metricool', 'claude', 'Respuesta a comentarios'], ['manychat', 'slack', 'Agente de escalamiento'], ['gbusiness', 'claude', 'Respuesta a reseñas']]},
  {t: 'Anuncios\npagados', n: 4, x: 547, rows: [['meta', 'claude', 'Operador de anuncios'], ['higgsfield', 'meta', 'Probador de creativos'], ['meta', 'meta', 'Retargeting'], ['gsheets', 'slack', 'Guardián del gasto']]},
];
const VEN: {t: string; n: number; x: number; rows: Row[]}[] = [
  {t: 'Captura\nde leads', n: 5, x: 65, rows: [['callrail', 'claude', 'Rastreador de llamadas'], ['manychat', 'hubspot', 'Atrapa DMs'], ['typeform', 'hubspot', 'Atrapa formularios'], ['hubspot', 'claude', 'Anti-duplicados'], ['hubspot', 'ganalytics', 'Etiqueta de origen']]},
  {t: 'Calificación\ny ruteo', n: 5, x: 186, rows: [['apollo', 'clearbit', 'Enriquecedor de leads'], ['hubspot', 'claude', 'Calificador'], ['hubspot', 'slack', 'Ficha de contacto'], ['hubspot', 'claude', 'Ruteador'], ['hubspot', 'x', 'Agente de nutrición']]},
  {t: 'Citas y\nconfirmaciones', n: 5, x: 306, rows: [['calendly', 'gcal', 'Agente de citas'], ['twilio', 'claude', 'Confirmaciones'], ['twilio', 'gmail', 'Recordatorios'], ['calendly', 'twilio', 'Rescate de ausencias'], ['hubspot', 'claude', 'Prepara la llamada']]},
  {t: 'Cotizaciones\ny depósitos', n: 5, x: 427, rows: [['pandadoc', 'claude', 'Cotizaciones'], ['stripe', 'hubspot', 'Cobra depósitos'], ['hubspot', 'gmail', 'Seguimiento'], ['pandadoc', 'gdrive', 'Contratos'], ['stripe', 'quickbooks', 'Facturación']]},
  {t: 'Reseñas y\nreferidos', n: 2, x: 547, rows: [['gbusiness', 'twilio', 'Pide reseñas'], ['stripe', 'hubspot', 'Agente de referidos']]},
];

const Col: React.FC<{t: string; n: number; x: number; y: number; rows: Row[]}> = ({t, n, x, y, rows}) => (
  <div style={{position: 'absolute', left: x, top: y, width: 108, borderRadius: 7, background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,.08), 0 0 0 1px #ECECEA', padding: '6px 6px 4px', boxSizing: 'border-box'}}>
    <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 4}}>
      <div style={{fontFamily: SANS, fontWeight: 700, fontSize: 7.4, lineHeight: '8px', color: C.ink, whiteSpace: 'pre'}}>{t}</div>
      <div style={{fontFamily: MONO, fontSize: 5, color: '#9a9a96', marginTop: 2}}>{n} agentes</div>
    </div>
    {rows.map(([a, b, l], i) => (
      <div key={i} style={{display: 'flex', alignItems: 'center', gap: 3, height: 19.3, borderTop: '1px solid #F0F0EE'}}>
        <Ico n={a} s={9}/>{b && <Ico n={b} s={9}/>}
        <div style={{fontFamily: SANS, fontSize: 5.6, color: '#333', whiteSpace: 'nowrap', overflow: 'hidden'}}>{l}</div>
      </div>
    ))}
  </div>
);

const Db: React.FC<{x: number; y: number; c1: string; c2: string; name: string; sub: string; logos: string[]; label: string}> = ({x, y, c1, c2, name, sub, logos, label}) => (
  <div style={{position: 'absolute', left: x, top: y, width: 88, height: 120, borderRadius: 7, background: '#fff', boxShadow: '0 1px 3px rgba(0,0,0,.08), 0 0 0 1px #ECECEA'}}>
    <div style={{position: 'absolute', left: 6, top: 5, fontFamily: MONO, fontSize: 4.6, color: '#555'}}>{label}</div>
    <svg width="60" height="56" viewBox="0 0 60 56" style={{position: 'absolute', left: 14, top: 14}}>
      <defs><linearGradient id={`g${name}`} x1="0" x2="1"><stop offset="0" stopColor={c1}/><stop offset="0.5" stopColor={c2}/><stop offset="1" stopColor={c1}/></linearGradient></defs>
      <path d="M2 8 v38 a28 8 0 0 0 56 0 v-38" fill={`url(#g${name})`}/>
      <ellipse cx="30" cy="8" rx="28" ry="8" fill="#EDEDED"/>
      <path d="M2 24 a28 8 0 0 0 56 0" fill="none" stroke="#fff" strokeOpacity=".6"/>
    </svg>
    <div style={{position: 'absolute', left: 0, right: 0, top: 74, textAlign: 'center', fontFamily: MONO, fontSize: 6.5, color: C.ink}}>{name}</div>
    <div style={{position: 'absolute', left: 0, right: 0, top: 83, textAlign: 'center', fontFamily: SANS, fontSize: 4.8, color: '#999'}}>{sub}</div>
    <div style={{position: 'absolute', left: 0, right: 0, top: 94, display: 'flex', justifyContent: 'center', gap: 3}}>{logos.map((l) => <Ico key={l} n={l} s={11}/>)}</div>
  </div>
);

const Arrow: React.FC<{x1: number; y1: number; x2: number; y2: number; n?: number; label?: string; lx?: number; ly?: number}> = ({x1, y1, x2, y2, n, label, lx, ly}) => (
  <>
    <svg style={{position: 'absolute', left: 0, top: 0, overflow: 'visible'}} width="1" height="1">
      <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={C.blue} strokeWidth="1.3"/>
      <polygon points={x2 === x1 ? `${x2 - 3},${y2 - 5} ${x2 + 3},${y2 - 5} ${x2},${y2}` : x2 > x1 ? `${x2 - 5},${y2 - 3} ${x2 - 5},${y2 + 3} ${x2},${y2}` : `${x2 + 5},${y2 - 3} ${x2 + 5},${y2 + 3} ${x2},${y2}`} fill={C.blue}/>
      <circle cx={(x1 + x2) / 2 - (x2 !== x1 ? 12 : 0)} cy={(y1 + y2) / 2 - (x2 === x1 ? 8 : 0)} r="2.2" fill="#fff" stroke={C.blue}/>
    </svg>
    {n !== undefined && <div style={{position: 'absolute', left: (lx ?? (x1 + x2) / 2) - 5, top: (ly ?? y1) - 16, width: 10, height: 10, borderRadius: 5, border: `1px solid ${C.blue}`, color: C.blue, fontSize: 5.5, fontFamily: SANS, display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#fff'}}>{n}</div>}
    {label && <div style={{position: 'absolute', left: (lx ?? (x1 + x2) / 2) - 40, top: (ly ?? y1) + 5, width: 80, textAlign: 'center', fontFamily: SANS, fontSize: 4.8, color: '#333'}}>{label}</div>}
  </>
);

const Tabs: React.FC<{x: number; y: number; items: string[]}> = ({x, y, items}) => (
  <div style={{position: 'absolute', left: x, top: y, width: 36, padding: 3, background: '#1c1c1e', borderRadius: 3, display: 'flex', flexDirection: 'column', gap: 2}}>
    {items.map((t) => <div key={t} style={{height: 8, borderRadius: 2, background: '#2c2c2f', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 2px', fontFamily: MONO, fontSize: 3.6, color: '#ddd'}}>{t}<span style={{width: 4, height: 4, borderRadius: 1, background: C.blue}}/></div>)}
  </div>
);

const Small: React.FC<{x: number; y: number; w: number; h: number; title: string; children?: React.ReactNode; dashed?: boolean}> = ({x, y, w, h, title, children, dashed}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: 7, background: '#fff', border: dashed ? '1px dashed #C9C9C6' : undefined, boxShadow: dashed ? undefined : '0 1px 3px rgba(0,0,0,.08), 0 0 0 1px #ECECEA', padding: 5, boxSizing: 'border-box'}}>
    <div style={{fontFamily: MONO, fontSize: 4.8, letterSpacing: 0.3, color: '#333', marginBottom: 4}}>{title}</div>
    {children}
  </div>
);

export const Blueprint: React.FC = () => (
  <div style={{position: 'absolute', left: 0, top: 0, width: 720, height: 1280}}>
    {/* conectores punteados al orquestador */}
    <svg style={{position: 'absolute', left: 0, top: 0}} width="720" height="1280">
      <g stroke="#9aa6c8" strokeWidth="1.1" strokeDasharray="5 4" fill="none">
        {[120, 240, 360, 480, 600].map((x) => <line key={x} x1={x} y1={640} x2={360} y2={745}/>)}
        {[120, 240, 360, 480, 600].map((x) => <line key={'b' + x} x1={360} y1={745} x2={x} y2={815}/>)}
        <ellipse cx="360" cy="728" rx="72" ry="44" stroke="#4E74D6" strokeWidth="1.4"/>
      </g>
      <rect x="58" y="428" width="604" height="212" rx="10" fill="#F6F6F4" stroke="#C9C9C6" strokeDasharray="5 4"/>
      <rect x="58" y="815" width="604" height="152" rx="10" fill="#F6F6F4" stroke="#C9C9C6" strokeDasharray="5 4"/>
    </svg>
    {/* fila superior */}
    <Small x={22} y={270} w={116} h={102} title="Señales · 12 herramientas" dashed>
      <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 20px)', gap: 6, marginLeft: 6}}>
        {['gtrends', 'ganalytics', 'semrush', 'sparktoro', 'manychat', 'metricool', 'callrail', 'typeform', 'hubspot', 'calendly', 'stripe', 'looker'].map((l) => <Ico key={l} n={l} s={18}/>)}
      </div>
    </Small>
    <Arrow x1={138} y1={322} x2={232} y2={322} n={1} label="señales crudas"/>
    <Db x={233} y={270} c1="#3fae6a" c2="#8fe0ad" name="ventas.db" sub="1,240 compradores" logos={['hubspot', 'stripe', 'calendly']} label="LEADS Y VENTAS"/>
    <Arrow x1={321} y1={322} x2={414} y2={322} n={2} label="leads y ventas"/>
    <Small x={415} y={270} w={118} h={150} title="Lo que lee cada agente" dashed>
      <div style={{fontFamily: MONO, fontSize: 4.3, color: '#555'}}>SISTEMA DE REGISTRO</div>
      <div style={{display: 'flex', gap: 3, margin: '3px 0 6px'}}>{['hubspot', 'stripe', 'gdrive', 'notion', 'calendly', 'gcal'].map((l) => <Ico key={l} n={l} s={11}/>)}</div>
      <div style={{fontFamily: MONO, fontSize: 4.3, color: '#555'}}>LO QUE PONES TÚ</div>
      <div style={{display: 'flex', gap: 3, margin: '3px 0 6px'}}>{['gdrive', 'user', 'notion', 'user', 'gsheets', 'slack', 'telegram'].map((l, i) => <Ico key={i} n={l} s={11}/>)}</div>
      <div style={{background: '#1c1c1e', borderRadius: 4, padding: 4, fontFamily: MONO, fontSize: 4.6, color: '#fff', lineHeight: '6.4px'}}>CONOCIMIENTO · 24 ARCHIVOS<br/><span style={{color: '#cfcfcf'}}>/voz /oferta /reglas<br/>/clientes /tendencias<br/>/pipeline /resultados</span></div>
    </Small>
    <Arrow x1={627} y1={322} x2={534} y2={322} label="indexado cada noche"/>
    <Db x={628} y={270} c1="#7b5bd6" c2="#b9a2f2" name="conocimiento.db" sub="24 archivos · 6 carpetas" logos={['gdrive', 'notion', 'claude']} label="ÍNDICE"/>
    <Arrow x1={277} y1={391} x2={277} y2={427}/>
    <Arrow x1={474} y1={421} x2={474} y2={427} n={3} lx={488} ly={428} label="reglas + contexto"/>
    {/* marketing */}
    <div style={{position: 'absolute', left: 66, top: 434, fontFamily: SANS, fontWeight: 700, fontSize: 7.6, color: C.ink}}>Marketing · 28 agentes</div>
    {MKT.map((c) => <Col key={c.t} {...c} y={446}/>)}
    <Tabs x={0} y={452} items={['tendencias', 'buscar', 'clientes']}/>
    <Tabs x={684} y={452} items={['contenido', 'estilo', 'canales']}/>
    {/* orquestador */}
    <div style={{position: 'absolute', left: 300, top: 656, width: 120, textAlign: 'center', fontFamily: SANS, fontWeight: 600, fontSize: 6, color: C.ink}}>Asigna cada tarea</div>
    <Img src={staticFile('logos/clawd.svg')} style={{position: 'absolute', left: 347, top: 667, width: 26}}/>
    <div style={{position: 'absolute', left: 334, top: 700, width: 52, height: 52, borderRadius: 26, background: '#FFF4EE', border: '2px solid #E9A27D', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Ico n="claude" s={36} bare/></div>
    <div style={{position: 'absolute', left: 278, top: 718}}><Ico n="slack" s={28} bare/></div>
    <div style={{position: 'absolute', left: 411, top: 712}}><Ico n="hubspot" s={30}/></div>
    <div style={{position: 'absolute', left: 262, top: 750, width: 60, textAlign: 'center', fontFamily: SANS, fontWeight: 600, fontSize: 5.4}}>Solo pregunta ahí</div>
    <div style={{position: 'absolute', left: 396, top: 750, width: 70, textAlign: 'center', fontFamily: SANS, fontWeight: 600, fontSize: 5.4}}>Lo que de verdad cerró</div>
    <div style={{position: 'absolute', left: 260, top: 768, width: 200, textAlign: 'center', fontFamily: SANS, fontWeight: 800, fontSize: 15, color: C.ink}}>Orquestador</div>
    <div style={{position: 'absolute', left: 260, top: 787, width: 200, textAlign: 'center', fontFamily: SANS, fontSize: 5.2, color: '#666', lineHeight: '6.5px'}}>Ventas y marketing no es un embudo.<br/>Es un ciclo.</div>
    {/* ventas */}
    <div style={{position: 'absolute', left: 66, top: 821, fontFamily: SANS, fontWeight: 700, fontSize: 7.6, color: C.ink}}>Ventas · 22 agentes</div>
    {VEN.map((c) => <Col key={c.t} {...c} y={833}/>)}
    <Tabs x={0} y={857} items={['leads', 'llamadas', 'citas']}/>
    <Tabs x={684} y={857} items={['ventas', 'depósitos', 'reseñas']}/>
    {/* abajo */}
    <Arrow x1={369} y1={968} x2={369} y2={1018} n={4} lx={382} ly={992} label="cada acción registrada"/>
    <Arrow x1={637} y1={968} x2={637} y2={1018} n={5} lx={650} ly={992} label="te necesita"/>
    <div style={{position: 'absolute', left: 22, top: 1020, width: 156, height: 148, borderRadius: 8, background: '#1c1c1e', padding: 8, boxSizing: 'border-box', fontFamily: MONO, fontSize: 6.6, color: '#eee', lineHeight: '9.2px'}}>
      <div style={{display: 'flex', gap: 3, marginBottom: 5}}>{['#ff5f57', '#febc2e', '#28c840'].map((c) => <span key={c} style={{width: 5, height: 5, borderRadius: 3, background: c}}/>)}</div>
      $ pipeline status --mañana<br/>posts publicados&nbsp;&nbsp;&nbsp;12<br/>leads captados&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;37<br/>llamadas agendadas&nbsp;9<br/>ventas cerradas&nbsp;&nbsp;&nbsp;&nbsp;4<br/><span style={{color: '#ff8fb1'}}>esperándote&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3</span><br/>resumen.md 8:00
    </div>
    <Arrow x1={289} y1={1052} x2={180} y2={1052} label="reporte 8:00"/>
    <Small x={290} y={1020} w={156} h={62} title="DATOS · LO QUE VES CADA MAÑANA">
      <div style={{display: 'grid', gridTemplateColumns: 'repeat(6, 16px)', gap: 5, marginLeft: 12}}>{['metricool', 'ganalytics', 'hubspot', 'callrail', 'looker', 'stripe', 'meta', 'gsheets', 'x', 'quickbooks'].map((l) => <Ico key={l} n={l} s={15}/>)}</div>
    </Small>
    <Small x={290} y={1092} w={156} h={60} title="TRASPASO HUMANO">
      <div style={{display: 'flex', justifyContent: 'space-around', fontFamily: SANS, fontSize: 4.8, color: C.mk}}><span>Tú</span><span style={{color: C.blue}}>Compradores</span><span style={{color: C.sl}}>Cada mañana</span></div>
      <div style={{display: 'flex', justifyContent: 'space-around', marginTop: 5}}>{[['slack', 'telegram'], ['calendly', 'zoom'], ['slack', 'looker']].map((p, i) => <div key={i} style={{display: 'flex', gap: 2}}>{p.map((l) => <Ico key={l} n={l} s={13}/>)}</div>)}</div>
    </Small>
    <Arrow x1={559} y1={1120} x2={447} y2={1120} label="traspaso"/>
    <Small x={560} y={1020} w={156} h={140} title="LO QUE INTERRUMPE EL CICLO">
      <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', rowGap: 7, columnGap: 4}}>
        {[['Post listo', 'slack'], ['Dato riesgoso en un post', 'claude'], ['Comentario o DM molesto', 'manychat'], ['Lead caliente pide llamada', 'hubspot'], ['Cotización especial', 'pandadoc'], ['Falla un depósito', 'stripe'], ['Alguien escribe STOP', 'twilio'], ['El gasto llega al tope', 'gsheets']].map(([t, l]) => (
          <div key={t}><div style={{fontFamily: SANS, fontSize: 4.4, color: '#333', height: 10}}>{t}</div><div style={{display: 'flex', gap: 2}}><Ico n={l} s={10}/><Ico n="user" s={10}/></div></div>
        ))}
      </div>
    </Small>
  </div>
);
