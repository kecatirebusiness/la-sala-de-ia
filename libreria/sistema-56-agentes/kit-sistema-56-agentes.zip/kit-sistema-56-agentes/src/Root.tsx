import React from 'react';
import {Composition} from 'remotion';
import {Edit} from './Edit';
import {TOTAL} from './theme';
export const Root: React.FC = () => <Composition id="Edit" component={Edit} durationInFrames={TOTAL} fps={30} width={1080} height={1920}/>;
