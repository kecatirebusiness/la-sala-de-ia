import React from 'react';
import {AbsoluteFill, Audio, Img, staticFile, useCurrentFrame, interpolate, Easing} from 'remotion';
import {C, F, FPS, MONO, SANS, fontCss, WORDS, tw, on, MK, SL, OC, Tema, Tile} from './theme';
import {Blueprint} from './Blueprint';
import {Wheel} from './Wheel';
import {Headers, H} from './Mod';
import {Marketing} from './Marketing';
import {Sales} from './Sales';
import {Orq} from './Orq';

const PINK: Tema = {c: C.pink, bg: '#FFF1F6', soft: '#FDDDE8', mid: '#F59BBE'};
const EZ = Easing.bezier(0.65, 0, 0.35, 1);

// cámara: [tRef, fx, fy, escala]
type K = [number, number, number, number];
const cam = (f: number, ks: K[]) => {
  let fx = ks[0][1], fy = ks[0][2], s = ks[0][3];
  for (let i = 1; i < ks.length; i++) {
    const [t, x, y, z] = ks[i];
    const a = F(t) - 10, b = F(t) + 2;
    const p = interpolate(f, [a, b], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EZ});
    // interpolación en espacio de "zoom" para que no se vea raro
    fx = fx + (x - fx) * p; fy = fy + (y - fy) * p; s = s * Math.pow(z / s, p);
  }
  return `translate(${360 - fx * s}px, ${640 - fy * s}px) scale(${s})`;
};

const PAN: K[] = [
  [0, 360, 640, 1], [9.75, 150, 525, 2.5], [10.55, 262, 525, 2.5], [11.6, 382, 520, 2.6], [12.6, 180, 890, 2.5], [13.5, 362, 890, 2.6], [14.55, 492, 890, 2.6], [15.65, 262, 1070, 2.35], [16.75, 360, 640, 1],
];

const Hero: React.FC<{f: number; hi?: 'mk' | 'sl'; hiT?: number}> = ({f, hi, hiT}) => {
  const box = hi === 'mk' ? [58, 428, 604, 212] : hi === 'sl' ? [58, 815, 604, 152] : null;
  const dim = box && hiT !== undefined ? tw(f, hiT, hiT + 0.3) : 0;
  return <AbsoluteFill style={{background: '#fff'}}>
    <div style={{position: 'absolute', left: 0, top: 0, width: 720, height: 1280, transformOrigin: '0 0', transform: cam(f, PAN)}}>
      <div style={{position: 'absolute', right: 16, top: 16, display: 'flex', alignItems: 'center', gap: 6}}>
        <Img src={staticFile('img/lasala.png')} style={{width: 20, height: 20}}/>
        <span style={{fontFamily: SANS, fontWeight: 700, fontSize: 11, color: C.ink, letterSpacing: -0.2}}>La Sala de IA</span>
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 150, textAlign: 'center', fontFamily: SANS, fontWeight: 800, fontSize: 33, lineHeight: '40px', color: C.ink, letterSpacing: -0.5}}>56 AGENTES DE IA MANEJAN<br/>UNA EMPRESA DE UNA PERSONA</div>
      <Blueprint/>
      {box && dim > 0 && <div style={{position: 'absolute', left: box[0] - 4, top: box[1] - 4, width: box[2] + 8, height: box[3] + 8, borderRadius: 12, boxShadow: `0 0 0 3000px rgba(60,60,60,${0.42 * dim})`, transform: `scale(${1 + 0.03 * dim})`}}/>}
    </div>
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 260, background: 'linear-gradient(rgba(255,255,255,0), rgba(255,255,255,.85))', opacity: interpolate(f, [F(9.4), F(9.8), F(16.6), F(16.9)], [1, 0, 0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) * (dim ? 0 : 1)}}/>
  </AbsoluteFill>;
};

const WheelScene: React.FC<{f: number; t0: number; hdr: H[]; tema?: Tema; ks?: K[]; extra?: Partial<React.ComponentProps<typeof Wheel>>}> = ({f, t0, hdr, tema = MK, ks, extra}) => (
  <AbsoluteFill style={{background: '#fff'}}>
    <div style={{position: 'absolute', left: 0, top: 0, width: 720, height: 1280, transformOrigin: '0 0', transform: ks ? cam(f, ks) : undefined}}>
      <Headers f={f} hdr={hdr} tema={tema}/>
      <Wheel f={f} t0={t0} {...extra}/>
    </div>
  </AbsoluteFill>
);

// subtítulos (solo en los planos del "plano general")
const CAP_ON: [number, number][] = [[0, 4.5], [7.7, 18.9], [22.0, 23.3], [55.4, 57.9], [112.5, 200]];
const UP = new Set(['marketing.', 'ventas.', 'SISTEMA']);
const chunks = (() => {
  const out: {txt: string; a: number; b: number}[] = [];
  let cur: typeof WORDS = [];
  WORDS.forEach((w, i) => {
    cur.push(w);
    const end = /[.,?!]$/.test(w.w) || cur.length >= 3;
    if (end || i === WORDS.length - 1) { out.push({txt: cur.map((x) => (UP.has(x.w) ? x.w.toUpperCase() : x.w)).join(' '), a: cur[0].a, b: cur[cur.length - 1].b}); cur = []; }
  });
  return out.map((c, i) => ({...c, b: Math.min(out[i + 1] ? out[i + 1].a : c.b + 0.6, c.b + 0.6)}));
})();
const Captions: React.FC<{f: number; ok: boolean}> = ({f, ok}) => {
  if (!ok) return null;
  const t = f / FPS;
  const c = chunks.find((x) => t >= x.a - 0.03 && t < x.b);
  if (!c) return null;
  const k = Math.min(1, (t - c.a + 0.03) / 0.08);
  return <div style={{position: 'absolute', left: 30, right: 30, top: 880, textAlign: 'center', fontFamily: SANS, fontWeight: 900, fontSize: 33, lineHeight: '40px', color: '#fff', WebkitTextStroke: '7px #111', paintOrder: 'stroke fill', letterSpacing: -0.6, transform: `scale(${0.9 + 0.1 * k})`, textShadow: '0 3px 0 #111'}}>{c.txt}</div>;
};

export const Edit: React.FC = () => {
  const f = useCurrentFrame();
  const t = (a: number, b: number) => f >= F(a) && f < F(b);
  const capOk = CAP_ON.some(([a, b]) => t(a, b));
  let scene: React.ReactNode = null;
  if (t(0, 4.5) || t(7.7, 18.9)) scene = <Hero f={f}/>;
  else if (t(4.5, 7.7)) scene = <WheelScene f={f} t0={4.5} hdr={[
    {t: 4.5, l1: 'PERSONAS', v1: '1', l2: 'MANEJA'}, {t: 5.2, l1: 'PERSONAS', v1: '1', l2: 'MANEJA', v2: 'LA EMPRESA'},
    {t: 6.04, l1: 'AGENTES', v1: '56', l2: 'REEMPLAZAN'}, {t: 6.9, l1: 'AGENTES', v1: '56', l2: 'REEMPLAZAN', v2: 'UN EQUIPO'}]}/>;
  else if (t(18.9, 22.0)) scene = <WheelScene f={f} t0={18.4} tema={PINK} hdr={[
    {t: 18.9, l1: 'SI FUERA UN', v1: 'EMBUDO', l2: 'CLIENTES PERDIDOS', v2: '30', c1: PINK}, {t: 19.25, l1: 'ES UN', v1: 'CICLO', l2: 'CLIENTES PERDIDOS', v2: '0', c1: SL}]}
    extra={{pipe: on(f, 19.25) ? 0 : 1, loop: tw(f, 19.25, 20.2)}}/>;
  else if (t(22.0, 23.3)) scene = <Hero f={f} hi="mk" hiT={22.0}/>;
  else if (t(23.3, 55.4)) scene = <Marketing f={f}/>;
  else if (t(55.4, 57.9)) scene = <Hero f={f} hi={on(f, 56.2) ? 'sl' : undefined} hiT={56.2}/>;
  else if (t(57.9, 59.9)) scene = <WheelScene f={f} t0={57.0} tema={SL} hdr={[{t: 57.9, l1: 'MÓDULO', v1: '02', l2: 'AGENTES', v2: '22', c1: SL}]}
    ks={[[0, 360, 640, 1], [59.1, 520, 640, 1.65]]} extra={{newLead: 58.2}}/>;
  else if (t(59.9, 82.0)) scene = <Sales f={f}/>;
  else if (t(82.0, 84.5)) scene = <WheelScene f={f} t0={81.0} tema={OC} hdr={[{t: 82.0, l1: 'MÓDULO', v1: '03', l2: 'AGENTES', v2: '6', c1: OC}]}
    ks={[[0, 360, 640, 1], [84.2, 360, 617, 3.2]]} extra={{hubLabel: on(f, 82.4) ? 'VENTA CERRADA' : undefined}}/>;
  else if (t(84.5, 108.5)) scene = <Orq f={f}/>;
  else if (t(108.5, 112.5)) scene = <WheelScene f={f} t0={107.5} tema={OC} hdr={[
    {t: 108.5, l1: 'LA IA MUEVE', l2: 'AGENTES', v2: '56', c1: OC}, {t: 109.1, l1: 'LA IA MUEVE', v1: 'INFORMACIÓN', l2: 'AGENTES', v2: '56', c1: OC},
    {t: 110.36, l1: 'TÚ MUEVES', v1: 'LA MARCA', l2: 'HUMANOS', v2: '1', c1: SL}, {t: 111.4, l1: 'TÚ MUEVES', v1: 'MARCA · PRESUP.', l2: 'HUMANOS', v2: '1', c1: SL}]}
    extra={{flow: tw(f, 108.6, 109.0) * (1 - tw(f, 110.2, 110.5)), youRight: on(f, 110.36) ? <Sliders f={f}/> : undefined}}/>;
  else scene = <Hero f={f}/>;
  return (
    <AbsoluteFill style={{background: '#fff'}}>
      <style>{fontCss}</style>
      <div style={{position: 'absolute', left: 0, top: 0, width: 720, height: 1280, transform: 'scale(1.5)', transformOrigin: '0 0', overflow: 'hidden'}}>
        {scene}
        <Captions f={f} ok={capOk}/>
      </div>
      <Audio src={staticFile('voz.wav')}/>
    </AbsoluteFill>
  );
};

const Sliders: React.FC<{f: number}> = ({f}) => (
  <div style={{display: 'flex', gap: 10, marginRight: 2}}>
    {[['MARCA', 110.5], ['PRESUPUESTO', 111.5]].map(([l, t]) => {
      const p = tw(f, t as number, (t as number) + 0.5);
      return <div key={l as string} style={{width: 34}}>
        <svg width="34" height="16"><line x1="2" y1="8" x2="32" y2="8" stroke={C.ink} strokeWidth="2"/><circle cx={6 + p * 22} cy="8" r="5" fill="#fff" stroke={C.ink} strokeWidth="2"/></svg>
        <div style={{fontFamily: MONO, fontSize: 4.4, textAlign: 'center', color: '#555'}}>{l as string}</div>
      </div>;
    })}
  </div>
);
