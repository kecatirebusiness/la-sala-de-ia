import React from 'react';
import {Img, staticFile, interpolate} from 'remotion';
import {C, F, MONO, SANS, Ico, Tile, Foto, tw, on, typed, FPS, SL} from './theme';
import {Mod, Slide, H} from './Mod';

const money = (n: number) => '$' + Math.round(n).toLocaleString('en-US');
const Box: React.FC<{x: number; y: number; w: number; h: number; c?: string; bg?: string; r?: number; bw?: number; style?: React.CSSProperties; children?: React.ReactNode}> = ({x, y, w, h, c = C.ink, bg = '#fff', r = 10, bw = 2.5, style, children}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: r, border: `${bw}px solid ${c}`, background: bg, boxSizing: 'border-box', ...style}}>{children}</div>
);
const Mono: React.FC<{x: number; y: number; s?: number; c?: string; w?: number; center?: boolean; children: React.ReactNode; style?: React.CSSProperties}> = ({x, y, s = 8, c = C.ink, w, center, children, style}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, textAlign: center ? 'center' : undefined, fontFamily: MONO, fontSize: s, letterSpacing: 0.6, color: c, whiteSpace: 'pre', ...style}}>{children}</div>
);

export const SL_HDR = (f: number): H[] => [
  {t: 59.9, l1: 'PIPELINE', v1: '$0', l2: 'BANDEJAS', v2: '3'},
  {t: 60.9, l1: 'PIPELINE', v1: '$18,400', l2: 'BANDEJAS', v2: '3'},
  {t: 61.9, l1: 'PIPELINE', v1: '$30,600', l2: 'BANDEJAS', v2: '3'},
  {t: 62.9, l1: 'PIPELINE', v1: '$48,600', l2: 'BANDEJAS', v2: '3'},
  {t: 64.4, l1: 'PIPELINE', v1: '$48,600', l2: 'BANDEJAS', v2: '3 → 1'},
  {t: 65.7, l1: 'LISTOS PARA COMPRAR', v1: '0', l2: 'CALIFICADOS', v2: '0 / 5'},
  {t: 66.6, l1: 'LISTOS PARA COMPRAR', v1: '0', l2: 'CALIFICADOS', v2: '3 / 5'},
  {t: 67.4, l1: 'LISTOS PARA COMPRAR', v1: '1', l2: 'CALIFICADOS', v2: '5 / 5'},
  {t: 67.9, l1: 'LISTOS PARA COMPRAR', v1: '1', l2: 'SU CONTACTO', v2: 'PARA TI'},
  {t: 68.9, l1: 'LISTOS PARA COMPRAR', v1: '2', l2: 'SU CONTACTO', v2: 'PARA TI'},
  {t: 71.0, l1: 'SÍ → AGENDADA', l2: 'CONFIRMADA'},
  {t: 73.3, l1: 'SÍ → AGENDADA', v1: '0.8s', l2: 'CONFIRMADA'},
  {t: 76.2, l1: 'SÍ → AGENDADA', v1: '0.8s', l2: 'CONFIRMADA', v2: 'POR MENSAJE'},
  {t: 77.3, l1: 'DEPÓSITO', l2: 'PERSEGUIDO POR TI'},
  {t: 78.4, l1: 'DEPÓSITO', v1: '$2,400', l2: 'PERSEGUIDO POR TI'},
  {t: 80.4, l1: 'DEPÓSITO', v1: '$2,400', l2: 'PERSEGUIDO POR TI', v2: '0'},
];

// 1) todo cae en una bandeja
const Inbox: React.FC<{f: number}> = ({f}) => {
  const src = [['phone', 'LÍNEA RASTREADA', 50, 'callrail', 60.2, 'img/lead2.jpg', 12200], ['web', 'SITIO WEB', 194, 'callrail', 61.2, 'img/maria.jpg', 18400], ['chat', 'IG · FB · TIKTOK', 338, 'manychat', 62.2, 'img/lead3.jpg', 18000]] as const;
  const icons: Record<string, React.ReactNode> = {
    phone: <svg width="22" height="22" viewBox="0 0 24 24"><path d="M6 3h3l2 5-2 1.5a11 11 0 0 0 5.5 5.5L16 13l5 2v3a2 2 0 0 1-2 2A17 17 0 0 1 4 5a2 2 0 0 1 2-2z" fill={C.ink}/></svg>,
    web: <svg width="22" height="26" viewBox="0 0 22 26"><rect x="2" y="2" width="18" height="22" rx="2" fill="none" stroke={C.ink} strokeWidth="2"/>{[8, 12, 16].map((y) => <line key={y} x1="6" y1={y} x2="16" y2={y} stroke={C.ink} strokeWidth="2"/>)}</svg>,
    chat: <svg width="26" height="24" viewBox="0 0 26 24"><path d="M3 3h20v14H10l-5 4v-4H3z" fill="none" stroke={C.ink} strokeWidth="2"/></svg>,
  };
  const n = src.filter((s) => on(f, s[4] + 0.9)).length;
  const one = on(f, 64.4);
  return <>
    <svg style={{position: 'absolute', left: 0, top: 0}} width="551" height="501">
      {src.map(([k, , y], i) => {
        const yy = y + 35, ty = 140 + i * 85;
        const d = `M110 ${yy} H 285 C 310 ${yy}, 318 ${ty}, 344 ${ty}`;
        return <g key={k}><path d={d} fill="none" stroke={C.ink} strokeWidth="17" strokeLinecap="round"/><path d={d} fill="none" stroke="#A8E6BE" strokeWidth="12" strokeLinecap="round"/>
          <path d={d} fill="none" stroke="#fff" strokeWidth="2" strokeDasharray="2 9" strokeDashoffset={-f * 1.5} opacity=".8"/></g>;
      })}
    </svg>
    {src.map(([k, label, y, tool, t, img], i) => {
      const p = tw(f, t, t + 0.9, 0, 1, 'lin');
      const yy = y + 35, ty = 140 + i * 85;
      const x = p < 0.75 ? 110 + (p / 0.75) * 175 : 285 + ((p - 0.75) / 0.25) * 59;
      const yb = p < 0.75 ? yy : yy + ((p - 0.75) / 0.25) * (ty - yy);
      const lit = on(f, t);
      return <React.Fragment key={k}>
        <Box x={24} y={y} w={112} h={70} r={10} c={lit && !on(f, t + 1) ? C.sl : C.ink} bg={lit && !on(f, t + 1) ? C.slSoft : '#fff'}>
          <div style={{position: 'absolute', left: 20, top: 14}}>{icons[k]}</div>
          <Mono x={0} y={50} s={5.6} w={108} center c="#666">{label}</Mono>
        </Box>
        <div style={{position: 'absolute', left: 212, top: yy - 18, width: 36, height: 36, borderRadius: 8, border: '2px solid #888', background: 'rgba(255,255,255,.75)', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Ico n={tool} s={24}/></div>
        {p > 0 && p < 1 && <div style={{position: 'absolute', left: x - 9, top: yb - 9}}><Foto src={img} s={18} ring={C.ink}/></div>}
      </React.Fragment>;
    })}
    <div style={{position: 'absolute', left: 331, top: 76, width: 163, height: 19, borderRadius: 10, border: `2.5px solid ${C.ink}`, background: one ? C.sl : '#fff', boxSizing: 'border-box'}}/>
    <Box x={344} y={110} w={138} h={239} r={14} c={one ? C.sl : C.ink}>
      <Mono x={0} y={22} s={7.5} w={134} center style={{fontWeight: 700}}>UNA BANDEJA</Mono>
      <div style={{position: 'absolute', left: 52, top: 44}}><Tile n="hubspot" s={30}/></div>
      {src.map(([k, , , , t, img, v], i) => on(f, t + 0.9) && <div key={k} style={{position: 'absolute', left: 12, top: 92 + i * 38, width: 110, height: 30, borderRadius: 8, border: `2px solid ${C.sl}`, background: C.slSoft, boxSizing: 'border-box', display: 'flex', alignItems: 'center', gap: 8, padding: '0 6px', transform: `scale(${tw(f, t + 0.9, t + 1.1, 0.6, 1)})`}}><Foto src={img} s={20}/><span style={{fontFamily: SANS, fontWeight: 700, fontSize: 9}}>{money(v)}</span></div>)}
    </Box>
    <Mono x={344} y={362} s={6.5} w={138} center c={one ? C.sl : '#666'}>{one ? 'TODO · EN UN SOLO LUGAR' : `${n} / 3 DENTRO`}</Mono>
  </>;
};

// 2) calificador: rampa y tubos
const Scorer: React.FC<{f: number}> = ({f}) => {
  const leads = [['img/maria.jpg', 92, 2, 66.0], ['img/lead1.jpg', 34, 0, 66.4], ['img/lead2.jpg', 61, 1, 66.8], ['img/lead3.jpg', 88, 2, 67.2], ['img/lead4.jpg', 47, 1, 67.6]] as const;
  const tubes = [['NO ENCAJA', '#fff', C.ink], ['NUTRIR', '#FFF8E8', C.ink], ['LISTO ≥ 80', C.slSoft, C.sl]] as const;
  const tx = [207, 315, 423];
  const col = (s: number) => (s >= 80 ? C.sl : s >= 50 ? C.yellow : '#777');
  const cnt = [0, 0, 0]; leads.forEach(([, , k, t]) => { if (on(f, t + 0.9)) cnt[k]++; });
  return <>
    <Box x={11} y={29} w={144} h={78} r={10} c={C.sl} bg={C.slSoft}>
      <div style={{position: 'absolute', left: 10, top: 18}}><Tile n="hubspot" s={36}/></div>
      <Mono x={56} y={24} s={8} style={{fontWeight: 700}}>CALIFICADOR</Mono>
      <Mono x={56} y={40} s={5.6} c="#555">LEE CADA CHAT</Mono>
    </Box>
    <svg style={{position: 'absolute', left: 0, top: 0}} width="551" height="501">
      <line x1="125" y1="84" x2="540" y2="211" stroke={C.ink} strokeWidth="7" strokeLinecap="round"/><line x1="125" y1="84" x2="540" y2="211" stroke="#fff" strokeWidth="3" strokeLinecap="round"/>
      {[249, 356].map((x) => <circle key={x} cx={x} cy={84 + (x - 125) * (127 / 415)} r="7" fill={C.ink}/>)}
      <circle cx="460" cy={84 + 335 * (127 / 415)} r="7" fill={C.ink}/>
      {tubes.map(([, bg, c], i) => <path key={i} d={`M${tx[i]} 149 V352 a8 8 0 0 0 8 8 H${tx[i] + 75} a8 8 0 0 0 8 -8 V${149 + (i === 2 ? 20 : 0)}`} fill={bg} stroke={c} strokeWidth="2.5"/>)}
    </svg>
    {tubes.map(([l, , c], i) => <React.Fragment key={l}><Mono x={tx[i] - 10} y={372} s={6.5} w={103} center c={c} style={{fontWeight: 700}}>{l}</Mono><Mono x={tx[i] - 10} y={386} s={9} w={103} center c={c}>{String(cnt[i])}</Mono></React.Fragment>)}
    {leads.map(([img, s, k, t], i) => {
      const p = tw(f, t, t + 0.55, 0, 1, 'lin');
      if (!on(f, t)) return null;
      const dropX = tx[k] + 41;
      const rx = 140 + p * (dropX - 140), ry = 84 + (rx - 125) * (127 / 415) - 16;
      const q = tw(f, t + 0.55, t + 0.9, 0, 1, 'lin');
      const stackY = 330 - leads.slice(0, i).filter((l) => l[2] === k).length * 32;
      const y = q > 0 ? ry + (stackY - ry) * q * q : ry;
      return <div key={i} style={{position: 'absolute', left: (q > 0 ? dropX : rx) - 15, top: y - 15, transform: `rotate(${p * 540}deg)`}}>
        <Foto src={img} s={30} ring={col(s)}/>
        <div style={{position: 'absolute', right: -10, top: -8, padding: '1px 4px', borderRadius: 6, background: col(s), color: '#fff', fontFamily: SANS, fontWeight: 800, fontSize: 7, transform: `rotate(${-p * 540}deg)`}}>{s}</div>
      </div>;
    })}
    {on(f, 67.9) && <Box x={18} y={417} w={294} h={69} r={12} c={C.sl} style={{transform: `translateY(${(1 - tw(f, 67.9, 68.2)) * 30}px)`, opacity: tw(f, 67.9, 68.1)}}>
      <div style={{position: 'absolute', left: 12, top: 12}}><Foto src="img/maria.jpg" s={42}/></div>
      <div style={{position: 'absolute', left: 64, top: 11, fontFamily: SANS, fontWeight: 800, fontSize: 10}}>María R. · puntaje 92</div>
      <Mono x={64} y={28} s={7}>+52 55 1234 5678</Mono>
      <Mono x={64} y={44} s={6} c="#666">cocina pequeña · $18,400 · quiere llamada</Mono>
      <div style={{position: 'absolute', right: 10, top: 8}}><Tile n="slack" s={24}/></div>
    </Box>}
    {on(f, 69.6) && <Mono x={410} y={402} s={6} c={C.sl} style={{opacity: tw(f, 69.6, 69.9)}}>SIGUIENTE → TU CALENDARIO</Mono>}
  </>;
};

// 3) dominó hasta tu calendario
const Domino: React.FC<{f: number}> = ({f}) => {
  const booked = on(f, 73.3), sms = on(f, 75.9);
  const sw = tw(f, 72.5, 73.3, 0, 0.8, 'lin');
  const days = ['LUN', 'MAR', 'MIÉ', 'JUE', 'VIE'];
  const busy = [[0, 0], [3, 0], [2, 1], [1, 2], [4, 2], [0, 3], [3, 3]];
  return <>
    <Box x={18} y={35} w={207} h={61} r={12} c={C.sl} bg={C.slSoft} style={{opacity: tw(f, 71.4, 71.7), transform: `scale(${tw(f, 71.4, 71.7, 0.8, 1)})`}}>
      <div style={{position: 'absolute', left: 12, top: 10}}><Foto src="img/maria.jpg" s={36}/></div>
      <div style={{position: 'absolute', left: 58, top: 12, fontFamily: SANS, fontWeight: 800, fontSize: 11}}>“¡Sí, hablemos!”</div>
      <Mono x={58} y={32} s={5.6} c="#555">MARÍA R. · PUNTAJE 92</Mono>
    </Box>
    <Box x={287} y={26} w={245} h={188} r={12}>
      <div style={{position: 'absolute', left: 12, top: 12}}><Tile n="gcal" s={22}/></div>
      <Mono x={42} y={18} s={7} style={{fontWeight: 700}}>TU CALENDARIO</Mono>
      {days.map((d, i) => <Mono key={d} x={30 + i * 41} y={48} s={5.6} w={38} center c={d === 'JUE' ? C.sl : '#666'}>{d}</Mono>)}
      {['09', '10', '11', '12'].map((h, r) => <React.Fragment key={h}><Mono x={8} y={70 + r * 29} s={5.6} c="#666">{h}</Mono>
        {days.map((_, c) => <div key={c} style={{position: 'absolute', left: 30 + c * 41, top: 64 + r * 29, width: 37, height: 24, borderRadius: 3, border: '1px solid #ddd', background: busy.some(([a, b]) => a === c && b === r) ? '#EFEFEC' : '#fff'}}/>)}</React.Fragment>)}
      {booked && <div style={{position: 'absolute', left: 153, top: 93, width: 37, height: 24, borderRadius: 3, border: `2px solid ${C.ink}`, background: C.sl, boxSizing: 'border-box', color: '#fff', fontFamily: MONO, fontWeight: 700, fontSize: 6, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${tw(f, 73.3, 73.5, 1.6, 1)})`}}>MARÍA</div>}
    </Box>
    <svg style={{position: 'absolute', left: 0, top: 0}} width="551" height="501">
      <line x1="31" y1="299" x2="313" y2="299" stroke={C.ink} strokeWidth="2.5"/>
      {Array.from({length: 9}).map((_, i) => {
        const a = tw(f, 72.4 + i * 0.08, 72.6 + i * 0.08, 0, 72, 'lin');
        const x = 64 + i * 29;
        return <g key={i} transform={`rotate(${a} ${x + 9} 299)`}><rect x={x} y={243} width="9" height="56" rx="2" fill={a > 1 ? C.slSoft : '#fff'} stroke={C.ink} strokeWidth="2"/><circle cx={x + 4.5} cy="256" r="1.5" fill={C.ink}/><circle cx={x + 4.5} cy="285" r="1.5" fill={C.ink}/></g>;
      })}
    </svg>
    <Box x={345} y={242} w={118} h={58} r={10} c={booked ? C.sl : C.ink} bg={booked ? C.slSoft : '#fff'}>
      <div style={{position: 'absolute', left: 10, top: 12}}><Tile n="calendly" s={30}/></div>
      <Mono x={50} y={16} s={7.5} style={{fontWeight: 700}}>AGENDA</Mono><Mono x={50} y={30} s={5.6} c="#666">LA LLAMADA</Mono>
    </Box>
    <svg style={{position: 'absolute', left: 51, top: 355}} width="96" height="110" viewBox="0 0 96 110">
      <rect x="40" y="0" width="16" height="9" rx="2" fill="#fff" stroke={C.ink} strokeWidth="2"/>
      <circle cx="48" cy="58" r="46" fill="#fff" stroke={C.ink} strokeWidth="2.5"/>
      <line x1="48" y1="58" x2={48 + Math.sin((sw / 0.8) * Math.PI * 1.75) * 34} y2={58 - Math.cos((sw / 0.8) * Math.PI * 1.75) * 34} stroke={C.sl} strokeWidth="2.5"/><circle cx="48" cy="58" r="3" fill={C.sl}/>
    </svg>
    <div style={{position: 'absolute', left: 51, top: 432, width: 96, textAlign: 'center', fontFamily: SANS, fontWeight: 800, fontSize: 12}}>{sw.toFixed(1)}s</div>
    <Mono x={20} y={470} s={5.6} w={158} center c="#666">DE SÍ A AGENDADA</Mono>
    {on(f, 75.2) && <Box x={206} y={349} w={106} h={52} r={10} c={C.pink} bg="#FDEFF4" style={{transform: `scale(${tw(f, 75.2, 75.4, 0.7, 1)})`}}>
      <div style={{position: 'absolute', left: 10, top: 10}}><Tile n="twilio" s={28}/></div><Mono x={48} y={18} s={7} style={{fontWeight: 700}}>MENSAJE</Mono>
    </Box>}
    {on(f, 75.4) && !sms && <div style={{position: 'absolute', left: 312 + tw(f, 75.4, 75.9) * 100, top: 371, width: 9, height: 9, borderRadius: 5, border: `2px solid ${C.ink}`, background: '#fff'}}/>}
    <div style={{position: 'absolute', left: 418, top: 330, width: 79, height: 157, borderRadius: 14, border: `3px solid ${C.ink}`, background: '#F4F4F1', boxSizing: 'border-box'}}>
      <div style={{position: 'absolute', left: 25, top: 6, width: 24, height: 7, borderRadius: 4, background: C.ink}}/>
      {sms && <div style={{position: 'absolute', left: 5, top: 36, width: 63, padding: 5, borderRadius: 6, background: C.slSoft, border: `1.5px solid ${C.sl}`, fontFamily: SANS, fontSize: 5.8, lineHeight: '8px', transform: `scale(${tw(f, 75.9, 76.1, 0.6, 1)})`}}>Confirmada:<br/>jue 10:00 con<br/>tu cocina co. ✓<div style={{marginTop: 4, height: 9, borderRadius: 3, background: C.sl}}/></div>}
    </div>
  </>;
};

// 4) cotización y depósito
const Quote: React.FC<{f: number}> = ({f}) => {
  const steps = [['COTIZACIÓN', 77.8], ['DEPÓSITO', 78.4], ['LISTO', 79.3]] as const;
  const won = on(f, 79.3);
  return <>
    <Box x={12} y={35} w={156} h={213} r={12}>
      <div style={{position: 'absolute', left: 46, top: 14}}><Foto src="img/maria.jpg" s={60} ring={C.sl}/></div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 82, textAlign: 'center', fontFamily: SANS, fontWeight: 800, fontSize: 10}}>María R.</div>
      <Img src={staticFile('img/cocina2.jpg')} style={{position: 'absolute', left: 10, top: 104, width: 132, height: 70, objectFit: 'cover', borderRadius: 4}}/>
      <Mono x={0} y={186} s={5.6} w={152} center>COCINA PEQUEÑA · $8,000</Mono>
    </Box>
    <Box x={193} y={29} w={208} h={451} r={16} c={C.sl} bg={C.slBg}>
      <Box x={17} y={17} w={120} h={262} r={8}>
        <div style={{position: 'absolute', left: 12, top: 12}}><Tile n="pandadoc" s={24}/></div>
        <Mono x={50} y={20} s={7.5} style={{fontWeight: 700}}>COTIZACIÓN</Mono>
        {[['Gabinetes', '$4,200'], ['Encimera', '$1,900'], ['Instalación', '$1,900']].map(([a, b], i) => <div key={a} style={{position: 'absolute', left: 12, top: 62 + i * 25, width: 92, display: 'flex', justifyContent: 'space-between', fontFamily: SANS, fontSize: 6.8, opacity: tw(f, 77.5 + i * 0.15, 77.7 + i * 0.15)}}><span style={{color: '#555'}}>{a}</span><b>{b}</b></div>)}
        <Mono x={0} y={170} s={5.6} w={116} center c="#666">DEPÓSITO 30%</Mono>
        <div style={{position: 'absolute', left: 0, right: 0, top: 184, textAlign: 'center', fontFamily: SANS, fontWeight: 800, fontSize: 12, opacity: tw(f, 78.4, 78.6)}}>$2,400</div>
        {won && <div style={{position: 'absolute', left: 6, top: 120, padding: '3px 8px', borderRadius: 5, border: `2px solid ${C.sl}`, background: C.slSoft, color: C.sl, fontFamily: MONO, fontWeight: 800, fontSize: 8.5, letterSpacing: 1, transform: `rotate(-8deg) scale(${tw(f, 79.3, 79.45, 1.7, 1)})`}}>LISTO · GANADA</div>}
      </Box>
      <Box x={151} y={43} w={43} h={82} r={8}>
        <div style={{position: 'absolute', left: 14, top: 8, width: 10, height: 26, borderRadius: 3, background: C.ink}}/>
        <div style={{position: 'absolute', left: 9, top: 44, transform: `translateY(${(1 - tw(f, 78.2, 78.45)) * -26}px)`}}><Tile n="stripe" s={22}/></div>
      </Box>
      {steps.map(([l, t], i) => <React.Fragment key={l}>
        <div style={{position: 'absolute', left: 31 + i * 50, top: 301, width: 20, height: 20, borderRadius: 10, background: on(f, t) ? C.sl : '#fff', border: `2px solid ${on(f, t) ? C.sl : '#bbb'}`, boxSizing: 'border-box', transform: `scale(${on(f, t) ? tw(f, t, t + 0.2, 1.4, 1) : 1})`}}/>
        <Mono x={11 + i * 50} y={326} s={5} w={60} center c={C.sl}>{l}</Mono>
      </React.Fragment>)}
      <Box x={17} y={357} w={170} h={69} r={10}>
        <Mono x={0} y={14} s={6.5} w={166} center c={C.sl} style={{fontWeight: 700}}>VENTA GANADA</Mono>
        <div style={{position: 'absolute', left: 0, right: 0, top: 30, textAlign: 'center', fontFamily: SANS, fontWeight: 800, fontSize: 15}}>{won ? '$8,000' : '—'}</div>
      </Box>
    </Box>
    <Box x={425} y={35} w={113} h={213} r={12}>
      <Mono x={0} y={16} s={6.5} w={109} center style={{fontWeight: 700}}>PERSIGUIENDO</Mono>
      {['LLAMADAS', 'EMAILS', 'MENSAJES'].map((l, i) => <div key={l} style={{position: 'absolute', left: 12, top: 40 + i * 51, width: 85, height: 40, borderRadius: 6, background: '#F1F1EE', border: '1px solid #e2e2df', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 8px', boxSizing: 'border-box', fontFamily: MONO, fontSize: 6}}>{l}<b style={{color: on(f, 80.4) ? C.sl : C.ink, fontSize: 9}}>{on(f, 80.4 + i * 0.1) ? '0' : '–'}</b></div>)}
    </Box>
  </>;
};

export const Sales: React.FC<{f: number}> = ({f}) => (
  <Mod f={f} tema={SL} num="02" nombre="VENTAS" agentes="22 AGENTES" logos={['callrail', 'hubspot', 'calendly', 'stripe']} hdr={SL_HDR(f)} t0={59.9} t1={82.0}>
    <Slide f={f} a={59.9} b={65.7} first><Inbox f={f}/></Slide>
    <Slide f={f} a={65.7} b={71.0}><Scorer f={f}/></Slide>
    <Slide f={f} a={71.0} b={77.3}><Domino f={f}/></Slide>
    <Slide f={f} a={77.3} b={82.0} last><Quote f={f}/></Slide>
  </Mod>
);
