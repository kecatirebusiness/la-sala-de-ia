import React from 'react';
import {Img, staticFile} from 'remotion';
import {C, F, MONO, SANS, Ico, Tile, tw, on, FPS, OC, SL, typed} from './theme';
import {Mod, Slide, H} from './Mod';
import {ST} from './Wheel';

const Box: React.FC<{x: number; y: number; w: number; h: number; c?: string; bg?: string; r?: number; bw?: number; style?: React.CSSProperties; children?: React.ReactNode}> = ({x, y, w, h, c = C.ink, bg = '#fff', r = 10, bw = 2.5, style, children}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: r, border: `${bw}px solid ${c}`, background: bg, boxSizing: 'border-box', ...style}}>{children}</div>
);
const Mono: React.FC<{x: number; y: number; s?: number; c?: string; w?: number; center?: boolean; children: React.ReactNode; style?: React.CSSProperties}> = ({x, y, s = 8, c = C.ink, w, center, children, style}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, textAlign: center ? 'center' : undefined, fontFamily: MONO, fontSize: s, letterSpacing: 0.6, color: c, whiteSpace: 'pre', ...style}}>{children}</div>
);

const HDR: H[] = [
  {t: 84.5, l1: 'LA CAPA', l2: 'LO CONECTA'},
  {t: 85.8, l1: 'LA CAPA', v1: 'DE ARRIBA', l2: 'LO CONECTA'},
  {t: 87.2, l1: 'LA CAPA', v1: 'DE ARRIBA', l2: 'LO CONECTA', v2: '6 / 6'},
  {t: 88.4, l1: 'POR', l2: 'CONECTADOS', v2: '0 / 3'},
  {t: 88.9, l1: 'POR', v1: 'MCP', l2: 'CONECTADOS', v2: '0 / 3'},
  {t: 90.3, l1: 'POR', v1: 'MCP', l2: 'CONECTADOS', v2: '1 / 3'},
  {t: 91.5, l1: 'POR', v1: 'MCP', l2: 'CONECTADOS', v2: '2 / 3'},
  {t: 92.4, l1: 'POR', v1: 'MCP', l2: 'CONECTADOS', v2: '3 / 3'},
  {t: 93.4, l1: 'POR DEBAJO', l2: 'TU'},
  {t: 94.4, l1: 'POR DEBAJO', v1: 'ARCHIVOS', l2: 'TU'},
  {t: 95.6, l1: 'POR DEBAJO', v1: 'ARCHIVOS', l2: 'TU', v2: 'VOZ'},
  {t: 96.4, l1: 'POR DEBAJO', v1: 'ARCHIVOS', l2: 'TU', v2: 'OFERTA'},
  {t: 97.3, l1: 'POR DEBAJO', v1: 'ARCHIVOS', l2: 'TUS', v2: 'REGLAS'},
  {t: 98.3, l1: 'VENTAS LEÍDAS', l2: 'LO QUE CERRÓ'},
  {t: 98.9, l1: 'VENTAS LEÍDAS', v1: '4', l2: 'LO QUE CERRÓ'},
  {t: 99.4, l1: 'VENTAS LEÍDAS', v1: '14', l2: 'LO QUE CERRÓ'},
  {t: 101.1, l1: 'VENTAS LEÍDAS', v1: '14', l2: 'LO QUE CERRÓ', v2: 'COCINAS PEQ.'},
  {t: 102.2, l1: 'VENTAS LEÍDAS', v1: '14', l2: 'DE VUELTA A', v2: 'INVESTIGACIÓN'},
  {t: 104.3, l1: 'PRÓXIMA SEMANA', l2: 'HOJAS DE CÁLCULO'},
  {t: 105.4, l1: 'PRÓXIMA SEMANA', v1: '5 POSTS', l2: 'HOJAS DE CÁLCULO'},
  {t: 106.9, l1: 'PRÓXIMA SEMANA', v1: '5 POSTS', l2: 'HOJAS DE CÁLCULO', v2: '0'},
];

// mini estación (igual que en la rueda, en pequeño)
const Mini: React.FC<{i: number; x: number; y: number}> = ({i, x, y}) => {
  const s = ST[i];
  return <div style={{position: 'absolute', left: x, top: y}}>
    <div style={{fontFamily: MONO, fontSize: 4.6, color: C.ink, marginBottom: 2, display: 'flex', alignItems: 'center', gap: 2}}><span style={{width: 4, height: 4, borderRadius: 2, background: s.c}}/>{s.label}</div>
    <div style={{width: 72, height: 38, borderRadius: 4, border: `2px solid ${s.c}`, background: s.c + '1a'}}/>
    <div style={{width: 72, height: 15, borderRadius: 4, border: `2px solid ${s.c}`, background: s.c + '1a', marginTop: 3, display: 'flex', alignItems: 'center', gap: 2, padding: '0 2px', boxSizing: 'border-box'}}>{s.tools.map((t) => <Ico key={t} n={t} s={9}/>)}</div>
  </div>;
};
const MX = [[24, 188], [24, 265], [24, 342], [284, 188], [284, 265], [284, 342]];

const OnTop: React.FC<{f: number}> = ({f}) => {
  const bar = tw(f, 84.6, 85.6);
  return <>
    <div style={{position: 'absolute', left: 73 + (1 - bar) * 200, top: 65, width: 403 * bar + 1, height: 40, borderRadius: 20, border: `2.5px solid ${C.oc}`, background: C.ocSoft, boxSizing: 'border-box'}}/>
    <Box x={199} y={53} w={152} h={62} r={10} c={C.oc} style={{opacity: tw(f, 84.6, 84.9)}}>
      <div style={{position: 'absolute', left: 10, top: 12}}><Tile n="clawd" s={34}/></div>
      <Mono x={52} y={17} s={8} style={{fontWeight: 700}}>CLAUDE CODE</Mono>
      <Mono x={52} y={32} s={5.4} c="#666">LA CAPA DE ARRIBA</Mono>
    </Box>
    <svg style={{position: 'absolute', left: 0, top: 0}} width="551" height="501">
      {MX.map(([x, y], i) => {
        const p = tw(f, 86.3 + i * 0.15, 86.9 + i * 0.15, 0, 1, 'lin');
        const x0 = 215 + i * 24, x1 = x + 85 + 36;
        return <line key={i} x1={x0} y1={110} x2={x0 + (x1 - x0) * p} y2={110 + (y - 2 - 110) * p} stroke={ST[i].c} strokeWidth="2" strokeDasharray="5 4"/>;
      })}
    </svg>
    {MX.map(([x, y], i) => <div key={i} style={{opacity: tw(f, 84.8 + i * 0.1, 85.2 + i * 0.1)}}><Mini i={i} x={x + 85} y={y}/></div>)}
    <Mono x={0} y={455} s={6} w={551} center c={C.oc} style={{opacity: tw(f, 87.2, 87.5)}}>6 EQUIPOS · UNA SOLA CAPA LOS MANEJA</Mono>
  </>;
};

const Mcp: React.FC<{f: number}> = ({f}) => {
  const tg = [['TU CRM', ['hubspot'], 90.3], ['TU CALENDARIO', ['gcal'], 91.5], ['TUS CANALES', ['instagram', 'tiktok', 'linkedin', 'youtube'], 92.4]] as const;
  const px = [140, 275, 410];
  return <>
    <Box x={200} y={22} w={150} h={46} r={10} c={C.oc} bg={C.ocSoft}>
      <div style={{position: 'absolute', left: 10, top: 7}}><Tile n="clawd" s={28}/></div>
      <Mono x={46} y={10} s={7.5} style={{fontWeight: 700}}>CLAUDE CODE</Mono><Mono x={46} y={24} s={5} c="#666">EL ORQUESTADOR</Mono>
    </Box>
    <div style={{position: 'absolute', left: 273, top: 68, width: 4, height: 92, background: C.oc}}/>
    <div style={{position: 'absolute', left: 24, top: 160, width: 503, height: 40, borderRadius: 20, border: `2.5px solid ${C.ink}`, background: '#fff', boxSizing: 'border-box', opacity: tw(f, 88.8, 89.1)}}>
      <div style={{position: 'absolute', left: 8, top: 5}}><Tile n="mcp" s={26}/></div>
      <Mono x={42} y={11} s={9} style={{fontWeight: 700}}>MCP</Mono>
      {[0, 1, 2, 3, 4, 5, 6].map((i) => <div key={i} style={{position: 'absolute', left: 90 + i * 58, top: 13, width: 9, height: 9, borderRadius: 5, border: `1.8px solid ${C.ink}`, boxSizing: 'border-box'}}/>)}
    </div>
    {tg.map(([l, logos, t], i) => {
      const plug = tw(f, t - 0.3, t, 0, 1);
      const ok = on(f, t);
      return <React.Fragment key={l}>
        <svg style={{position: 'absolute', left: px[i] - 20, top: 196}} width="40" height="160">
          <line x1="20" y1={22 + (1 - plug) * 40} x2="20" y2="160" stroke={C.ink} strokeWidth="3"/>
          <rect x="8" y={4 + (1 - plug) * 40} width="24" height="18" rx="3" fill={ok ? C.ocSoft : '#fff'} stroke={C.ink} strokeWidth="2.5"/>
          <line x1="14" y1={(1 - plug) * 40} x2="14" y2={6 + (1 - plug) * 40} stroke={C.ink} strokeWidth="3"/><line x1="26" y1={(1 - plug) * 40} x2="26" y2={6 + (1 - plug) * 40} stroke={C.ink} strokeWidth="3"/>
        </svg>
        {ok && <div style={{position: 'absolute', left: px[i] + 14, top: 192, width: 10, height: 10, borderRadius: 5, background: C.sl}}/>}
        <Box x={px[i] - 62} y={356} w={124} h={92} r={10} c={ok ? C.oc : '#c9c9c6'} style={{opacity: ok ? 1 : 0.55}}>
          <Mono x={0} y={12} s={6.2} w={120} center style={{fontWeight: 700}}>{l}</Mono>
          <div style={{position: 'absolute', left: 0, right: 0, top: 36, display: 'flex', justifyContent: 'center', gap: 4}}>{logos.map((g) => <Tile key={g} n={g} s={logos.length > 1 ? 24 : 36}/>)}</div>
        </Box>
      </React.Fragment>;
    })}
  </>;
};

const Files: React.FC<{f: number}> = ({f}) => {
  const up = tw(f, 93.6, 94.4);
  const fl = [['voz.md', 'CÓMO HABLAS', 'Cálida, corta.\nSin jerga.', 95.6], ['oferta.md', 'QUÉ VENDES', 'Cocinas desde\n$6,000.', 96.4], ['reglas.md', 'QUÉ NECESITA DE TI', 'Cotización de más\nde $15k → pregúntame.', 97.3]] as const;
  const cur = [...fl].reverse().find((x) => on(f, x[3]));
  return <>
    <div style={{position: 'absolute', inset: 0, transform: `translateY(${-up * 110}px)`}}>
      {MX.map(([x, y], i) => <Mini key={i} i={i} x={i >= 3 ? 340 : 140} y={y - 170}/>)}
      <Box x={62} y={184} w={425} h={44} r={22} c={C.oc} bg={C.ocSoft}>
        <div style={{position: 'absolute', left: 8, top: 4}}><Tile n="clawd" s={30}/></div>
        <Mono x={0} y={14} s={8} w={421} center style={{fontWeight: 700}}>CLAUDE CODE · LEE PRIMERO</Mono>
      </Box>
      <svg style={{position: 'absolute', left: 0, top: 0}} width="551" height="700">
        {[98, 275, 452].map((x) => <line key={x} x1={x} y1={228} x2={x} y2={282} stroke={C.oc} strokeWidth="2" strokeDasharray="5 4"/>)}
        <line x1="10" y1="284" x2="541" y2="284" stroke={C.ink} strokeWidth="2.5"/>
        {Array.from({length: 40}).map((_, i) => <line key={i} x1={10 + i * 13.5} y1={286} x2={2 + i * 13.5} y2={296} stroke="#bbb" strokeWidth="1"/>)}
      </svg>
      {fl.map(([n, l, body, t], i) => {
        const a = on(f, t);
        return <Box key={n} x={20 + i * 177} y={330} w={157} h={150} r={10} c={a ? C.oc : '#bdbdbd'} bg={a ? C.ocSoft : '#F7F7F5'}>
          <div style={{position: 'absolute', left: 17, top: 10, width: 120, height: 30, borderRadius: 6, border: `2.5px solid ${a ? C.ink : '#bbb'}`, background: '#fff', boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: MONO, fontSize: 10, color: a ? C.ink : '#999'}}>{n}</div>
          <Mono x={0} y={56} s={5.8} w={153} center c={a ? C.oc : '#bbb'}>{l}</Mono>
          <div style={{position: 'absolute', left: 16, top: 74, fontFamily: SANS, fontSize: 8.5, lineHeight: '12px', whiteSpace: 'pre', color: C.ink}}>{a ? body : ''}</div>
        </Box>;
      })}
    </div>
    <div style={{position: 'absolute', left: 24, top: 452, width: 503, height: 36, borderRadius: 8, background: C.ink, display: 'flex', alignItems: 'center', padding: '0 14px', boxSizing: 'border-box', opacity: tw(f, 94.6, 94.9)}}>
      <span style={{fontFamily: MONO, fontWeight: 700, fontSize: 9.5, color: '#fff'}}>$ cat {typed(cur ? cur[0] : '', tw(f, cur ? cur[3] : 0, (cur ? cur[3] : 0) + 0.4))}</span>
      <span style={{flex: 1}}/><span style={{fontFamily: MONO, fontSize: 6, color: '#aaa'}}>NO ES UNA BASE DE DATOS</span>
    </div>
  </>;
};

const Looker: React.FC<{f: number}> = ({f}) => {
  const rows = [['COCINAS PEQUEÑAS', 0.75, 0.06, '4 cerradas'], ['ISLAS DE LUJO', 0, 0.19, ''], ['PLANTA ABIERTA', 0.19, 0.12, '1 cerrada'], ['AYUDA DIY', 0.19, 0.06, '1 cerrada']] as const;
  const g = tw(f, 98.9, 100.4);
  const focus = on(f, 102.2);
  const back = tw(f, 102.3, 103.3, 0, 1, 'lin');
  return <>
    <Box x={29} y={28} w={190} h={63} r={12} c={C.mk} bg={focus && back > 0.95 ? C.mkSoft : '#fff'}>
      <div style={{position: 'absolute', left: 12, top: 14}}><Tile n="gtrends" s={30}/></div>
      <Mono x={56} y={18} s={8} style={{fontWeight: 700}}>INVESTIGACIÓN</Mono>
      <Mono x={56} y={34} s={5.4} c="#777">{back > 0.95 ? 'YA SABE QUÉ VENDIÓ' : 'ESTACIÓN 01'}</Mono>
    </Box>
    <svg style={{position: 'absolute', left: 0, top: 0}} width="551" height="501">
      <path d="M219 60 H535 V180 H500" fill="none" stroke="#D7D5DE" strokeWidth="9"/>
      {focus && <path d="M500 180 H535 V60 H222" fill="none" stroke={C.ink} strokeWidth="9" strokeDasharray="520" strokeDashoffset={520 * (1 - back)}/>}
      {focus && <path d="M500 180 H535 V60 H222" fill="none" stroke={C.oc} strokeWidth="6" strokeDasharray="520" strokeDashoffset={520 * (1 - back)}/>}
      {focus && back > 0.95 && <polygon points="222,52 222,68 210,60" fill={C.oc}/>}
    </svg>
    {[0, 1, 2, 3, 4, 5].map((i) => { const t = 98.7 + i * 0.25; const p = tw(f, t, t + 0.5, 0, 1, 'lin'); return p > 0 && p < 1 ? <div key={i} style={{position: 'absolute', left: 230 + p * 300, top: 52, padding: '1px 4px', borderRadius: 3, background: i % 3 === 1 ? '#FFD6DE' : C.slSoft, border: `1.5px solid ${i % 3 === 1 ? C.pink : C.sl}`, fontFamily: MONO, fontSize: 5, color: i % 3 === 1 ? C.pink : C.sl}}>{i % 3 === 1 ? 'perdida' : 'ganada'}</div> : null; })}
    <Box x={24} y={123} w={476} h={294} r={12} c={C.oc}>
      <div style={{position: 'absolute', left: 14, top: 14}}><Tile n="looker" s={30}/></div>
      <Mono x={56} y={16} s={8.5} style={{fontWeight: 700}}>LOOKER STUDIO</Mono>
      <Mono x={56} y={32} s={5.4} c="#666">LO QUE DE VERDAD CERRÓ · ESTA SEMANA</Mono>
      {rows.map(([l, a, b, n], i) => {
        const dim = focus && i > 0;
        return <React.Fragment key={l}>
          <Mono x={14} y={84 + i * 52} s={6.5} c={dim ? '#aaa' : C.ink} style={{fontWeight: 700}}>{l}</Mono>
          <div style={{position: 'absolute', left: 150, top: 78 + i * 52, width: 302, height: 22, borderRadius: 5, background: '#F3F3F0', border: '1px solid #e6e6e3', overflow: 'hidden', opacity: dim ? 0.45 : 1}}>
            <div style={{position: 'absolute', left: 0, top: 0, height: '100%', width: `${a * 100 * g}%`, background: focus && i === 0 ? C.oc : C.ocMid, borderRadius: 4}}/>
            <div style={{position: 'absolute', left: `${a * 100 * g}%`, top: 0, height: '100%', width: `${b * 100 * g}%`, background: '#FBCFD8'}}/>
            {n && g > 0.9 && <span style={{position: 'absolute', right: 6, top: 5, fontFamily: SANS, fontWeight: 700, fontSize: 7, color: C.ink}}>{n}</span>}
          </div>
        </React.Fragment>;
      })}
      {focus && <Mono x={0} y={268} s={6.5} w={472} center c={C.oc} style={{fontWeight: 700, opacity: tw(f, 102.2, 102.5)}}>COCINAS PEQUEÑAS CERRÓ 4 DE 6</Mono>}
    </Box>
  </>;
};

const Lanes: React.FC<{f: number}> = ({f}) => {
  const days = ['LUN', 'MAR', 'MIÉ', 'JUE', 'VIE', 'SÁB', 'DOM'];
  const cols = [0, 2, 4, 6];
  const cross = tw(f, 107.0, 107.4);
  return <>
    <Mono x={0} y={36} s={7.5} w={551} center style={{fontWeight: 700}}>PRÓXIMA SEMANA · CARRILES DE CONTENIDO</Mono>
    {days.map((d, i) => <Mono key={d} x={190 + i * 46} y={62} s={5.4} w={30} center c="#666">{d}</Mono>)}
    <Box x={24} y={85} w={150} h={162} r={8} c={C.oc} bg={C.ocSoft}>
      <Mono x={10} y={12} s={6.5} style={{fontWeight: 700}}>COCINAS PEQUEÑAS</Mono><Mono x={10} y={26} s={5.4} c={C.oc}>5 CARRILES</Mono>
    </Box>
    <Box x={181} y={85} w={332} h={162} r={8} c={C.oc} bg="#fff">
      {cols.map((c, ci) => [0, 1, 2, 3, 4].map((r) => {
        const t = 104.7 + (r * 4 + ci) * 0.06;
        return <div key={`${c}${r}`} style={{position: 'absolute', left: 10 + c * 46, top: 10 + r * 29, width: 38, height: 21, borderRadius: 4, background: C.ocMid, border: `1.5px solid ${C.oc}`, boxSizing: 'border-box', transform: `scale(${tw(f, t, t + 0.2)})`}}/>;
      }))}
    </Box>
    <div style={{position: 'absolute', left: 24, top: 258, width: 489, height: 12, borderRadius: 6, background: '#EFEFEC'}}/>
    {[['PLANTA ABIERTA', [1, 4]], ['AYUDA DIY', [0, 3, 6]]].map(([l, sl], k) => <React.Fragment key={l as string}>
      <div style={{position: 'absolute', left: 24, top: 282 + k * 46, width: 150, height: 34, borderRadius: 6, background: '#EFEFEC', fontFamily: MONO, fontSize: 5.8, color: '#666', display: 'flex', alignItems: 'center', paddingLeft: 10, boxSizing: 'border-box'}}>{l as string}</div>
      <div style={{position: 'absolute', left: 181, top: 282 + k * 46, width: 332, height: 34, borderRadius: 6, border: '1px solid #e2e2df', background: '#fff'}}>
        {(sl as number[]).map((c) => <div key={c} style={{position: 'absolute', left: 8 + c * 46, top: 6, width: 38, height: 20, borderRadius: 4, border: '1.5px solid #ccc'}}/>)}
      </div>
    </React.Fragment>)}
    <Box x={149} y={411} w={251} h={63} r={8} c={cross > 0 ? C.pink : C.ink}>
      <div style={{position: 'absolute', left: 12, top: 15}}><Tile n="gsheets" s={30}/></div>
      {Array.from({length: 3}).map((_, r) => Array.from({length: 4}).map((__, c) => <div key={`${r}${c}`} style={{position: 'absolute', left: 60 + c * 44, top: 10 + r * 14, width: 42, height: 12, border: '1px solid #ddd'}}/>))}
      <svg style={{position: 'absolute', left: 0, top: 0}} width="251" height="63"><line x1="4" y1="58" x2={4 + 240 * cross} y2={58 - 54 * cross} stroke={C.pink} strokeWidth="3"/></svg>
      {cross > 0.95 && <div style={{position: 'absolute', right: -9, top: -9, width: 18, height: 18, borderRadius: 9, background: C.pink, color: '#fff', fontWeight: 900, fontSize: 11, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>✕</div>}
    </Box>
  </>;
};

export const Orq: React.FC<{f: number}> = ({f}) => (
  <Mod f={f} tema={OC} num="03" nombre="ORQUESTADOR" agentes="6 AGENTES" logos={['clawd', 'mcp', 'gdrive', 'looker']} hdr={HDR} t0={84.5} t1={108.5}>
    <Slide f={f} a={84.5} b={88.4} first><OnTop f={f}/></Slide>
    <Slide f={f} a={88.4} b={93.4}><Mcp f={f}/></Slide>
    <Slide f={f} a={93.4} b={98.3}><Files f={f}/></Slide>
    <Slide f={f} a={98.3} b={104.3}><Looker f={f}/></Slide>
    <Slide f={f} a={104.3} b={108.5} last><Lanes f={f}/></Slide>
  </Mod>
);
