import React from 'react';
import {Img, staticFile, interpolate} from 'remotion';
import {C, F, MONO, SANS, Ico, Tile, Foto, tw, FPS} from './theme';

// La rueda: 56 agentes · 6 equipos. Coordenadas del cuadro 720x1280.
const CX = 360, CY = 617;
type St = {k: string; label: string; c: string; x: number; y: number; lx: number; ly: number; tools: string[]; n: number; side: 'L' | 'R'};
export const ST: St[] = [
  {k: 'research', label: 'INVESTIGACIÓN', c: C.teal, x: 65, y: 442, lx: 92, ly: 424, tools: ['gtrends', 'semrush'], n: 7, side: 'L'},
  {k: 'content', label: 'CONTENIDO', c: C.mk, x: 49, y: 580, lx: 76, ly: 562, tools: ['claude', 'higgsfield'], n: 8, side: 'L'},
  {k: 'posting', label: 'PUBLICACIÓN', c: C.pink, x: 65, y: 717, lx: 92, ly: 699, tools: ['metricool', 'manychat'], n: 13, side: 'L'},
  {k: 'leads', label: 'LEADS', c: C.blue, x: 529, y: 442, lx: 556, ly: 424, tools: ['callrail', 'hubspot'], n: 10, side: 'R'},
  {k: 'calls', label: 'LLAMADAS', c: C.sl, x: 545, y: 580, lx: 572, ly: 562, tools: ['calendly', 'twilio'], n: 5, side: 'R'},
  {k: 'follow', label: 'SEGUIMIENTO', c: C.yellow, x: 529, y: 718, lx: 556, ly: 700, tools: ['pandadoc', 'stripe'], n: 7, side: 'R'},
];
const W = 125, H = 68;

const Illus: React.FC<{k: string; c: string; f: number}> = ({k, c, f}) => {
  const t = f / FPS;
  if (k === 'research') return <svg width="110" height="52" viewBox="0 0 110 52"><rect x="3" y="3" width="104" height="46" rx="4" fill="#fff" stroke={C.ink} strokeWidth="2"/><path d={`M8 ${38 + Math.sin(t) * 2} C 25 ${10 + Math.sin(t * 1.3) * 4}, 35 40, 50 36 S 80 ${30 + Math.sin(t) * 3}, 102 33`} fill="none" stroke={c} strokeWidth="2.2"/></svg>;
  if (k === 'content') return <svg width="110" height="52" viewBox="0 0 110 52"><rect x="3" y="4" width="64" height="44" rx="4" fill="#fff" stroke={C.ink} strokeWidth="2"/><rect x="9" y="12" width="36" height="4" rx="2" fill={c}/><rect x="9" y="21" width="48" height="3" rx="1.5" fill="#bbb"/><rect x="9" y="29" width="44" height="3" rx="1.5" fill="#bbb"/><rect x="73" y="4" width="32" height="44" rx="3" fill={C.ink}/><rect x="78" y="9" width="22" height="15" rx="2" fill={c} opacity=".8"/><rect x="78" y="28" width="22" height="15" rx="2" fill="#fff"/></svg>;
  if (k === 'posting') return <svg width="110" height="52" viewBox="0 0 110 52"><path d="M8 5 h26 l-13 21 l13 21 h-26 l13 -21z" fill="#fff" stroke={C.ink} strokeWidth="2"/><path d={`M14 ${47 - (t % 3) * 4} h14 l-7 -${(t % 3) * 4}z`} fill={c}/>{[0, 1, 2, 3].map((i) => <rect key={i} x={44 + (i % 2) * 32} y={6 + Math.floor(i / 2) * 22} width="28" height="18" rx="3" fill={i === 1 ? c : '#fff'} stroke={C.ink} strokeWidth="2"/>)}</svg>;
  if (k === 'leads') return <svg width="110" height="52" viewBox="0 0 110 52">{[12, 26, 40].map((y) => <path key={y} d={`M6 ${y} H55 L72 26`} fill="none" stroke={C.ink} strokeWidth="2"/>)}<rect x="74" y="10" width="30" height="32" rx="4" fill="#fff" stroke={c} strokeWidth="2.4"/><text x="89" y="32" fontSize="14" textAnchor="middle" fill={c} fontFamily="Inter" fontWeight="700">1</text></svg>;
  if (k === 'calls') return <svg width="110" height="52" viewBox="0 0 110 52">{Array.from({length: 10}).map((_, i) => <rect key={i} x={6 + (i % 5) * 20} y={6 + Math.floor(i / 5) * 21} width="17" height="18" rx="3" fill={i === 6 ? c : '#fff'} stroke={C.ink} strokeWidth="2"/>)}</svg>;
  return <svg width="110" height="52" viewBox="0 0 110 52"><rect x="6" y="9" width="46" height="34" rx="3" fill="#FFF4CC" stroke="#e2c46a" strokeWidth="2"/><text x="29" y="30" fontSize="8.5" textAnchor="middle" fill="#8a6d00" fontFamily="JBM">COTIZ.</text><rect x="62" y="14" width="42" height="30" rx="3" fill="#fff" stroke={C.ink} strokeWidth="2"/><path d="M77 14 a6 6 0 0 1 12 0" fill="none" stroke={C.ink} strokeWidth="2"/></svg>;
};

export const Wheel: React.FC<{f: number; t0: number; dim?: number; youRight?: React.ReactNode; hubLabel?: string; loop?: number; pipe?: number; flow?: number; newLead?: number}> = ({f, t0, dim = 0, youRight, hubLabel, loop = 0, pipe = 0, flow = 0, newLead}) => {
  const rot = (f - F(t0)) * 0.35;
  const appear = (i: number) => interpolate(f - F(t0), [i * 2, i * 2 + 8], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const grey = (c: string) => (pipe > 0 ? '#bdbdbd' : c);
  return (
    <div style={{position: 'absolute', inset: 0}}>
      <div style={{position: 'absolute', left: 80, top: 405, fontFamily: MONO, fontSize: 9, letterSpacing: 1, color: C.mk}}>MARKETING · 28</div>
      <div style={{position: 'absolute', left: 570, top: 405, fontFamily: MONO, fontSize: 9, letterSpacing: 1, color: C.sl}}>VENTAS · 22</div>
      <svg style={{position: 'absolute', left: 0, top: 0}} width="720" height="1280">
        {ST.map((s, i) => {
          const ex = s.side === 'L' ? s.x + W : s.x, ey = s.y + H / 2;
          const a = Math.atan2(ey - CY, ex - CX), sx = CX + Math.cos(a) * 88, sy = CY + Math.sin(a) * 88;
          const mx = (sx + ex) / 2, my = (sy + ey) / 2;
          const d = ((f / FPS) * 0.9 + i * 0.17) % 1;
          return <g key={s.k} opacity={appear(i)}>
            <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={C.ink} strokeWidth="7.5" strokeLinecap="round"/>
            <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={grey(s.c)} strokeWidth="4.5" strokeLinecap="round"/>
            <circle cx={mx} cy={my} r="5" fill="#fff" stroke={C.ink} strokeWidth="1.6"/>
            {flow > 0 && <circle cx={ex + (sx - ex) * d} cy={ey + (sy - ey) * d} r="3.4" fill="#fff" stroke={s.c} strokeWidth="2" opacity={flow}/>}
          </g>;
        })}
        {/* rueda */}
        <g transform={`translate(${CX} ${CY})`}>
          <circle r="86" fill="#fff" stroke={C.oc} strokeWidth="4"/>
          <circle r="80" fill="none" stroke={C.ink} strokeWidth="5" strokeDasharray="2 7" transform={`rotate(${rot})`}/>
          <circle r="94" fill="none" stroke={C.oc} strokeWidth="3" strokeDasharray="10 7" opacity=".75" transform={`rotate(${-rot * 0.6})`}/>
          <g transform={`rotate(${rot})`}>
            {Array.from({length: 7}).map((_, i) => { const a = (i / 7) * Math.PI * 2; return <line key={i} x1={Math.cos(a) * 30} y1={Math.sin(a) * 30} x2={Math.cos(a) * 74} y2={Math.sin(a) * 74} stroke={C.ink} strokeWidth="1.6"/>; })}
            {Array.from({length: 7}).map((_, i) => { const a = ((i + 0.5) / 7) * Math.PI * 2; const x = Math.cos(a) * 54, y = Math.sin(a) * 54; return <g key={i} transform={`translate(${x} ${y}) rotate(${-rot})`}><circle r="12" fill={i % 3 === 0 ? '#E7DDFB' : '#fff'} stroke={C.ink} strokeWidth="1.8"/><rect x="-6" y="-3" width="12" height="6" rx="3" fill={C.ink}/><circle cx="-2.5" cy="0" r="1.2" fill="#fff"/><circle cx="2.5" cy="0" r="1.2" fill="#fff"/></g>; })}
          </g>
          <circle r="30" fill="#fff" stroke={C.oc} strokeWidth="2.5"/>
        </g>
      </svg>
      <Img src={staticFile('logos/clawd.svg')} style={{position: 'absolute', left: CX - 19, top: CY - 14, width: 38}}/>
      {hubLabel && <div style={{position: 'absolute', left: CX - 60, top: CY - 8, width: 120, textAlign: 'center', fontFamily: MONO, fontWeight: 800, fontSize: 12, color: C.ink, opacity: 0.85}}><span style={{background: '#FFF4CC', padding: '1px 4px', borderRadius: 3}}>{hubLabel}</span></div>}
      <div style={{position: 'absolute', left: CX - 72, top: 497, width: 144, height: 22, borderRadius: 11, background: C.ink, color: '#fff', fontFamily: MONO, fontWeight: 700, fontSize: 9.5, letterSpacing: 0.8, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>56 AGENTES · 6 EQUIPOS</div>
      {/* estaciones */}
      {ST.map((s, i) => (
        <div key={s.k} style={{opacity: appear(i) * (1 - dim * 0.55), transform: `scale(${0.85 + appear(i) * 0.15})`, transformOrigin: `${s.x + W / 2}px ${s.y + H / 2}px`, position: 'absolute', inset: 0, filter: pipe > 0 ? 'grayscale(1)' : undefined}}>
          <div style={{position: 'absolute', left: s.lx - 14, top: s.ly, display: 'flex', alignItems: 'center', gap: 5, fontFamily: MONO, fontSize: 9, letterSpacing: 0.6, color: C.ink}}><span style={{width: 8, height: 8, borderRadius: 4, background: s.c}}/>{s.label}</div>
          <div style={{position: 'absolute', left: s.x, top: s.y, width: W, height: H, borderRadius: 7, border: `2.5px solid ${s.c}`, background: s.c + '1a', boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Illus k={s.k} c={s.c} f={f}/></div>
          <div style={{position: 'absolute', left: s.x, top: s.y + 75, width: W, height: 30, borderRadius: 7, border: `2.5px solid ${s.c}`, background: s.c + '1a', boxSizing: 'border-box', display: 'flex', alignItems: 'center', padding: '0 5px', gap: 4}}>
            {s.tools.map((t) => <Tile key={t} n={t} s={20} fill={t === 'higgsfield' || t === 'metricool' ? C.lime : '#fff'}/>)}
            <div style={{display: 'flex', gap: 2, marginLeft: 3}}>{[0, 1, 2, 3].map((d) => <span key={d} style={{width: 7, height: 7, borderRadius: 4, border: `1.5px solid ${C.ink}`, background: (Math.floor(f / 8) + d + i) % 4 === 0 ? 'transparent' : s.c}}/>)}</div>
            <div style={{flex: 1}}/><div style={{fontFamily: MONO, fontSize: 9, color: C.ink}}>{s.n}</div>
          </div>
        </div>
      ))}
      {newLead !== undefined && (() => {
        const p = tw(f, newLead, newLead + 0.8);
        return <div style={{position: 'absolute', left: 470 + p * 40, top: 470 - p * 10, opacity: tw(f, newLead - 0.2, newLead), padding: '3px 8px', borderRadius: 6, background: '#fff', border: `2px solid ${C.blue}`, fontFamily: MONO, fontSize: 9, color: C.blue, fontWeight: 700}}>NUEVO LEAD</div>;
      })()}
      {/* tú */}
      <svg style={{position: 'absolute', left: 0, top: 0}} width="720" height="1280">
        <rect x={CX - 9} y={706} width={18} height={150} rx="4" fill="#fff" stroke={C.ink} strokeWidth="2"/>
        {[720, 735, 820, 835].map((y, i) => <rect key={y} x={CX - 5} y={y} width={10} height={3} rx="1.5" fill={[C.oc, C.mk, C.sl, C.mk][i]}/>)}
      </svg>
      <div style={{position: 'absolute', left: 247, top: 762, width: 226, height: 49, borderRadius: 9, border: `2.5px solid ${C.ink}`, background: '#F4F4F2', boxSizing: 'border-box', display: 'flex', alignItems: 'center', padding: '0 8px', gap: 8}}>
        <Foto src="img/tu-foto.png" s={32}/>
        <div><div style={{fontFamily: SANS, fontWeight: 800, fontSize: 12, color: C.ink}}>TÚ</div><div style={{fontFamily: MONO, fontSize: 7.5, color: C.sl, letterSpacing: 0.5}}>SÍ FINAL</div></div>
        <div style={{position: 'absolute', left: 88, top: -3, width: 48, height: 51, borderRadius: 8, border: `2.5px solid ${C.ink}`, background: '#fff', boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
          <div style={{width: 22, height: 22, borderRadius: 11, background: C.sl, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: 14, fontWeight: 900}}>✓</div>
        </div>
        <div style={{position: 'absolute', right: 8, display: 'flex', gap: 4}}>{youRight ?? <><Tile n="slack" s={26}/><Tile n="telegram" s={26}/></>}</div>
      </div>
      <div style={{position: 'absolute', left: 251, top: 851, width: 218, height: 52, borderRadius: 10, border: `2.5px solid ${C.sl}`, background: '#fff', boxSizing: 'border-box', display: 'flex', alignItems: 'center', padding: '0 10px', gap: 6}}>
        <span style={{width: 9, height: 9, borderRadius: 5, background: C.sl}}/><div style={{fontFamily: MONO, fontSize: 8.5, color: C.ink, marginRight: 4}}>EN VIVO EN</div>
        {['instagram', 'tiktok', 'linkedin', 'youtube'].map((l) => <Tile key={l} n={l} s={30}/>)}
      </div>
      {/* modo embudo / ciclo */}
      {pipe > 0 && <svg style={{position: 'absolute', left: 0, top: 0}} width="720" height="1280" opacity={pipe}>
        <path d="M70 900 H650" stroke={C.pink} strokeWidth="4" strokeDasharray="10 6"/>
        <text x="360" y="925" textAnchor="middle" fontFamily="JBM" fontSize="11" fill={C.pink}>✕ EMBUDO · LOS CLIENTES SE ESCAPAN</text>
        {[0, 1, 2, 3, 4].map((i) => { const p = ((f / FPS) * 0.8 + i * 0.2) % 1; return <circle key={i} cx={100 + p * 520} cy={900 + p * p * 120} r="5" fill={C.pink} opacity={1 - p}/>; })}
      </svg>}
      {loop > 0 && <svg style={{position: 'absolute', left: 0, top: 0}} width="720" height="1280">
        <path d="M190 452 C 250 425, 470 425, 530 452" fill="none" stroke={C.sl} strokeWidth="5" strokeDasharray="600" strokeDashoffset={600 * (1 - loop)} strokeLinecap="round"/>
        <path d="M128 858 C 160 960, 560 960, 592 858" fill="none" stroke={C.sl} strokeWidth="5" strokeDasharray="600" strokeDashoffset={600 * (1 - loop)} strokeLinecap="round"/>
        <g opacity={loop}><rect x="318" y="421" width="84" height="20" rx="10" fill="#fff" stroke={C.sl} strokeWidth="2"/><text x="360" y="435" textAnchor="middle" fontFamily="JBM" fontWeight="700" fontSize="10" fill={C.sl}>↻ CICLO</text></g>
      </svg>}
    </div>
  );
};
