import React from 'react';
import {Img, staticFile, interpolate, Easing} from 'remotion';
import TI from './tiempos.json';

export const FPS = 30;
export const TOTAL = Math.ceil((TI as any).total * FPS) + 15;

// ---- mapa de tiempo: segundo de la referencia -> frame de nuestro video (anclado frase a frase a la voz) ----
const A: [number, number][] = (TI as any).frases.map((f: any) => [f.anc, f.start]);
export const R = (t: number) => {
  if (t <= A[0][0]) return t + (A[0][1] - A[0][0]);
  for (let i = 0; i < A.length - 1; i++) {
    const [a0, b0] = A[i], [a1, b1] = A[i + 1];
    if (t < a1) return b0 + ((t - a0) / (a1 - a0)) * (b1 - b0);
  }
  const [aN, bN] = A[A.length - 1];
  return bN + (t - aN) * 1.0;
};
export const F = (t: number) => Math.round(R(t) * FPS);
export const WORDS: {w: string; a: number; b: number}[] = (TI as any).frases.flatMap((f: any) => f.words.map((w: any) => ({w: w[0], a: w[1], b: w[2]})));

// ---- easing ----
const EZ = Easing.bezier(0.22, 1, 0.36, 1);
const EIO = Easing.bezier(0.65, 0, 0.35, 1);
export const tw = (f: number, t0: number, t1: number, a = 0, b = 1, e: 'out' | 'io' | 'lin' = 'out') =>
  interpolate(f, [F(t0), Math.max(F(t0) + 1, F(t1))], [a, b], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: e === 'out' ? EZ : e === 'io' ? EIO : (x) => x});
export const twf = (f: number, f0: number, f1: number, a = 0, b = 1) =>
  interpolate(f, [f0, Math.max(f0 + 1, f1)], [a, b], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: EZ});
export const pop = (f: number, t: number, d = 0.35) => {
  const p = interpolate(f, [F(t), F(t) + d * FPS], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return p <= 0 ? 0 : 1 + Math.sin(p * Math.PI) * 0.12 * (1 - p) - (1 - EZ(p)) * 1;
};
export const on = (f: number, t: number) => f >= F(t);

// ---- colores ----
export const C = {
  ink: '#151515', grey: '#8A8A86', line: '#D9D9D6', paper: '#FFFFFF', chip: '#F2F2EF',
  mk: '#EC6A1E', mkBg: '#FEF7F3', mkSoft: '#FCE6DA', mkMid: '#F6B48C',
  sl: '#22C55E', slBg: '#F3FCF6', slSoft: '#DDF7E6', slMid: '#9BE3B5',
  oc: '#7C3AED', ocBg: '#F8F4FE', ocSoft: '#ECE3FC', ocMid: '#C4A8F7',
  blue: '#3B6FE0', teal: '#1FB5A8', pink: '#E5307A', yellow: '#F2B705', lime: '#D1FE17',
};
export type Tema = {c: string; bg: string; soft: string; mid: string};
export const MK: Tema = {c: C.mk, bg: C.mkBg, soft: C.mkSoft, mid: C.mkMid};
export const SL: Tema = {c: C.sl, bg: C.slBg, soft: C.slSoft, mid: C.slMid};
export const OC: Tema = {c: C.oc, bg: C.ocBg, soft: C.ocSoft, mid: C.ocMid};

export const fontCss = `
@font-face{font-family:'Inter';src:url('${staticFile('fonts/Inter.ttf')}') format('truetype');font-weight:100 900;}
@font-face{font-family:'JBM';src:url('${staticFile('fonts/jbm400.woff2')}') format('woff2');font-weight:400;}
@font-face{font-family:'JBM';src:url('${staticFile('fonts/jbm700.woff2')}') format('woff2');font-weight:700;}
@font-face{font-family:'JBM';src:url('${staticFile('fonts/jbm800.woff2')}') format('woff2');font-weight:800;}
`;
export const SANS = "'Inter', 'Helvetica Neue', Arial, sans-serif";
export const MONO = "'JBM', Menlo, monospace";

// ---- logos ----
const EXT: Record<string, string> = {
  gcal: 'svg', gmail: 'svg', gdrive: 'svg', gsheets: 'svg', gdocs: 'svg', ganalytics: 'svg', slack: 'svg', linkedin: 'svg', whatsapp: 'svg',
  youtube: 'svg', instagram: 'svg', telegram: 'svg', bitly: 'svg', looker: 'svg', tiktok: 'svg', gtrends: 'svg', clawd: 'svg', higgsfield: 'svg',
};
export const logoSrc = (n: string) => staticFile(`logos/${n}.${EXT[n] || 'png'}`);
// logo "app icon": cuadrado redondeado con borde
export const Ico: React.FC<{n: string; s?: number; bare?: boolean; style?: React.CSSProperties; bg?: string}> = ({n, s = 22, bare, style, bg}) => {
  if (n === 'user') return <div style={{width: s, height: s, borderRadius: s * 0.22, background: C.ink, display: 'flex', alignItems: 'center', justifyContent: 'center', ...style}}><svg width={s * 0.62} height={s * 0.62} viewBox="0 0 20 20"><circle cx="10" cy="7" r="4" fill="#fff"/><path d="M2 19c1-5 4.5-7 8-7s7 2 8 7z" fill="#fff"/></svg></div>;
  const full = ['higgsfield', 'hubspot', 'manychat', 'metricool', 'apollo', 'semrush', 'sparktoro', 'mcp', 'twilio', 'pandadoc', 'x', 'notion', 'callrail', 'stripe', 'quickbooks', 'canva', 'reddit', 'typeform'].includes(n);
  if (n === 'stripe') return <div style={{width: s, height: s, borderRadius: s * 0.22, background: '#635BFF', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontFamily: SANS, fontWeight: 800, fontSize: s * 0.66, ...style}}>S</div>;
  if (n === 'tiktok') return <div style={{width: s, height: s, borderRadius: s * 0.22, background: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center', ...style}}><Img src={logoSrc('tiktok')} style={{width: s * 0.62, height: s * 0.62, filter: 'invert(1) drop-shadow(1px 1px 0 #FE2C55) drop-shadow(-1px -1px 0 #25F4EE)'}}/></div>;
  if (bare || full) return <Img src={logoSrc(n)} style={{width: s, height: s, borderRadius: s * 0.22, objectFit: 'contain', ...style}}/>;
  return <div style={{width: s, height: s, borderRadius: s * 0.22, background: bg || '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', ...style}}><Img src={logoSrc(n)} style={{width: s * 0.78, height: s * 0.78, objectFit: 'contain'}}/></div>;
};
// tile con borde negro (como en las barras del módulo)
export const Tile: React.FC<{n: string; s?: number; c?: string; fill?: string; style?: React.CSSProperties}> = ({n, s = 26, c = C.ink, fill = '#fff', style}) => (
  <div style={{width: s, height: s, borderRadius: s * 0.24, border: `2px solid ${c}`, background: fill, display: 'flex', alignItems: 'center', justifyContent: 'center', boxSizing: 'border-box', ...style}}>
    <Ico n={n} s={s * 0.7}/>
  </div>
);

export const Foto: React.FC<{src: string; s: number; ring?: string; style?: React.CSSProperties}> = ({src, s, ring, style}) => (
  <div style={{width: s, height: s, borderRadius: '50%', overflow: 'hidden', border: ring ? `2px solid ${ring}` : undefined, boxSizing: 'border-box', background: '#ddd', ...style}}>
    <Img src={staticFile(src)} style={{width: '100%', height: '100%', objectFit: 'cover'}}/>
  </div>
);

export const Dots: React.FC<{c: string}> = ({c}) => <span style={{letterSpacing: 2, color: c}}>•••</span>;

// texto que se "escribe"
export const typed = (txt: string, p: number) => txt.slice(0, Math.round(txt.length * Math.max(0, Math.min(1, p))));
