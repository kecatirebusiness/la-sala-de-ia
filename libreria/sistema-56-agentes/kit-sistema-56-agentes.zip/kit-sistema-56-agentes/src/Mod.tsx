import React from 'react';
import {F, C, Tema, MONO, SANS, Tile, pop, Dots, FPS} from './theme';
import {interpolate} from 'remotion';

export type H = {t: number; l1: string; v1?: string; l2: string; v2?: string; c1?: Tema};

const Card: React.FC<{x: number; w: number; label: string; val?: string; c: string; bg: string; brd: string; big?: boolean; k: number; f: number; vc: string}> = ({x, w, label, val, c, bg, brd, k, f, vc}) => {
  const s = val ? interpolate(f - k, [0, 4, 9], [0.86, 1.06, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}) : 1;
  return (
    <div style={{position: 'absolute', left: x, top: 315, width: w, height: 58, borderRadius: 8, border: `2px solid ${brd}`, background: bg, boxSizing: 'border-box', padding: '8px 14px'}}>
      <div style={{fontFamily: MONO, fontSize: 10.5, letterSpacing: 2.2, color: '#77736d', textTransform: 'uppercase', whiteSpace: 'nowrap'}}>{label}</div>
      <div style={{fontFamily: SANS, fontWeight: 800, fontSize: val && val.length > 13 ? 21 : 26, lineHeight: '30px', color: vc, transform: `scale(${s})`, transformOrigin: 'left center', whiteSpace: 'nowrap', letterSpacing: -0.4}}>
        {val ?? <Dots c={c}/>}
      </div>
    </div>
  );
};

export const Headers: React.FC<{f: number; hdr: H[]; tema: Tema}> = ({f, hdr, tema}) => {
  let cur = hdr[0], ci = 0;
  hdr.forEach((h, i) => { if (f >= F(h.t)) { cur = h; ci = i; } });
  const prev = hdr[ci - 1];
  const k1 = cur.v1 !== undefined && (!prev || prev.v1 !== cur.v1) ? F(cur.t) : -99;
  const k2 = cur.v2 !== undefined && (!prev || prev.v2 !== cur.v2) ? F(cur.t) : -99;
  const t1c = cur.c1 || tema;
  return <>
    <Card x={135} w={218} label={cur.l1} val={cur.v1} c={t1c.c} bg={t1c.soft + '99'} brd={t1c.c} k={k1} f={f} vc={t1c.c}/>
    <Card x={367} w={218} label={cur.l2} val={cur.v2} c={C.ink} bg={C.chip} brd="#E2E1DC" k={k2} f={f} vc={C.ink}/>
  </>;
};

export const Mod: React.FC<{f: number; tema: Tema; num: string; nombre: string; agentes: string; logos: string[]; hdr: H[]; t0: number; t1: number; children?: React.ReactNode}> = ({f, tema, num, nombre, agentes, logos, hdr, t0, t1, children}) => {
  // puntitos de progreso
  const N = num === '03' ? 7 : 15;
  const prog = interpolate(f, [F(t0), F(t1)], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <>
      <Headers f={f} hdr={hdr} tema={tema}/>
      <div style={{position: 'absolute', left: 0, right: 0, top: 388, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 9, fontFamily: MONO, fontSize: 14, letterSpacing: 1, color: C.ink}}>
        <div style={{width: 12, height: 12, borderRadius: 6, background: tema.c}}/>{num} {nombre}
      </div>
      <div style={{position: 'absolute', left: 85, top: 416, width: 551, height: 501, borderRadius: 16, border: `2.5px solid ${tema.c}`, background: tema.bg, boxSizing: 'border-box', overflow: 'hidden'}}>
        {children}
      </div>
      <div style={{position: 'absolute', left: 85, top: 925, width: 551, height: 40, borderRadius: 12, border: `2.5px solid ${tema.c}`, background: tema.soft + 'aa', boxSizing: 'border-box', display: 'flex', alignItems: 'center', padding: '0 10px', gap: 7}}>
        <div style={{width: 10, height: 10, borderRadius: 5, border: `2px solid ${C.ink}`}}/>
        {logos.map((l) => <Tile key={l} n={l} s={25} fill={l === 'higgsfield' || l === 'metricool' ? C.lime : '#fff'}/>)}
        <div style={{fontFamily: MONO, fontSize: 8.5, letterSpacing: 1, color: '#6b6b66', marginLeft: 18, whiteSpace: 'nowrap'}}>MÓDULO {num} · {agentes}</div>
        <div style={{flex: 1}}/>
        {Array.from({length: N}).map((_, i) => {
          const fill = (i / N < prog && (i + Math.floor(f / 9)) % 6 !== 0) || i / N < prog - 0.25;
          return <div key={i} style={{width: 9, height: 9, borderRadius: 5, border: `1.6px solid ${fill ? tema.c : C.ink}`, background: fill ? tema.c : 'transparent', boxSizing: 'border-box', marginLeft: 1}}/>;
        })}
        <div style={{width: 10, height: 10, borderRadius: 5, border: `2px solid ${C.ink}`, marginLeft: 6}}/>
      </div>
    </>
  );
};

// cambio de "sub-escena" dentro del panel: entra deslizando desde la derecha y sale hacia la izquierda
export const Slide: React.FC<{f: number; a: number; b: number; first?: boolean; last?: boolean; children: React.ReactNode}> = ({f, a, b, first, last, children}) => {
  const fa = F(a), fb = F(b);
  if (f < fa - 1 || f >= fb + 6) return null;
  const xin = first ? 0 : interpolate(f, [fa - 1, fa + 7], [560, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: (x) => 1 - Math.pow(1 - x, 3)});
  const xout = last ? 0 : interpolate(f, [fb - 1, fb + 6], [0, -560], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: (x) => x * x});
  if (last && f >= fb) return null;
  return <div style={{position: 'absolute', inset: 0, transform: `translateX(${xin + xout}px)`}}>{children}</div>;
};
export {FPS};
