import React from 'react';
import {Img, staticFile, interpolate} from 'remotion';
import {C, F, MONO, SANS, Ico, Tile, Foto, tw, on, typed, FPS, MK, SL, Tema} from './theme';
import {Mod, Slide, H} from './Mod';

const AMBAR: Tema = {c: '#E0A400', bg: '#FFFBEA', soft: '#FFF1BF', mid: '#F5D46A'};

export const MK_HDR: H[] = [
  {t: 23.3, l1: 'TEMA DISPARADO', v1: '+1%', l2: 'EL CEREBRO'},
  {t: 24.6, l1: 'TEMA DISPARADO', v1: '+340%', l2: 'EL CEREBRO'},
  {t: 25.6, l1: 'TEMA DISPARADO', v1: '+340%', l2: 'EL CEREBRO', v2: 'YA LO SABÍA'},
  {t: 26.2, l1: 'FUENTES', v1: '1', l2: 'CEREBRO'},
  {t: 27.6, l1: 'FUENTES', v1: '3', l2: 'CEREBRO'},
  {t: 29.4, l1: 'FUENTES', v1: '3', l2: 'CEREBRO', v2: '1'},
  {t: 30.3, l1: 'LEE', l2: 'DE UN ARCHIVO'},
  {t: 30.9, l1: 'LEE', v1: 'TENDENCIAS', l2: 'DE UN ARCHIVO'},
  {t: 31.85, l1: 'LEE', v1: '+ CLIENTES', l2: 'DE UN ARCHIVO'},
  {t: 32.9, l1: 'ÁNGULOS', v1: '3', l2: 'DE UN ARCHIVO'},
  {t: 34.4, l1: 'ÁNGULOS', v1: '3', l2: 'DE UN ARCHIVO', v2: 'clientes.md'},
  {t: 35.5, l1: 'EL VIDEO', v1: 'ESCRIBIENDO', l2: 'PASO', v2: '1 / 3'},
  {t: 37.1, l1: 'EL VIDEO', v1: 'VISUAL', l2: 'PASO', v2: '2 / 3'},
  {t: 38.6, l1: 'EL VIDEO', v1: 'RENDERIZANDO', l2: 'PASO', v2: '3 / 3'},
  {t: 40.3, l1: 'CANALES PUBLICADOS', v1: '0 / 4', l2: 'A LA HORA EN'},
  {t: 41.0, l1: 'CANALES PUBLICADOS', v1: '0 / 4', l2: 'A LA HORA EN', v2: 'QUE PEGA'},
  {t: 41.7, l1: 'CANALES PUBLICADOS', v1: '1 / 4', l2: 'A LA HORA EN', v2: 'QUE PEGA'},
  {t: 42.4, l1: 'CANALES PUBLICADOS', v1: '2 / 4', l2: 'A LA HORA EN', v2: 'QUE PEGA'},
  {t: 43.1, l1: 'CANALES PUBLICADOS', v1: '3 / 4', l2: 'A LA HORA EN', v2: 'QUE PEGA'},
  {t: 43.8, l1: 'CANALES PUBLICADOS', v1: '4 / 4', l2: 'A LA HORA EN', v2: 'QUE PEGA'},
  {t: 44.7, l1: 'TIEMPO DE RESPUESTA', l2: 'CON TU'},
  {t: 46.9, l1: 'TIEMPO DE RESPUESTA', v1: '0:04', l2: 'CON TU'},
  {t: 47.9, l1: 'TIEMPO DE RESPUESTA', v1: '0:04', l2: 'CON TU', v2: 'VOZ'},
  {t: 50.2, l1: 'EL SISTEMA', v1: 'SE DETIENE', l2: 'EL SÍ FINAL', c1: AMBAR},
  {t: 52.6, l1: 'EL SISTEMA', v1: 'APROBADO', l2: 'EL SÍ FINAL', v2: 'ES TUYO', c1: SL},
  {t: 54.6, l1: 'EL SISTEMA', v1: 'APROBADO', l2: 'INICIOS DE SESIÓN', v2: '0', c1: SL},
];

const Box: React.FC<{x: number; y: number; w: number; h: number; c?: string; bg?: string; r?: number; bw?: number; style?: React.CSSProperties; children?: React.ReactNode}> = ({x, y, w, h, c = C.ink, bg = '#fff', r = 10, bw = 2.5, style, children}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: r, border: `${bw}px solid ${c}`, background: bg, boxSizing: 'border-box', ...style}}>{children}</div>
);
const Mono: React.FC<{x: number; y: number; s?: number; c?: string; w?: number; center?: boolean; children: React.ReactNode; style?: React.CSSProperties}> = ({x, y, s = 8, c = C.ink, w, center, children, style}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, textAlign: center ? 'center' : undefined, fontFamily: MONO, fontSize: s, letterSpacing: 0.6, color: c, whiteSpace: 'pre', ...style}}>{children}</div>
);

// 1) tendencia
const Trend: React.FC<{f: number}> = ({f}) => {
  const draw = tw(f, 23.4, 25.3, 0, 1, 'lin');
  const pts: [number, number][] = [];
  for (let i = 0; i <= 80; i++) {
    const x = i / 80; const spike = x < 0.55 ? 0 : Math.min(1, (x - 0.55) / 0.2);
    pts.push([20 + x * 310, 128 - spike * spike * (3 - 2 * spike) * 88 + Math.sin(i * 0.7) * 3.5 * (1 - spike * 0.5)]);
  }
  const n = Math.max(2, Math.round(pts.length * draw));
  const d = pts.slice(0, n).map((p, i) => `${i ? 'L' : 'M'}${p[0]} ${p[1]}`).join(' ');
  const end = pts[n - 1];
  const src = [['gtrends', 'GOOGLE TRENDS', 93, 26.2], ['semrush', 'SEMRUSH', 275, 27.0], ['sparktoro', 'SPARKTORO', 456, 27.7]] as const;
  const same = on(f, 29.4);
  return <>
    <Box x={23} y={24} w={503} h={165} r={12}>
      <Mono x={14} y={12} s={7.5}>TENDENCIA · "ideas cocina pequeña"</Mono>
      <svg style={{position: 'absolute', left: 0, top: 0}} width="500" height="160">
        {Array.from({length: 11}).map((_, i) => <line key={i} x1={20 + i * 31} y1={30} x2={20 + i * 31} y2={140} stroke="#E4E4E1"/>)}
        {[50, 80, 110, 140].map((y) => <line key={y} x1={20} y1={y} x2={330} y2={y} stroke="#E4E4E1"/>)}
        <path d={d} fill="none" stroke={C.mk} strokeWidth="2.6"/>
        <circle cx={end[0]} cy={end[1]} r="4.5" fill={C.mk} stroke={C.ink} strokeWidth="1.5"/>
        <line x1={end[0]} y1={end[1]} x2={415} y2={end[1]} stroke={C.ink} strokeWidth="1.8" opacity={draw > 0.98 ? 1 : 0}/>
        <rect x="415" y="28" width="8" height="122" rx="4" fill="#fff" stroke={C.ink} strokeWidth="2"/>
      </svg>
      <div style={{position: 'absolute', left: 278, top: 6, opacity: tw(f, 24.5, 24.8), padding: '3px 10px', borderRadius: 10, background: C.mk, color: '#fff', fontFamily: SANS, fontWeight: 800, fontSize: 10}}>{draw > 0.7 ? '+340%' : '+1%'}</div>
      <div style={{position: 'absolute', left: 432, top: 34, width: 56, height: 56, borderRadius: 28, background: C.mkSoft, border: `2.5px solid ${C.mk}`, boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${1 + tw(f, 25.3, 25.5) * 0.1 - tw(f, 25.5, 25.8) * 0.1})`}}><Tile n="claude" s={30}/></div>
      <Mono x={412} y={96} s={6.5} c={C.mk} w={96} center>YA LO SABE</Mono>
    </Box>
    <svg style={{position: 'absolute', left: 0, top: 0}} width="551" height="501">
      {src.map(([_, __, x, t], i) => {
        const p = tw(f, t + 0.1, t + 0.9, 0, 1, 'lin');
        const path = i === 1 ? `M${x} 262 V400` : `M${x} 262 V330 L${i === 0 ? 248 : 302} 368 V400`;
        return <g key={i}>
          <path d={path} fill="none" stroke="#D8D8D5" strokeWidth="9"/>
          <path d={path} fill="none" stroke={C.ink} strokeWidth="10" strokeDasharray="400" strokeDashoffset={400 * (1 - p)} opacity={p > 0 ? 1 : 0}/>
          <path d={path} fill="none" stroke={C.mk} strokeWidth="6.5" strokeDasharray="400" strokeDashoffset={400 * (1 - p)} opacity={p > 0 ? 1 : 0}/>
        </g>;
      })}
    </svg>
    {src.map(([l, name, x, t]) => {
      const a = on(f, t);
      return <div key={name} style={{position: 'absolute', left: x - 24, top: 196, width: 48, textAlign: 'center', opacity: a ? 1 : 0.38}}>
        <svg width="30" height="12" viewBox="0 0 30 12"><path d="M5 11 a12 9 0 0 1 20 0" fill="none" stroke={a ? C.mk : '#bbb'} strokeWidth="1.6"/><path d="M10 11 a6 5 0 0 1 10 0" fill="none" stroke={a ? C.mk : '#bbb'} strokeWidth="1.6"/></svg>
        <div style={{margin: '0 auto', width: 42, height: 42, borderRadius: 9, border: `2px solid ${a ? C.mk : '#aaa'}`, background: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Ico n={l} s={30}/></div>
        <Mono x={-26} y={60} s={6} w={100} center>{name}</Mono>
      </div>;
    })}
    <Box x={181} y={400} w={188} h={77} r={12} bg={same ? C.mkSoft : '#fff'} c={same ? C.mk : C.ink}>
      <div style={{position: 'absolute', left: 14, top: 19}}><Tile n="claude" s={36}/></div>
      <Mono x={66} y={22} s={11.5} style={{fontWeight: 700}}>{same ? 'MISMO CEREBRO' : 'UN CEREBRO'}</Mono>
      <Mono x={66} y={42} s={6.5} c="#666">3 FUENTES · 1 LECTURA</Mono>
    </Box>
  </>;
};

// 2) lector de tarjetas
const Reader: React.FC<{f: number}> = ({f}) => {
  const cols = ['PEQUEÑA', 'LUJO', 'ECONÓMICA', 'DIY', '3 SEMANAS', 'ABIERTA'];
  const up = tw(f, 31.8, 32.4);
  const match = [0, 2, 4];
  return <>
    <Box x={49} y={104} w={452} h={207} r={12}>
      <Mono x={16} y={14} s={7.5}>LECTOR DE TARJETAS</Mono>
      <div style={{position: 'absolute', left: 22, top: 38, width: 403, height: 58, borderRadius: 8, border: `2px solid ${C.mk}`, background: C.mkSoft, opacity: tw(f, 30.7, 31.1), transform: `translateY(${(1 - tw(f, 30.7, 31.1)) * -20}px)`}}>
        <Mono x={10} y={6} s={6.2} c={C.mk}>TENDENCIAS DE LA SEMANA · google-trends + semrush</Mono>
        {cols.map((_, i) => <div key={i} style={{position: 'absolute', left: 22 + i * 62.5, top: 22, width: 30, height: 23, borderRadius: 6, border: `2px ${i === 1 || i === 5 ? 'dashed' : 'solid'} ${i === 1 || i === 5 ? C.mk : C.ink}`, background: '#fff', boxSizing: 'border-box'}}/>)}
      </div>
      {cols.map((c, i) => <React.Fragment key={c}>
        <div style={{position: 'absolute', left: 57 + i * 62.5, top: 98, width: 18, height: 18, borderRadius: 9, border: '1.5px solid #ccc', background: match.includes(i) && on(f, 33.0 + match.indexOf(i) * 0.15) ? C.mk : '#fff', boxSizing: 'border-box'}}/>
        <Mono x={36 + i * 62.5} y={188} s={6} w={60} center c={match.includes(i) && on(f, 33) ? C.mk : C.ink}>{c}</Mono>
      </React.Fragment>)}
    </Box>
    <div style={{position: 'absolute', left: 75 - up * 2, top: 381 - up * 165, width: 400 + up * 2, height: 58, borderRadius: 8, border: `2.5px solid ${C.ink}`, background: '#fff', boxSizing: 'border-box'}}>
      <Mono x={10} y={6} s={6.2}>clientes.md · LO QUE LE IMPORTA A TUS CLIENTES</Mono>
      {cols.map((_, i) => <div key={i} style={{position: 'absolute', left: 28 + i * 62.5, top: 22, width: 30, height: 23, borderRadius: 6, border: `2px ${i === 3 || i === 5 ? 'dashed' : 'solid'} ${C.ink}`, background: '#fff', boxSizing: 'border-box'}}/>)}
      {on(f, 32.4) && <div style={{position: 'absolute', right: 14, top: -10}}><Tile n="gdrive" s={22}/></div>}
    </div>
    <div style={{position: 'absolute', left: 322, top: 332, transform: `rotate(-6deg) scale(${tw(f, 34.4, 34.6, 1.6, 1)})`, opacity: tw(f, 34.4, 34.55), padding: '4px 14px', border: `2px solid ${C.mk}`, borderRadius: 6, background: C.mkSoft, fontFamily: MONO, fontWeight: 700, fontSize: 10, color: C.mk, letterSpacing: 1}}>ESCRITO UNA VEZ</div>
    {['ESPACIO PEQUEÑO', 'MENOS DE $8K', 'INSTALACIÓN EN 3 SEM.'].map((t, i) => (
      <div key={t} style={{position: 'absolute', left: 62 + i * 146, top: 412, width: 132, height: 32, borderRadius: 16, border: `2.5px solid ${C.mk}`, background: C.mkSoft, boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: MONO, fontWeight: 700, fontSize: 7.6, color: C.ink, opacity: tw(f, 33.1 + i * 0.25, 33.35 + i * 0.25), transform: `translateY(${(1 - tw(f, 33.1 + i * 0.25, 33.4 + i * 0.25)) * 14}px)`}}>{t}</div>
    ))}
    <Mono x={0} y={464} s={6.5} w={551} center c="#777" style={{opacity: tw(f, 33.8, 34.1)}}>3 ÁNGULOS PARA ESTA SEMANA</Mono>
  </>;
};

// 3) el video: 3 máquinas
const Short: React.FC<{f: number}> = ({f}) => {
  const st = on(f, 38.6) ? 2 : on(f, 37.1) ? 1 : 0;
  const txt = '¿Cocina pequeña?\n3 diseños que caben\nen 6 m², instalados\nen 3 semanas.';
  const tp = tw(f, 35.7, 36.9, 0, 1, 'lin');
  const pieces = Math.round(tw(f, 37.2, 38.3, 0, 9, 'lin'));
  const rend = tw(f, 38.7, 40.1, 0, 89, 'lin');
  const cards = [['claude', 'PASO 1', 'ESCRIBE EL POST'], ['higgsfield', 'PASO 2', 'CREA EL VISUAL'], ['remotion', 'PASO 3', 'RENDERIZA EL VIDEO']];
  const beltX = tw(f, 35.6, 40.2, 0, 1, 'lin');
  return <>
    {cards.map(([l, a, b], i) => {
      const act = i <= st;
      return <Box key={i} x={18 + i * 175} y={35} w={163} h={295} c={act ? C.mk : '#E7C9B8'} bg={act ? C.mkBg : '#FDF8F5'} r={12} style={{opacity: act ? 1 : 0.6}}>
        <div style={{position: 'absolute', left: 10, top: 10}}><Tile n={l} s={28} fill={l === 'higgsfield' ? C.lime : '#fff'}/></div>
        <Mono x={46} y={12} s={6.5}>{a}</Mono><Mono x={46} y={24} s={6.5}>{b}</Mono>
        <Box x={13} y={62} w={137} h={218} r={8}>
          {i === 0 && <>
            <div style={{position: 'absolute', left: 8, top: 10, display: 'flex', alignItems: 'center', gap: 5}}><Foto src="img/tu-foto.png" s={18}/><span style={{fontFamily: MONO, fontSize: 6}}>tu cocina co.</span></div>
            <div style={{position: 'absolute', left: 10, top: 40, width: 120, fontFamily: SANS, fontWeight: 600, fontSize: 10.5, lineHeight: '15px', whiteSpace: 'pre-wrap', color: C.ink}}>{typed(txt, tp)}<span style={{opacity: tp < 1 && Math.floor(f / 8) % 2 ? 1 : 0, color: C.mk}}>▍</span></div>
            <Mono x={0} y={195} s={6} w={137} center c="#777">{Math.round(tp * 13)} / 13 TOKENS</Mono>
          </>}
          {i === 1 && act && <>
            <div style={{position: 'absolute', left: 8, top: 8, width: 121, height: 178, display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gridTemplateRows: 'repeat(3,1fr)', gap: 2}}>
              {Array.from({length: 9}).map((_, k) => <div key={k} style={{overflow: 'hidden', position: 'relative', opacity: k < pieces ? 1 : 0.08, background: '#eee'}}>
                <Img src={staticFile('img/cocina.jpg')} style={{position: 'absolute', width: 121, height: 178, objectFit: 'cover', left: -(k % 3) * 41, top: -Math.floor(k / 3) * 60}}/>
              </div>)}
            </div>
            <Mono x={0} y={195} s={6} w={137} center c="#777">{pieces} / 9 PIEZAS</Mono>
          </>}
          {i === 2 && act && <>
            <div style={{position: 'absolute', left: 14, top: 10, width: 109, height: 150, borderRadius: 6, overflow: 'hidden'}}>
              <Img src={staticFile('img/cocina.jpg')} style={{width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${1 + rend / 400})`}}/>
            </div>
            <div style={{position: 'absolute', left: 14, top: 168, width: 109, height: 7, borderRadius: 4, border: `1.5px solid ${C.ink}`, boxSizing: 'border-box'}}><div style={{width: `${rend / 0.89}%`, height: '100%', background: C.mk, borderRadius: 3}}/></div>
            <Mono x={0} y={195} s={6} w={137} center c="#777">{Math.round(rend)}% RENDERIZADO</Mono>
          </>}
        </Box>
      </Box>;
    })}
    <div style={{position: 'absolute', left: 18, top: 355, width: 514, height: 20, borderRadius: 10, border: `2.5px solid ${C.ink}`, boxSizing: 'border-box', background: '#fff'}}>
      {Array.from({length: 12}).map((_, i) => <div key={i} style={{position: 'absolute', left: 10 + ((i * 43 - beltX * 43 * 3) % 516 + 516) % 516, top: 2.5, width: 11, height: 11, borderRadius: 6, border: `2px solid ${C.ink}`, boxSizing: 'border-box'}}/>)}
    </div>
    <div style={{position: 'absolute', left: 30 + beltX * 380, top: 383, padding: '6px 14px', borderRadius: 6, border: `2.5px solid ${C.mk}`, background: C.mkSoft, fontFamily: MONO, fontWeight: 700, fontSize: 7.5}}>EL POST</div>
    <Mono x={0} y={450} s={6.5} w={551} center c="#777">UNA IDEA · TRES MÁQUINAS · CERO EDITOR</Mono>
  </>;
};

// 4) relojes de arena
const Hourglass: React.FC<{f: number}> = ({f}) => {
  const ch = [['instagram', '18:00', 43.0], ['tiktok', '21:00', 43.8], ['linkedin', '08:00', 41.7], ['youtube', '17:00', 42.4]] as const;
  return <>
    {ch.map(([l, h, t], i) => {
      const x = 62 + i * 142, p = tw(f, 40.3, t, 0, 1, 'lin'), done = on(f, t);
      return <React.Fragment key={l}>
        <div style={{position: 'absolute', left: x - 22, top: 32}}><Tile n={l} s={44}/>{done && <div style={{position: 'absolute', right: -7, top: -7, width: 16, height: 16, borderRadius: 8, background: C.sl, color: '#fff', fontSize: 10, fontWeight: 900, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${tw(f, t, t + 0.2)})`}}>✓</div>}</div>
        <Mono x={x - 40} y={84} s={11} w={80} center style={{fontWeight: 700}}>{h}</Mono>
        <svg style={{position: 'absolute', left: x - 40, top: 130}} width="80" height="160" viewBox="0 0 80 160">
          <rect x="4" y="2" width="72" height="8" rx="3" fill="#fff" stroke={C.ink} strokeWidth="2"/>
          <rect x="4" y="142" width="72" height="8" rx="3" fill="#fff" stroke={C.ink} strokeWidth="2"/>
          <path d={`M${40 - 27 * (1 - p)} ${12 + 60 * p} L${40 + 27 * (1 - p)} ${12 + 60 * p} L40 74 Z`} fill={C.mkMid} opacity={1 - p * 0.98}/>
          <path d={`M${40 - 30 * Math.sqrt(p)} 140 L${40 + 30 * Math.sqrt(p)} 140 L40 ${140 - 64 * Math.sqrt(p)} Z`} fill={C.mkMid}/>
          {!done && p > 0 && <line x1="40" y1="74" x2="40" y2="140" stroke={C.mkMid} strokeWidth="1.5"/>}
          <path d="M10 12 L70 12 L40 76 L70 140 L10 140 L40 76 Z" fill="none" stroke={C.ink} strokeWidth="2"/>
        </svg>
        <Box x={x - 44} y={292} w={88} h={50} r={6} c={done ? C.mk : C.ink} bg={done ? '#fff' : '#fff'}>
          <div style={{position: 'absolute', left: 6, top: done ? 4 : -14, width: 72, height: 30, borderRadius: 4, border: `2px solid ${C.ink}`, background: C.mkSoft, boxSizing: 'border-box', transition: 'none'}}/>
          <Mono x={0} y={36} s={5.6} w={84} center c={done ? C.mk : '#777'}>{done ? 'PUBLICADO' : 'ESPERANDO'}</Mono>
        </Box>
      </React.Fragment>;
    })}
    <Box x={143} y={412} w={264} h={60} r={12} c={C.mk} bg={C.mkBg}>
      <div style={{position: 'absolute', left: 14, top: 13}}><Tile n="metricool" s={30} fill={C.lime}/></div>
      <Mono x={60} y={15} s={10} style={{fontWeight: 700}}>METRICOOL</Mono>
      <Mono x={60} y={32} s={6}>PUBLICA CUANDO CADA UNO PEGA</Mono>
    </Box>
  </>;
};

// 5) péndulo de Newton
const Cradle: React.FC<{f: number}> = ({f}) => {
  const t = f / FPS;
  const r0 = F(45.0) / FPS;
  const ph = Math.max(0, t - r0);
  // golpe cada 1.6 s: izquierda sube y baja, derecha sale
  const cyc = ph % 1.6;
  const L = ph > 0 ? (cyc < 0.8 ? -Math.sin((cyc / 0.8) * Math.PI) * 0.55 : 0) : -0.45;
  const Rr = ph > 0 && cyc >= 0.8 ? Math.sin(((cyc - 0.8) / 0.8) * Math.PI) * 0.55 : 0;
  const balls = [['DM', C.blue], ['voz.md', null], ['manychat', null], ['faq.md', null], ['RESPUESTA', C.mk]] as const;
  const xs = [164, 219, 275, 330, 386], PY = 42, LEN = 172;
  const reply = on(f, 46.7);
  return <>
    <svg style={{position: 'absolute', left: 0, top: 0}} width="551" height="501">
      <rect x="93" y="28" width="364" height="12" rx="5" fill="#fff" stroke={C.ink} strokeWidth="2.2"/>
      <line x1="105" y1="40" x2="105" y2="269" stroke={C.ink} strokeWidth="2.2"/><line x1="445" y1="40" x2="445" y2="269" stroke={C.ink} strokeWidth="2.2"/>
      <rect x="80" y="266" width="390" height="10" rx="4" fill="#fff" stroke={C.ink} strokeWidth="2.2"/>
      {xs.map((x, i) => { const a = i === 0 ? L : i === 4 ? Rr : 0; const bx = x + Math.sin(a) * LEN, by = PY + Math.cos(a) * LEN; return <line key={i} x1={x} y1={PY} x2={bx} y2={by} stroke={C.ink} strokeWidth="1.4"/>; })}
    </svg>
    {balls.map(([l, c], i) => {
      const a = i === 0 ? L : i === 4 ? Rr : 0; const bx = xs[i] + Math.sin(a) * LEN, by = PY + Math.cos(a) * LEN;
      return <div key={i} style={{position: 'absolute', left: bx - 27, top: by - 27, width: 54, height: 54, borderRadius: 27, border: `2.5px solid ${c || C.ink}`, background: c === C.blue ? '#CFE3FF' : c ? C.mkSoft : '#fff', boxSizing: 'border-box', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: MONO, fontWeight: 700, fontSize: l.length > 6 ? 6.2 : 8, color: C.ink}}>
        {l === 'manychat' ? <Tile n="manychat" s={28}/> : l}
      </div>;
    })}
    <Box x={18} y={314} w={263} h={168} r={12}>
      <div style={{position: 'absolute', left: 10, top: 9, display: 'flex', alignItems: 'center', gap: 7}}><Foto src="img/maria.jpg" s={24}/><span style={{fontFamily: MONO, fontWeight: 700, fontSize: 7.5}}>Instagram DM</span></div>
      <div style={{position: 'absolute', right: 10, top: 10}}><Tile n="instagram" s={22}/></div>
      <div style={{position: 'absolute', left: 12, top: 46, padding: '7px 10px', borderRadius: 9, background: '#F1F1EE', fontFamily: SANS, fontSize: 9, opacity: tw(f, 44.9, 45.2)}}>¿Hacen cocinas pequeñas?</div>
      {reply && <div style={{position: 'absolute', left: 40, top: 84, width: 200, padding: '7px 10px', borderRadius: 9, border: `2px solid ${C.mk}`, background: C.mkSoft, boxSizing: 'border-box', fontFamily: SANS, fontSize: 8.6, lineHeight: '12px', transform: `scale(${tw(f, 46.7, 46.95, 0.7, 1)})`, transformOrigin: 'right top'}}>{typed('¡Sí! Desde 6 m², instaladas en 3 semanas. ¿Te mando 3 diseños?', tw(f, 46.75, 47.6, 0, 1, 'lin'))}</div>}
      {reply && <Mono x={0} y={146} s={5.8} w={250} c={C.sl} style={{textAlign: 'right'}}>ENVIADO 0:04 · CON TU VOZ</Mono>}
    </Box>
    <div style={{position: 'absolute', left: 374, top: 309, width: 96, height: 210, borderRadius: 16, background: '#141414', border: '3px solid #444', boxSizing: 'border-box'}}>
      <div style={{position: 'absolute', left: 30, top: 6, width: 30, height: 8, borderRadius: 4, background: '#000'}}/>
      <div style={{position: 'absolute', left: 0, right: 0, top: 30, textAlign: 'center', fontFamily: SANS, fontWeight: 700, fontSize: 18, color: '#fff'}}>9:41</div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 64, textAlign: 'center', fontSize: 18, color: '#fff'}}>🔒</div>
      <Mono x={0} y={96} s={5.5} w={90} center c="#ccc">BLOQUEADO</Mono>
      <Mono x={0} y={124} s={5.5} w={90} center c="#FF4D6D">APP SIN ABRIR</Mono>
    </div>
  </>;
};

// 6) interruptor + tu sí
const Breaker: React.FC<{f: number}> = ({f}) => {
  const yes = on(f, 52.6);
  const lev = tw(f, 52.6, 52.9);
  const ang = 35 - lev * 70; // de abajo (stop) a arriba (run)
  const col = yes ? C.sl : AMBAR.c;
  return <>
    <Box x={24} y={29} w={214} h={270} r={12} c={yes ? C.ink : AMBAR.c}>
      <Mono x={16} y={16} s={7.5} style={{fontWeight: 700}}>INTERRUPTOR PRINCIPAL</Mono>
      <Mono x={0} y={44} s={6.5} w={210} center c={C.sl}>CORRE</Mono>
      <div style={{position: 'absolute', left: 68, top: 58, width: 74, height: 156, borderRadius: 8, border: `2.5px solid ${C.ink}`, background: '#F3F3F0', boxSizing: 'border-box'}}/>
      <div style={{position: 'absolute', left: 103, top: 136, width: 1, height: 1, transform: `rotate(${ang}deg)`}}>
        <div style={{position: 'absolute', left: -6, top: -62, width: 12, height: 66, borderRadius: 6, border: `2.5px solid ${C.ink}`, background: '#fff', boxSizing: 'border-box'}}/>
        <div style={{position: 'absolute', left: -20, top: -80, width: 40, height: 22, borderRadius: 7, border: `2.5px solid ${C.ink}`, background: col, boxSizing: 'border-box'}}/>
        <div style={{position: 'absolute', left: -10, top: -10, width: 20, height: 20, borderRadius: 10, border: `2.5px solid ${C.ink}`, background: '#fff', boxSizing: 'border-box'}}/>
      </div>
      <Mono x={0} y={222} s={6.5} w={210} center c="#777">PARA</Mono>
      <Mono x={0} y={244} s={7} w={210} center c={col} style={{fontWeight: 700}}>{yes ? 'CORRIENDO' : 'ESPERANDO TU SÍ'}</Mono>
    </Box>
    <div style={{position: 'absolute', left: 336, top: 25, width: 134, height: 276, borderRadius: 22, border: `3px solid ${C.ink}`, background: '#EDEDEA', boxSizing: 'border-box'}}>
      <div style={{position: 'absolute', left: 44, top: 8, width: 40, height: 10, borderRadius: 5, background: C.ink}}/>
      {on(f, 51.0) && <div style={{position: 'absolute', left: 7, top: 42, width: 114, borderRadius: 8, background: '#fff', border: '1.5px solid #ccc', padding: 6, boxSizing: 'border-box', transform: `translateY(${(1 - tw(f, 51.0, 51.3)) * -30}px)`, opacity: tw(f, 51.0, 51.2)}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 4, fontFamily: SANS, fontWeight: 700, fontSize: 7}}><Ico n="slack" s={13} bare/>Post listo</div>
        <Img src={staticFile('img/cocina.jpg')} style={{width: '100%', height: 54, objectFit: 'cover', borderRadius: 4, marginTop: 5}}/>
        <div style={{fontFamily: SANS, fontSize: 6, marginTop: 4}}>¿Cocina pequeña? 3 diseños…</div>
        <div style={{display: 'flex', gap: 5, marginTop: 6}}>
          <div style={{flex: 1, height: 18, borderRadius: 4, background: C.sl, color: '#fff', fontFamily: SANS, fontWeight: 800, fontSize: 7.5, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${yes ? 1 - Math.max(0, 0.12 - Math.abs(f - F(52.6)) * 0.02) : 1})`, boxShadow: yes ? `0 0 0 3px ${C.slSoft}` : undefined}}>SÍ</div>
          <div style={{flex: 1, height: 18, borderRadius: 4, border: `1.5px solid ${C.ink}`, fontFamily: SANS, fontWeight: 700, fontSize: 7, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>EDITAR</div>
        </div>
      </div>}
    </div>
    {on(f, 54.6) && <div style={{position: 'absolute', left: 250, top: 150, padding: '4px 9px', borderRadius: 8, border: `2px solid ${C.sl}`, background: C.slSoft, fontFamily: MONO, fontSize: 7, color: C.sl, fontWeight: 700, transform: `scale(${tw(f, 54.6, 54.8)})`}}>0 INICIOS</div>}
    <Box x={24} y={330} w={502} h={156} r={12}>
      <Mono x={16} y={16} s={7}>LA LÍNEA DE MARKETING</Mono>
      <svg style={{position: 'absolute', left: 0, top: 0}} width="500" height="150">
        {[[78, 160], [182, 294], [318, 412]].map(([a, b], i) => <g key={i}>
          <line x1={a} y1={80} x2={b} y2={80} stroke={i === 2 && !yes ? '#cfcfcf' : C.mk} strokeWidth="3"/>
          <circle cx={(a + b) / 2 + 20} cy={80} r="4.5" fill="#fff" stroke={C.ink} strokeWidth="1.5"/>
          {yes && <circle cx={a + ((f / FPS * 0.9 + i * 0.3) % 1) * (b - a)} cy={80} r="3" fill={C.mk}/>}
        </g>)}
      </svg>
      {[['claude', 38], ['higgsfield', 160], ['remotion', 296], ['metricool', 414]].map(([l, x]) => <div key={l as string} style={{position: 'absolute', left: x as number, top: 59}}><Tile n={l as string} s={42} fill={l === 'higgsfield' || l === 'metricool' ? C.lime : '#fff'}/></div>)}
      <Mono x={0} y={118} s={7} w={500} center c={col} style={{fontWeight: 700}}>{yes ? 'APROBADO · PUBLICANDO' : 'EN PAUSA · ESPERANDO TU SÍ'}</Mono>
    </Box>
  </>;
};

export const Marketing: React.FC<{f: number}> = ({f}) => (
  <Mod f={f} tema={MK} num="01" nombre="MARKETING" agentes="28 AGENTES" logos={['gtrends', 'claude', 'higgsfield', 'metricool']} hdr={MK_HDR} t0={23.3} t1={55.4}>
    <Slide f={f} a={23.3} b={30.3} first><Trend f={f}/></Slide>
    <Slide f={f} a={30.3} b={35.4}><Reader f={f}/></Slide>
    <Slide f={f} a={35.4} b={40.3}><Short f={f}/></Slide>
    <Slide f={f} a={40.3} b={44.65}><Hourglass f={f}/></Slide>
    <Slide f={f} a={44.65} b={50.2}><Cradle f={f}/></Slide>
    <Slide f={f} a={50.2} b={55.4} last><Breaker f={f}/></Slide>
  </Mod>
);
