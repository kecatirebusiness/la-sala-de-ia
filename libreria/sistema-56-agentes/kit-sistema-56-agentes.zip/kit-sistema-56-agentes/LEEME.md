# Kit · Sistema de 56 agentes (empresa de una persona)

Qué hay aquí:
- CLAUDE.md → las instrucciones del orquestador. Pon esta carpeta como tu proyecto y abre Claude Code dentro.
- conocimiento/ → los archivos que lee TODO el sistema. Rellénalos (o pídele a Claude que te entreviste: prompts/01-archivos.md).
- prompts/ → un prompt por paso, en el mismo orden que la página de la librería.
- mapa-56-agentes.md → los 56 agentes con sus herramientas. Marca con [x] los que vas a montar primero.
- borradores/ → aquí deja Claude todo lo que espera tu sí.

Orden recomendado (un fin de semana):
1. conocimiento/ (1 hora)
2. Conectar herramientas por MCP (prompts/02-conectar.md)
3. Marketing: investigación + contenido (prompts/03-marketing.md)
4. Ventas: bandeja única + calificación (prompts/04-ventas.md)
5. Orquestador: ciclo semanal + resumen diario (prompts/05-orquestador.md)
6. Ponlo en automático (prompts/06-automatico.md)

Montado juntos, paso a paso, en La Sala de IA: https://lasaladeia.com
