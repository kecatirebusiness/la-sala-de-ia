# Kit · Sistema de 56 agentes (La Sala de IA)

1. `npm i` (Remotion 4) y pon en `public/`: `voz.wav` (tu voz en off) e `img/tu-foto.png` (tu foto cuadrada).
2. Los tiempos de cada frase están en `src/tiempos.json` (los genera `scripts/coloca.py` a partir de la voz con tiempos de ElevenLabs).
3. `npx remotion studio src/index.ts` para verlo, `npx remotion render src/index.ts Edit out/video.mp4` para exportar.
4. Scripts: `guion.py` (frases + segundo de la referencia), `vo.py` (voz con ElevenLabs, lee tu key de ~/.config/elevenlabs/key), `corta.py` y `coloca.py` (arman la pista y los tiempos), `sep.py` (separa la música de una referencia con Demucs).
