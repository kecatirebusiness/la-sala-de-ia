# Mis clientes

Quién me compra:
Qué le importa:
Objeciones típicas (y cómo respondo):
Palabras que usa para describir su problema:
