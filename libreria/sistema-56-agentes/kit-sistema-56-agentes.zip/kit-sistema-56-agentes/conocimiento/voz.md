# Mi voz

Tono:
Frases que uso:
Palabras que NUNCA uso:
Cómo saludo / cómo cierro:
Mis 3 mejores posts (pégalos):
