# Reglas: qué hace el sistema solo y qué necesita mi sí

## Lo hace solo
- Investigar tendencias y escribir borradores
- Responder DMs y comentarios normales con mi voz
- Mandar el link de Calendly a leads con 80+
- Confirmaciones y recordatorios de citas

## Necesita mi sí (me avisa por Slack)
- Publicar cualquier post
- Un dato o una cifra delicada en un post
- Un comentario o DM molesto
- Lead caliente que pide llamada
- Cotización de más de $[MONTO] o con descuento
- Un depósito que falla
- Alguien que escribe STOP
- El gasto en anuncios llega a $[TOPE] al día
