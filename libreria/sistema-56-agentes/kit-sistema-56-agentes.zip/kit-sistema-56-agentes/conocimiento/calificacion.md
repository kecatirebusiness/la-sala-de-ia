# Calificación de leads (0-100)

Suma:
Resta:
80+ → ficha por Slack + link de Calendly
50-79 → nutrición de 3 mensajes
<50 → respuesta amable y cierre
