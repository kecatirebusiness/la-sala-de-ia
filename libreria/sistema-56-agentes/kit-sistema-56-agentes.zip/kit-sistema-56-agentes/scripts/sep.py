import torch, wave, numpy as np
from demucs.pretrained import get_model
from demucs.apply import apply_model
w=wave.open('ref_st.wav'); sr=w.getframerate()
a=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).reshape(-1,2).T.astype(np.float32)/32768
m=get_model('htdemucs'); m.eval()
with torch.no_grad(): out=apply_model(m,torch.from_numpy(a)[None],device='cpu',shifts=1,split=True,overlap=0.25)[0]
nv=None
for name,s in zip(m.sources,out):
    s=s.numpy(); print(name, round(float(20*np.log10(np.sqrt((s**2).mean())+1e-9)),1),'dB')
    if name!='vocals': nv=s if nv is None else nv+s
    d=(s.T*32767).clip(-32768,32767).astype(np.int16)
    f=wave.open(f'musica/{name}.wav','wb'); f.setnchannels(2); f.setsampwidth(2); f.setframerate(sr); f.writeframes(d.tobytes()); f.close()
d=(nv.T*32767).clip(-32768,32767).astype(np.int16)
f=wave.open('musica/no_vocals.wav','wb'); f.setnchannels(2); f.setsampwidth(2); f.setframerate(sr); f.writeframes(d.tobytes()); f.close()
