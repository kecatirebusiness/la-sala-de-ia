import json, base64, os, sys, urllib.request
sys.path.insert(0,'.'); from guion import G
K=open(os.path.expanduser('~/.config/elevenlabs/key')).read().strip()
V='7mnM0bDMmkYHowjZiDNa'
for i,g in enumerate(G):
    if os.path.exists(f'vo/g{i}.json') and '--force' not in sys.argv: continue
    text=' '.join(t for _,t in g)
    body={'text':text,'model_id':'eleven_v4','language_code':'es','voice_settings':{'stability':0.5,'similarity_boost':0.8,'speed':1.15}}
    if i>0: body['previous_text']=' '.join(t for _,t in G[i-1])
    req=urllib.request.Request(f'https://api.elevenlabs.io/v1/text-to-speech/{V}/with-timestamps?output_format=mp3_44100_192',data=json.dumps(body).encode(),headers={'xi-api-key':K,'Content-Type':'application/json'})
    try: r=json.load(urllib.request.urlopen(req))
    except urllib.error.HTTPError as e: print(i,e.read()[:400]); sys.exit(1)
    open(f'vo/g{i}.mp3','wb').write(base64.b64decode(r['audio_base64']))
    json.dump(r['alignment'],open(f'vo/g{i}.json','w'),ensure_ascii=False)
    print(i,'ok',r['alignment']['character_end_times_seconds'][-1])
