# divide cada grupo en frases usando la alineación por caracteres -> lista de (anchor, texto, archivo, t0, t1, palabras)
import json, sys
sys.path.insert(0,'.'); from guion import G
out=[]
for i,g in enumerate(G):
    a=json.load(open(f'vo/g{i}.json')); ch=a['characters']; st=a['character_start_times_seconds']; en=a['character_end_times_seconds']
    text=''.join(ch); pos=0
    for anc,t in g:
        k=text.find(t,pos); assert k>=0,(i,t); e=k+len(t); pos=e
        # palabras
        words=[]; j=k
        while j<e:
            while j<e and ch[j]==' ': j+=1
            s=j
            while j<e and ch[j]!=' ': j+=1
            if s<j: words.append((''.join(ch[s:j]),st[s],en[j-1]))
        out.append(dict(anc=anc,text=t,g=i,t0=words[0][1],t1=words[-1][2],words=words))
json.dump(out,open('vo/frases.json','w'),ensure_ascii=False,indent=0)
for o,n in zip(out,out[1:]+[None]):
    slot=(n['anc'] if n else 116)-o['anc']; d=o['t1']-o['t0']
    print(f"{o['anc']:6.2f} dur {d:5.2f} slot {slot:5.2f} ratio {d/slot:4.2f}  {o['text'][:50]}")
