# coloca frases seguidas, comprime pausas internas (ritmo kecatire: sin pausas de "pensando")
import json, wave, numpy as np
fr=json.load(open('vo/frases.json'))
SR=48000; G={i:np.frombuffer(wave.open(f'vo/g{i}.wav').readframes(10**9),dtype=np.int16).astype(np.float32)/32768 for i in range(7)}
SECC={20.34:0.45,56.22:0.45,82.20:0.45,112.58:0.4}   # pausas un poco más largas al cambiar de bloque
def fade(a,ms=8):
    n=min(len(a)//2,int(ms/1000*SR)); a[:n]*=np.linspace(0,1,n); a[-n:]*=np.linspace(1,0,n); return a
out=np.zeros(SR*200,np.float32); t=0.15; res=[]
for k,f in enumerate(fr):
    if k>0: t+=SECC.get(f['anc'],0.16)
    g=G[f['g']]; ws=f['words']; pieces=[]; cur=t; wt=[]
    # agrupa palabras en tramos sin pausa >0.12
    spans=[[ws[0][1],ws[0][2],[ws[0]]]]
    for w in ws[1:]:
        if w[1]-spans[-1][1]>0.12: spans.append([w[1],w[2],[w]])
        else: spans[-1][1]=w[2]; spans[-1][2].append(w)
    for j,(a0,b0,wl) in enumerate(spans):
        pre=0.03 if j==0 else 0.02
        a=fade(g[max(0,int((a0-pre)*SR)):int((b0+0.06)*SR)].copy())
        s=int(cur*SR); out[s:s+len(a)]+=a
        off=cur+pre-a0
        wt+= [(w,round(x+off,3),round(y+off,3)) for w,x,y in wl]
        gap=0.14 if wl[-1][0][-1] in ',.' else 0.06
        cur=cur+pre+(b0-a0)+gap
    end=wt[-1][2]
    res.append(dict(anc=f['anc'],start=wt[0][1],end=end,text=f['text'],words=wt))
    t=end
tot=t+1.2; out=out[:int(tot*SR)]
w=wave.open('vo/voz.wav','wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((np.clip(out,-1,1)*32767).astype(np.int16).tobytes()); w.close()
json.dump(dict(total=round(tot,3),frases=res),open('vo/tiempos.json','w'),ensure_ascii=False)
print('total',round(tot,2))
