import json,sys
d=json.load(open('vo/tiempos_final.json')); A=[(f['anc'],f['start']) for f in d['frases']]
def R(t):
    if t<=A[0][0]: return t+(A[0][1]-A[0][0])
    for (a0,b0),(a1,b1) in zip(A,A[1:]):
        if t<a1: return b0+(t-a0)/(a1-a0)*(b1-b0)
    return A[-1][1]+(t-A[-1][0])
print(' '.join(str(round(R(float(t))*30)) for t in sys.argv[1:]))
