# Los 5 plugins

| Plugin | Qué hace | ¿Oficial? | Instalar | Quitar |
|---|---|---|---|---|
| Claude Code Setup | Revisa tu proyecto y recomienda herramientas (no toca archivos) | Sí, Anthropic | /plugin install claude-code-setup@claude-plugins-official | /plugin uninstall claude-code-setup@claude-plugins-official |
| Superpowers | Preguntas, plan y revisión antes de programar | Comunidad (Jesse Vincent), en el marketplace oficial | /plugin install superpowers@claude-plugins-official | /plugin uninstall superpowers@claude-plugins-official |
| Frontend Design | Páginas con personalidad, no genéricas | Sí, Anthropic | /plugin install frontend-design@claude-plugins-official | /plugin uninstall frontend-design@claude-plugins-official |
| Caveman | Respuestas cortas y al grano | Comunidad | /plugin marketplace add JuliusBrussee/caveman y /plugin install caveman@caveman | /plugin uninstall caveman@caveman |
| Claude Security | Busca huecos de seguridad y propone parches (beta) | Sí, Anthropic | /plugin install claude-security@claude-plugins-official | /plugin uninstall claude-security@claude-plugins-official |

Después de instalar o quitar: /reload-plugins. También puedes manejarlos desde el menú /plugin.
