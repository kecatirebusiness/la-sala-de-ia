# 02 · 2 · Superpowers

Claude deja de lanzarse a programar a ciegas. Primero te hace preguntas, después escribe un plan y revisa cada parte antes de seguir. Ideal cuando le pides algo grande y vago.

## Comando

```
/plugin install superpowers@claude-plugins-official
```

## Prompt para Claude Code: construir con método

```
Quiero construir esto: [TU IDEA, ej. una app para que mis clientes reserven citas]. Usa Superpowers: hazme las preguntas que necesites (una a la vez), escribe el plan y espera mi sí antes de programar cada parte.
```

