# 01 · 1 · Claude Code Setup (oficial)

Revisa tu proyecto y te recomienda qué herramientas te convienen (conectores, skills, hooks, pruebas). Solo recomienda: no toca tus archivos. Es el mejor primero porque te dice cuáles de los otros necesitas de verdad.

## Comando

```
/plugin install claude-code-setup@claude-plugins-official
```

## Prompt para Claude Code: que revise tu proyecto

```
Usa claude-code-setup para revisar este proyecto. Dime qué herramientas, plugins o conectores me convienen y por qué, ordenados de más útil a menos. No instales ni cambies nada: solo la lista con una línea de por qué cada uno.
```

