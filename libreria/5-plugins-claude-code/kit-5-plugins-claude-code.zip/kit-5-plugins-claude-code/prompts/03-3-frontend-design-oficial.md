# 03 · 3 · Frontend Design (oficial)

Le pides una página y, en vez del diseño genérico de siempre (degradado morado y tarjetas iguales), te hace algo con personalidad: tipografía, color y composición pensadas para tu marca.

## Comando

```
/plugin install frontend-design@claude-plugins-official
```

## Prompt para Claude Code: página con personalidad

```
Hazme la página de [TU NEGOCIO, ej. mi cafetería «Tostado lento»]. Usa frontend-design. Antes de programar, propónme la dirección visual en 4 líneas (tipografía, colores, el detalle que la hace distinta). Nada de diseño genérico. Que se vea bien en móvil.
```

