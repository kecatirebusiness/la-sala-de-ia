# 04 · 4 · Caveman

Claude te contesta corto y al grano, sin párrafos de relleno. Hace las respuestas mucho más cortas; no damos un porcentaje de ahorro porque su creador retiró la cifra que usaba antes.

## Comandos (son dos)

```
/plugin marketplace add JuliusBrussee/caveman
/plugin install caveman@caveman
```

