# 05 · 5 · Claude Security (oficial, en beta)

Busca huecos de seguridad en tu código (por ejemplo, una inyección SQL) y te propone el arreglo. No aplica nada por su cuenta: tú decides. Escanea solo código tuyo o que tengas permiso de revisar. Mejor que los encuentres tú antes que un hacker.

## Comando

```
/plugin install claude-security@claude-plugins-official
```

## Prompt para Claude Code: escaneo de seguridad

```
Usa claude-security para revisar este proyecto. Antes de empezar dime cuánto uso va a gastar. Ordena lo que encuentres por gravedad (alta, media, baja), explícame cada uno en una línea sin tecnicismos y propón el parche. No apliques nada hasta que yo te diga cuál.
```

