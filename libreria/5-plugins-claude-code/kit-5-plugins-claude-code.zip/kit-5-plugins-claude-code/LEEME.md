# 5 plugins que ponen a Claude Code a trabajar mucho mejor

Tres son oficiales de Anthropic. Uno revisa tu proyecto, otro lo obliga a planear, otro diseña con personalidad, otro contesta corto y el último busca huecos de seguridad. Cada uno con su comando exacto.

Receta completa: https://lasaladeia.com/libreria/5-plugins-claude-code/

Los comandos se escriben dentro de Claude Code (terminal o app de escritorio) y hay que copiarlos exactos: un carácter de más y no funcionan. Después de instalar, escribe /reload-plugins o reinicia Claude Code. Claude Code Setup, Frontend Design y Claude Security son oficiales de Anthropic; Superpowers es de la comunidad (Jesse Vincent) pero está en el marketplace oficial; Caveman se instala desde su propio marketplace.

**Costo:** Los cinco se instalan gratis. Claude Code requiere un plan de pago de Claude (Pro o Max) y lo que hacen los plugins gasta de tu uso normal. Los escaneos largos de Claude Security gastan bastante: antes de empezar te dice cuánto

**Tiempo:** 5 minutos para instalar los cinco

## Herramientas
- Claude Code: Donde se instalan y corren los plugins. https://claude.com/claude-code
- Claude Security: La página oficial del plugin de seguridad (en beta). https://claude.com/plugins/claude-security
- Docs: cómo instalar plugins: La guía oficial de /plugin: marketplaces, instalar y quitar. https://code.claude.com/docs/en/discover-plugins
- La Sala de IA: Aquí los probamos primero y te contamos cuáles sí valen la pena. https://lasaladeia.com/?utm_source=libreria

## Repos
- anthropics/claude-plugins-official: https://github.com/anthropics/claude-plugins-official
- obra/superpowers: https://github.com/obra/superpowers
- JuliusBrussee/caveman: https://github.com/JuliusBrussee/caveman

## Qué hay en este kit
- instalar.md: los comandos de instalación.
- prompts/: un archivo por paso con sus prompts.
