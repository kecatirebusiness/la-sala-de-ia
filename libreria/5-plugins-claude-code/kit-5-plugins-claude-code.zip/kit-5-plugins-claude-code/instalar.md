# Instalar

Los comandos que empiezan con / se escriben dentro de Claude Code. Los demás, en la terminal (o pídeselos a Claude Code). Después de instalar plugins: /reload-plugins.

## anthropics/claude-plugins-official
https://github.com/anthropics/claude-plugins-official

```
/plugin install claude-code-setup@claude-plugins-official
/plugin install superpowers@claude-plugins-official
/plugin install frontend-design@claude-plugins-official
/plugin install claude-security@claude-plugins-official
```

## obra/superpowers
https://github.com/obra/superpowers

```
/plugin install superpowers@claude-plugins-official
```

## JuliusBrussee/caveman
https://github.com/JuliusBrussee/caveman

```
/plugin marketplace add JuliusBrussee/caveman
/plugin install caveman@caveman
```

