# 3 herramientas gratis para que el sonido de tus videos con Claude no suene falso

Una busca, otra escucha y la otra coloca. Openverse le da a tu agente millones de audios con licencia abierta, Earshot escucha por Claude y Real SFX pone cada sonido en el cuadro exacto.

Receta completa: https://lasaladeia.com/libreria/sonido-para-claude/

Claude ya anima videos increíbles, pero escoge los sonidos a ciegas porque no puede oír. Openverse le da más de 5 millones de audios con licencia abierta que él mismo busca y descarga por su API. Earshot escucha los candidatos por él, le dice cuál pega y, si ninguno sirve, crea uno nuevo por código. Real SFX mira tu edición, encuentra cada momento que pide un sonido (un pop cuando algo aparece, un whoosh en un corte) y lo pone en el cuadro exacto, sin pisar tu voz ni tu música.

**Costo:** Gratis. Openverse es gratis y Earshot es de código abierto (MIT). Real SFX es pública en GitHub, aunque su repo no trae licencia formal. Para usarlas con Claude Code necesitas un plan de Claude

**Tiempo:** 30 minutos para dejar las tres listas (Earshot baja ~1.1 GB de modelos la primera vez que escucha)

## Herramientas
- Openverse: Más de 5 millones de audios con licencia abierta (Wikimedia Commons, Jamendo y Freesound). Tiene API sin cuenta. Revisa la licencia de cada sonido: algunos piden crédito y otros no permiten uso comercial. https://openverse.org
- Claude Code: El que busca, escucha (con Earshot) y coloca. https://claude.com/claude-code
- La Sala de IA: Aquí le ponemos sonido así a nuestros reels y te enseñamos el proceso. https://lasaladeia.com/?utm_source=libreria

## Repos
- Leonxlnx/earshot: https://github.com/Leonxlnx/earshot
- Clipwing/skills: https://github.com/Clipwing/skills

## Qué hay en este kit
- instalar.md: los comandos de instalación.
- prompts/: un archivo por paso con sus prompts.
