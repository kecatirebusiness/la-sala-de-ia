# 02 · Escucha: Earshot

Claude no puede oír, así que escoge a ciegas. Earshot escucha los candidatos con dos modelos abiertos y le dice cuál pega con lo que pediste. Si ninguno sirve, crea uno nuevo por código (sin modelos de audio, a partir de grabaciones de dominio público), y ese sonido es tuyo.

## Prompt para Claude Code: instalar Earshot y escoger

```
Instala Earshot con Python 3.10 o más nuevo: pip install "earshot[listen,mcp] @ git+https://github.com/Leonxlnx/earshot" y conéctalo con: claude mcp add earshot --scope user -- earshot mcp. Corre "earshot doctor" para comprobar. Después escucha los candidatos de sonidos/ y dime cuál pega mejor para cada momento (whoosh, pop, clic) y por qué. Si ninguno sirve, crea uno nuevo con earshot y guárdalo en sonidos/.
```

