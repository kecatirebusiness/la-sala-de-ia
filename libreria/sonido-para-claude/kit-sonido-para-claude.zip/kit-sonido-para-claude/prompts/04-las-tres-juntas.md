# 04 · Las tres juntas

Una busca, otra escucha y la otra coloca. Déjalo escrito en el CLAUDE.md de tu carpeta de edición para que Claude lo haga solo cada vez que termine un video.

## Bloque para el CLAUDE.md de tu carpeta de edición

```
## Sonido
Cuando termines un video, antes de exportar el final:
1. Busca: encuentra los momentos que piden sonido y busca candidatos en la API de Openverse (solo licencia comercial). Anota cada crédito en sonidos/CREDITOS.md.
2. Escucha: usa Earshot para escoger el que pega en cada momento; si ninguno sirve, crea uno con Earshot.
3. Coloca: usa la skill real-sfx para ponerlos en el cuadro exacto sin tapar la voz ni la música.
Nada de sonidos con copyright. Enséñame la pista de efectos antes de mezclar el final.
```

