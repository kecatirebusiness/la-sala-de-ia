# 01 · Busca: Openverse

Openverse tiene más de 5 millones de audios con licencia abierta y una API pública, así que Claude puede buscar y bajar sonidos solo, sin que entres a ninguna página. Filtra por uso comercial si el video es para tu negocio y guarda el crédito de cada sonido.

## Prompt para Claude Code: buscar sonidos en Openverse

```
Busca efectos de sonido en la API de Openverse (https://api.openverse.org/v1/audio/?q=...) para este video: [RUTA/A/TU-VIDEO.mp4]. Necesito: [EJ: un whoosh suave para los cortes, un pop para cuando aparece un texto, un clic de interfaz]. Usa solo sonidos con licencia de uso comercial (license_type=commercial), baja 3 candidatos de cada uno a sonidos/ y crea sonidos/CREDITOS.md con título, autor, licencia y link de cada uno.
```

