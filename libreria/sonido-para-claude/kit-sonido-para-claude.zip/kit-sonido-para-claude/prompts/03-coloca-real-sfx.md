# 03 · Coloca: Real SFX

Real SFX mira tu edición y encuentra cada momento que pide un sonido: un pop cuando algo aparece, un whoosh en un corte. Lo pone en el cuadro exacto, mantiene tu voz y tu música, y te devuelve un MP4 nuevo más la pista de efectos aparte. Usa grabaciones reales de tu librería (o los 78 sonidos de interfaz que trae).

## Prompt para Claude Code: instalar Real SFX y sonorizar

```
Instala la skill Real SFX: clona https://github.com/Clipwing/skills.git y copia la carpeta skills/real-sfx a ~/.claude/skills/. Revisa que FFmpeg y Python 3.9+ estén instalados. Configura mi librería con la carpeta sonidos/ (y los sonidos de interfaz que trae con --uisfx). Después: "add sound design to this render" → [RUTA/A/TU-VIDEO.mp4]. Mantén mi voz y mi música, y dame el MP4 final y la pista de efectos aparte.
```

