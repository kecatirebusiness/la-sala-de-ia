# Instalar

Los comandos que empiezan con / se escriben dentro de Claude Code. Los demás, en la terminal (o pídeselos a Claude Code). Después de instalar plugins: /reload-plugins.

## Leonxlnx/earshot
https://github.com/Leonxlnx/earshot

```
pip install "earshot[listen,mcp] @ git+https://github.com/Leonxlnx/earshot"
claude mcp add earshot --scope user -- earshot mcp
```

## Clipwing/skills
https://github.com/Clipwing/skills

```
git clone https://github.com/Clipwing/skills.git clipwing-skills
mkdir -p ~/.claude/skills && cp -R clipwing-skills/skills/real-sfx ~/.claude/skills/
```

