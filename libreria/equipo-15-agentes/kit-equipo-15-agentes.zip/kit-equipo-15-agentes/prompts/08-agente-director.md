# El agente director: metas, reparto y relevos

El agente director mira las metas de la semana, reparte el trabajo y cada agente le pasa la tarea al siguiente como un equipo de verdad: el contenido trae leads, ventas los pasa a la oficina cuando dicen que sí, y la oficina le cuenta al director qué se cobró. Mientras tú trabajas en una cosa, otras seis se están moviendo.

## Prompt para Claude Code: CLAUDE.md del agente director

```
Crea un CLAUDE.md en la raíz de esta carpeta para el agente director: 1) cada lunes lee las metas en metas.md y reparte el trabajo entre crecimiento, ventas y oficina; 2) antes de cualquier tarea lee conocimiento/; 3) los relevos: contenido publicado → ventas vigila los leads que trae; lead que dice que sí → oficina; pago cobrado → reportes/semana.md; 4) cada viernes escribe en una página qué se hizo, qué se cobró y qué sigue. Mis metas de esta semana: [EJ: lanzar la auditoría de marca, 10 leads nuevos, 3 facturas cobradas].
```
