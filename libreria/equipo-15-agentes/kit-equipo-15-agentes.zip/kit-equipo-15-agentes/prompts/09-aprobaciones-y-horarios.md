# Solo te pregunta cuando hay una decisión de verdad

El equipo trabaja solo, pero hay decisiones que son tuyas: un descuento, una propuesta especial, un cliente molesto, un pago que no llega. Esas te llegan por Slack o Telegram con dos botones: aprobar o rechazar. Lo demás corre a su hora.

## Prompt para Claude Code: tus reglas de aprobación y los horarios

```
Escribe conocimiento/reglas.md con lo que el equipo hace solo y lo que necesita mi sí: descuentos, propuestas de más de $[MONTO], quejas de clientes, pagos con más de 14 días de atraso y cualquier cosa que se publique. Lo que necesite mi sí me lo mandas por Slack con el contexto en 2 líneas y la opción de aprobar o rechazar. Después prográmame: el reparto de los lunes a las 8:00, el resumen diario a las 18:00 y el reporte de los viernes. Dime cómo pausarlo.
```
