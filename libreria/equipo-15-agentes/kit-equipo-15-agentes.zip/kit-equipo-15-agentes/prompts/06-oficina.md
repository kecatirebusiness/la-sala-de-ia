# La oficina: propuesta, factura y bienvenida

En el momento en que alguien dice que sí, la oficina se encarga: Claude escribe la propuesta y PandaDoc la manda a firmar, Stripe manda la factura con el link de pago y QuickBooks la registra, y el cliente recibe su correo de bienvenida con su portal en Notion. Tú no tocas nada.

## Prompt para Claude Code: del sí al cliente nuevo

```
Cuando un lead en HubSpot pase a "dijo que sí": 1) escribe la propuesta con conocimiento/ventas/oferta.md y precios.md (qué incluye, precio y plazos) y déjala lista para PandaDoc; 2) crea la factura en Stripe por [MONTO] con vencimiento a 14 días; 3) escribe el correo de bienvenida con mi voz y la lista de lo que necesito del cliente; 4) crea su página en conocimiento/clientes/proyectos.md. Muéstrame todo antes de mandar nada.
```
