# Crecimiento: artículos SEO y tu newsletter

Tu agente de SEO mira lo que está buscando tu nicho en Semrush y escribe dos artículos por semana. Tu agente de newsletter toma lo mejor de la semana (el reel, el artículo y el gráfico) y arma la edición en Beehiiv. Apareces en todas partes sin pasarte el día haciendo contenido.

## Prompt para Claude Code: 2 artículos + newsletter

```
Te pego las búsquedas de mi nicho de esta semana: [PEGA LA LISTA DE SEMRUSH: palabra clave y volumen]. Elige las 2 con más volumen que encajen con conocimiento/ventas/oferta.md y escribe un artículo de 800 palabras para cada una, con mi voz, títulos claros y un CTA al final. Después arma el newsletter de la semana: una intro de 3 líneas, el reel, los 2 artículos y el gráfico, listo para pegar en Beehiiv. Déjalo todo en borradores/.
```
