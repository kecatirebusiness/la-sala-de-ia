# Ventas: cada lead respondido en minutos

El agente de bandeja separa los leads del ruido. El de respuesta contesta en minutos con tu voz y manda tu Calendly. La llamada cae en tu calendario. Y si alguien todavía no está listo, el de seguimiento le escribe el día 3, el 7 y el 14 hasta que lo esté. Todo queda registrado en HubSpot.

## Prompt para Claude Code: bandeja, respuesta y seguimiento

```
Lee conocimiento/ventas/ y conocimiento/voz/. Escríbeme: 1) las reglas para separar mi bandeja en LEAD, CLIENTE, URGENTE y RUIDO, con ejemplos; 2) la respuesta a un lead nuevo (máximo 4 líneas, con mi voz, termina con mi link de Calendly [TU LINK]); 3) una secuencia de seguimiento para los que no están listos: día 3 (un caso de estudio), día 7 (un tip rápido) y día 14 (pregunta directa). Dime qué propiedades crear en HubSpot para saber en qué paso va cada lead.
```
