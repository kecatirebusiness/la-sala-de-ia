# La capa de conocimiento: escrita una vez, la usan los 15

Todos los agentes leen los mismos archivos: tu voz, tu audiencia, lo que vendes, tus clientes y el reporte de la semana. Por eso todo suena a ti. Pídele a Claude que te los arme con una entrevista corta.

## Prompt para Claude Code: la capa de conocimiento

```
Voy a montar un equipo de agentes para mi negocio. Hazme una entrevista corta (una pregunta a la vez, máximo 12) y con mis respuestas crea esta carpeta:

conocimiento/
  voz/        → tono.md (cómo hablo) y frases.md (frases que uso y palabras que nunca uso)
  audiencia/  → clientes.md (quién me compra) y dolores.md (qué le preocupa, con sus palabras)
  ventas/     → oferta.md (qué vendo, paquetes) y precios.md
  clientes/   → proyectos.md (clientes activos y en qué van)
  reportes/   → semana.md (lo llena el agente director cada viernes)

Mi negocio: [DESCRIBE TU NEGOCIO EN 2 LÍNEAS]. Escribe todo en español, corto y concreto.
```
