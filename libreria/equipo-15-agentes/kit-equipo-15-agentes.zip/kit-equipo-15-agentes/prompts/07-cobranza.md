# Cobranza sin perseguir a nadie

Si un pago se atrasa, el agente de cobranza lo detecta en Stripe y manda un recordatorio amable con el link para pagar en un clic. Cuando entra el pago, queda registrado. Cobras y nunca tocas el papeleo.

## Prompt para Claude Code: recordatorios de pago

```
Revisa en Stripe las facturas abiertas que llevan más de 3 días vencidas. Para cada una escribe un recordatorio amable con mi voz (máximo 3 líneas, con el número de factura y el link de pago). Día 3: recordatorio suave. Día 7: segundo recordatorio. Día 14: me avisas a mí en vez de escribirle al cliente. Dame la lista para aprobar antes de enviar.
```
