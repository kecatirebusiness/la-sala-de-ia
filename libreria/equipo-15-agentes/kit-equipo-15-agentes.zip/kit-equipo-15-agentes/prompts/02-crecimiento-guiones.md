# Crecimiento: guiones, videos y gráficos cada lunes

Cada lunes Claude escribe los guiones de la semana con tu voz, Higgsfield los convierte en videos, CapCut les pone subtítulos y Canva hace los gráficos. Tú solo apruebas.

## Prompt para Claude Code: los guiones de la semana

```
Lee conocimiento/voz/ y conocimiento/audiencia/. Escríbeme 7 guiones de reels de 30 segundos para esta semana, uno por día, cada uno con: hook de 3 segundos, 3 puntos y CTA. Usa los dolores reales de mis clientes. Para cada guion dame también el prompt en inglés para el video en Higgsfield y el texto de un gráfico para Canva. Guárdalo en contenido/semana-[FECHA].md y no publiques nada sin mi sí.
```

## Prompt de video para Higgsfield (9:16)

```
Vertical video, a [PERSONA, ej. small business owner in her 30s] in [LUGAR, ej. a bright home office] talking to the camera about [TEMA DEL GUION], natural window light, handheld feel, real skin texture, casual and authentic.
```

Abrir: https://higgsfield.ai?fpr=kecatire
