# Soporte de día y de noche

Tu agente de soporte responde a los clientes a cualquier hora usando tus preguntas frecuentes en Notion. Si algo no está en las preguntas frecuentes, no inventa: te avisa. Nadie te espera.

## Prompt para Claude Code: tus preguntas frecuentes

```
Te pego los últimos 30 mensajes que me mandaron clientes: [PÉGALOS]. Agrúpalos en las 15 preguntas que más se repiten y escribe la respuesta de cada una con mi voz (máximo 3 líneas). Guárdalo como preguntas-frecuentes.md para Notion. Después escribe las reglas del agente de soporte: responde solo con lo que está ahí, y si no lo sabe o el cliente está molesto, me avisa por Slack en vez de responder.
```
