# Mapa del equipo · 15 agentes

Cada agente trabaja con dos herramientas. Marca con [x] los que vas a montar primero.

## Crecimiento

5 agentes · apareces en todas partes sin pasarte el día haciendo contenido

| Agente | Herramienta 1 | Herramienta 2 | ¿Lo monto? |
|---|---|---|---|
| Guionista | claude — Los guiones reales de la semana | notion — Tu plan de contenido | [ ] |
| Editor de video | higgsfield — Guiones a videos | capcut — Subtítulos y cortes | [ ] |
| Diseñador | canva — Gráficos del lanzamiento | claude — Escribe los titulares | [ ] |
| Newsletter | beehiiv — Tu newsletter semanal | claude — Lo mejor de la semana | [ ] |
| Redactor SEO | semrush — Lo que busca tu nicho | claude — Dos artículos por semana | [ ] |

## Ventas

5 agentes · cada lead y cada cliente recibe respuesta en minutos

| Agente | Herramienta 1 | Herramienta 2 | ¿Lo monto? |
|---|---|---|---|
| Ordena la bandeja | gmail — Separa lo importante | jev — Lead, urgente o ruido | [ ] |
| Responde leads | claude — Responde en minutos | manychat — DMs y comentarios | [ ] |
| Agenda llamadas | calendly — Agenda la llamada | gcal — Tu calendario | [ ] |
| Agente de soporte | intercom — Responde a clientes | notion — Tus preguntas frecuentes | [ ] |
| Seguimiento | claude — Hasta que esté listo | hubspot — Cada lead registrado | [ ] |

## Oficina

4 agentes · cobras y nunca tocas el papeleo

| Agente | Herramienta 1 | Herramienta 2 | ¿Lo monto? |
|---|---|---|---|
| Propuestas | claude — Escribe la propuesta | pandadoc — La manda a firmar | [ ] |
| Facturas | stripe — Factura y link de pago | quickbooks — Lo registra | [ ] |
| Bienvenida | gmail — Correo de bienvenida | notion — Portal del cliente | [ ] |
| Cobranza | stripe — Detecta pagos atrasados | claude — Recordatorios amables | [ ] |

## Agente director

1 agente · metas, reparte y solo te pregunta lo importante

| Agente | Herramienta 1 | Herramienta 2 | ¿Lo monto? |
|---|---|---|---|
| Metas semanales | notion — Las metas de la semana | claude — Las reparte al equipo | [ ] |
| Aprobaciones | slack — Te pregunta aquí | telegram — O aquí, en el teléfono | [ ] |
