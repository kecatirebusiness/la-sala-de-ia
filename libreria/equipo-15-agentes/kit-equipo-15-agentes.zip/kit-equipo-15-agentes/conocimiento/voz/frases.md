# Frases

Frases que uso:
Palabras que nunca uso:
