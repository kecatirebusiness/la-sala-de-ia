# Clientes activos

| Cliente | Proyecto | Estado | Próximo paso |
|---|---|---|---|
