# Reglas

## El equipo lo hace solo
- Escribir guiones, artículos y el newsletter (en borradores/)
- Responder leads nuevos y mandar mi Calendly
- Seguimiento a los que no están listos (día 3, 7 y 14)
- Responder a clientes con las preguntas frecuentes
- Recordatorios de pago amables (día 3 y 7)

## Necesita mi sí
- Publicar cualquier cosa
- Descuentos y propuestas de más de $[MONTO]
- Clientes molestos o preguntas que no están en las frecuentes
- Pagos con más de 14 días de atraso
