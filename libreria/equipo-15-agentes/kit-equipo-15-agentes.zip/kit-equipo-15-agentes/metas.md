# Metas de esta semana

1. 
2. 
3. 
