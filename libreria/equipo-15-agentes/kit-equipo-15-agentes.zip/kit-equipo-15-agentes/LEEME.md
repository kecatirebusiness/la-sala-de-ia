# Kit · Equipo de 15 agentes para el que emprende solo

Qué hay aquí:
- CLAUDE.md → las reglas del agente director. Abre Claude Code dentro de esta carpeta.
- conocimiento/ → la capa que leen los 15 agentes: voz, audiencia, ventas, clientes y reportes. Rellénala o pídele a Claude la entrevista (prompts/01-conocimiento.md).
- conocimiento/reglas.md → lo que el equipo hace solo y lo que necesita tu sí.
- metas.md → las metas de la semana que reparte el director.
- prompts/ → un archivo por paso, en el mismo orden que la página de la librería.
- mapa-15-agentes.md → los 4 equipos con cada agente y sus dos herramientas.
- borradores/ → todo lo que espera tu sí.

Montado juntos, paso a paso, en La Sala de IA: https://lasaladeia.com
