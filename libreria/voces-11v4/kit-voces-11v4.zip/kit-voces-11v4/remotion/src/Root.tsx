import React from 'react';
import {Composition} from 'remotion';
import {Edit, TOTAL} from './Edit';
export const Root: React.FC = () => <Composition id="Edit" component={Edit} durationInFrames={TOTAL} fps={30} width={1080} height={1920} />;
