import React from 'react';
import {AbsoluteFill, Audio, Img, OffthreadVideo, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {C, Cursor, F, Logo, Wave, clamp, path, pop, press, ramp, typed} from './kit';
import FILM from './film.json';

// ---------- tiempos ----------
type Clip = {id: string; frames: number; from?: number; lines: {t: string; a: number; b: number}[]};
const CLIPS = FILM as Clip[];
const starts: number[] = [];
let acc = 0;
for (const c of CLIPS) { starts.push(acc); acc += c.frames; }
const F0 = acc;                    // aquí empieza el tutorial
const VO = 1201;
export const TOTAL = F0 + VO;
const v = (t: number) => Math.round(F0 + t * 30);

const PURPLE = '#a855f7', INK = '#111113', LINE = '#e6e6e8', MUTED = '#8b8b90';

// ---------- PARTE 1: la película ----------
const FY = 505, FH = 608;
const subChunks = (() => {
  const out: {a: number; b: number; t: string}[] = [];
  CLIPS.forEach((c, i) => c.lines.forEach((l) => out.push({a: starts[i] + l.a * 30, b: starts[i] + l.b * 30, t: l.t})));
  return out;
})();

const AudioChip: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <div style={{position: 'absolute', left: x, top: y, width: 96 * s, height: 116 * s, borderRadius: 14 * s, background: '#fff', boxShadow: '0 12px 40px rgba(0,0,0,0.55)', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
    <div style={{position: 'absolute', right: 0, top: 0, width: 26 * s, height: 26 * s, background: '#e9e9ee', borderBottomLeftRadius: 8 * s}} />
    <Wave w={56 * s} h={44 * s} seed={7} color={PURPLE} n={9} />
  </div>
);

const Movie: React.FC = () => {
  const f = useCurrentFrame();
  const sub = subChunks.find((k) => f >= k.a && f < k.b);
  const iC = CLIPS.findIndex((c) => c.id === 'C');
  const inC = iC >= 0 && f >= starts[iC] && f < starts[iC] + CLIPS[iC].frames;
  // el archivo de audio "cae" sobre la película cuando cambia la voz (se baja la máscara)
  const D0 = 5.0 * 30, chip = path(f, [[D0, 860, 1320], [D0 + 18, 640, 900], [D0 + 30, 640, 900]]);
  const chipA = interpolate(f, [D0, D0 + 4, D0 + 26, D0 + 32], [0, 1, 1, 0], clamp);
  return (
    <AbsoluteFill style={{background: '#000'}}>
      <div style={{position: 'absolute', left: 0, right: 0, top: 286, textAlign: 'center', fontFamily: F.pop, fontWeight: 700, fontSize: 64, lineHeight: 1.22, color: '#fff', letterSpacing: -1}}>
        Las voces con IA ya son<br />demasiado reales 😳
      </div>
      <div style={{position: 'absolute', left: 0, top: FY, width: 1080, height: FH, overflow: 'hidden', background: '#050505'}}>
        {CLIPS.map((c, i) => (
          <Sequence key={c.id} from={starts[i]} durationInFrames={c.frames} layout="none">
            <OffthreadVideo src={staticFile(`film_${c.id}.mp4`)} startFrom={c.from ?? 0} muted style={{position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover'}} />
          </Sequence>
        ))}
        {sub && <div style={{position: 'absolute', left: 0, right: 0, bottom: 28, textAlign: 'center', fontFamily: F.serifI, fontStyle: 'italic', fontSize: 39, color: '#f4d35e', textShadow: '0 2px 10px rgba(0,0,0,0.85), 0 0 2px rgba(0,0,0,0.9)'}}>{sub.t}</div>}
      </div>
      {inC && (
        <div style={{position: 'absolute', left: 240, top: 1150, width: 600, height: 338, overflow: 'hidden', borderRadius: 6, opacity: ramp(f, starts[iC], starts[iC] + 5), transform: `scale(${0.92 + 0.08 * pop(f, starts[iC])})`, boxShadow: '0 0 0 2px rgba(255,255,255,0.14)'}}>
          <Sequence from={starts[iC]} durationInFrames={158} layout="none"><OffthreadVideo src={staticFile('perf.mp4')} muted style={{width: '100%', height: '100%', objectFit: 'cover'}} /></Sequence>
          {f >= starts[iC] + 158 && <Img src={staticFile('perf_last.jpg')} style={{position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover'}} />}
          <div style={{position: 'absolute', left: 12, top: 10, padding: '4px 12px', borderRadius: 14, background: 'rgba(0,0,0,0.6)', color: '#fff', fontFamily: F.ui, fontWeight: 700, fontSize: 20}}>Mi actuación real</div>
        </div>
      )}
      {chipA > 0 && <div style={{opacity: chipA}}><AudioChip x={chip.x} y={chip.y} /><Cursor x={chip.x + 70} y={chip.y + 84} /></div>}
    </AbsoluteFill>
  );
};

// ---------- presentador (cabeza sale del marco) ----------
const BOX = 900, BX = 90, BY = 842, CX = 140, CY = 1150, CW = 800;
const Host: React.FC = () => {
  const f = useCurrentFrame();
  const up = (1 - pop(f, 0, {damping: 16, stiffness: 120, mass: 0.8})) * 860;
  return (
    <AbsoluteFill style={{transform: `translateY(${up}px)`}}>
      <div style={{position: 'absolute', left: CX, top: CY, width: CW, height: 1920 - CY + 60, borderRadius: 60, overflow: 'hidden', background: '#0c0f0e', boxShadow: '0 -10px 60px rgba(0,0,0,0.18)'}}>
        <OffthreadVideo src={staticFile('aroll.mp4')} muted style={{position: 'absolute', left: BX - CX, top: BY - CY, width: BOX, height: BOX}} />
        <OffthreadVideo src={staticFile('aroll.mp4')} muted style={{position: 'absolute', left: BX - CX, top: BY - CY + BOX - 2, width: BOX, height: BOX, transform: 'scaleY(-1)'}} />
        <div style={{position: 'absolute', left: 0, right: 0, top: BY - CY + BOX - 120, height: 320, background: 'linear-gradient(180deg, rgba(10,12,11,0) 0%, rgba(10,12,11,0.92) 45%, #0a0c0b 100%)'}} />
      </div>
      <div style={{position: 'absolute', left: CX, top: CY - 220, width: CW, height: 220, overflow: 'hidden'}}>
        <OffthreadVideo src={staticFile('cutout.webm')} transparent muted style={{position: 'absolute', left: BX - CX, top: BY - (CY - 220), width: BOX, height: BOX}} />
      </div>
    </AbsoluteFill>
  );
};

// ---------- piezas de interfaz clara ----------
const Scene: React.FC<{from: number; to: number; children: React.ReactNode}> = ({from, to, children}) => {
  const f = useCurrentFrame();
  if (f < from - 1 || f > to + 1) return null;
  const a = Math.min(interpolate(f, [from, from + 6], [0, 1], clamp), interpolate(f, [to - 5, to], [1, 0], clamp));
  return <AbsoluteFill style={{opacity: a, filter: a < 1 ? `blur(${(1 - a) * 14}px)` : undefined, transform: `scale(${0.965 + 0.035 * a})`}}>{children}</AbsoluteFill>;
};
const Head: React.FC<{f: number; at: number}> = ({f, at}) => (
  <div style={{position: 'absolute', top: 250, left: 0, right: 0, display: 'flex', justifyContent: 'center', transform: `scale(${0.92 + 0.08 * pop(f, at)})`}}><Logo src="elevenlabs_black.svg" h={62} /></div>
);
const LCard: React.FC<{x: number; y: number; w: number; h: number; children?: React.ReactNode; hot?: boolean; style?: React.CSSProperties}> = ({x, y, w, h, children, hot, style}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: 30, background: '#fff', boxShadow: hot ? `0 0 0 3px ${C.claude}, 0 24px 70px rgba(0,0,0,0.12)` : `0 0 0 1.5px ${LINE}, 0 24px 70px rgba(0,0,0,0.10)`, overflow: 'hidden', ...style}}>{children}</div>
);
const T: React.FC<{x: number; y: number; s?: number; w?: number; c?: string; children: React.ReactNode; style?: React.CSSProperties}> = ({x, y, s = 28, w = 500, c = INK, children, style}) => (
  <div style={{position: 'absolute', left: x, top: y, fontFamily: F.ui, fontWeight: w, fontSize: s, color: c, whiteSpace: 'nowrap', ...style}}>{children}</div>
);
const Box: React.FC<{x: number; y: number; w: number; h: number; hot?: boolean; bg?: string; r?: number; children?: React.ReactNode}> = ({x, y, w, h, hot, bg = '#fff', r = 14, children}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: r, background: bg, boxShadow: hot ? `0 0 0 3px ${C.claude}` : `0 0 0 1.5px ${LINE}`, overflow: 'hidden'}}>{children}</div>
);
const VoiceIcon: React.FC<{s?: number}> = ({s = 46}) => <div style={{width: s, height: s, borderRadius: s * 0.24, background: '#f3e8ff', display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Wave w={s * 0.56} h={s * 0.56} seed={3} color={PURPLE} n={5} /></div>;

// 0. título Eleven v4
const Title: React.FC = () => {
  const f = useCurrentFrame() - F0;
  return (
    <AbsoluteFill style={{background: '#16302a', overflow: 'hidden'}}>
      <AbsoluteFill style={{background: `linear-gradient(${118 + f * 0.25}deg, #0d3b2e 0%, #1f7a55 16%, #e8795a 34%, #f6c9b4 44%, #d9603f 56%, #1c6b4c 72%, #0b2a22 100%)`, filter: 'blur(30px)', transform: `scale(1.5) translateX(${-60 + f * 0.9}px)`}} />
      <AbsoluteFill style={{background: 'repeating-linear-gradient(118deg, rgba(255,255,255,0.10) 0 6px, rgba(255,255,255,0) 6px 60px)', filter: 'blur(8px)', transform: `translateX(${f * 1.6 - 80}px) scale(1.3)`}} />
      <div style={{position: 'absolute', left: 0, right: 0, top: 500, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 22, transform: `scale(${0.8 + 0.2 * pop(f, 4)})`, opacity: ramp(f, 2, 9)}}>
        <div style={{fontFamily: F.ui, fontWeight: 300, fontSize: 168, color: '#fff', letterSpacing: -5, lineHeight: 1}}>Eleven</div>
        <div style={{height: 150, padding: '0 34px', borderRadius: 80, boxShadow: 'inset 0 0 0 8px #fff', display: 'flex', alignItems: 'center', fontFamily: F.ui, fontWeight: 700, fontSize: 112, color: '#fff', letterSpacing: -2}}>V4</div>
      </div>
    </AbsoluteFill>
  );
};

// 1. Voice Design
const VPROMPT = 'Voz de mujer latina de unos 25 años, brillante, coqueta y descarada, muy expresiva, con actitud y energía.';
const VoiceDesign: React.FC = () => {
  const f = useCurrentFrame();
  const S = v(4.23), T0 = v(4.9), T1 = v(8.6), GEN = v(9.15);
  const cur = path(f, [[T1, 760, 900], [GEN - 3, 540, 962]]);
  return (
    <AbsoluteFill>
      <Head f={f} at={S} />
      <LCard x={130} y={400} w={820} h={620}>
        <div style={{position: 'absolute', left: 44, top: 40, width: 64, height: 64, borderRadius: 16, boxShadow: `0 0 0 1.5px ${LINE}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 30}}>✎</div>
        <T x={128} y={54} s={34} w={500}>Voice Design</T>
        <T x={748} y={40} s={36} c={MUTED} w={300}>×</T>
        <T x={44} y={148} s={25} c={MUTED}>Prompt</T>
        <Box x={44} y={190} w={732} h={270} hot={f >= T0 - 3 && f < GEN}>
          <div style={{padding: '18px 22px', fontFamily: F.ui, fontWeight: 500, fontSize: 30, lineHeight: 1.36, color: INK}}>{typed(VPROMPT, f, T0, T1)}{f > T0 && f < T1 + 8 && f % 14 < 8 && <span style={{color: C.claude}}>|</span>}</div>
        </Box>
        <div style={{position: 'absolute', left: 44, top: 510, width: 732, height: 68, borderRadius: 14, background: f >= GEN ? INK : '#fff', color: f >= GEN ? '#fff' : MUTED, boxShadow: `0 0 0 1.5px ${LINE}`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: F.ui, fontWeight: 700, fontSize: 27, transform: `scale(${1 - press(f, GEN) * 0.04})`}}>{f >= GEN + 4 ? 'Generating voice…' : 'Generate voice'}</div>
      </LCard>
      {f > T1 && <Cursor x={cur.x} y={cur.y} press={press(f, GEN)} />}
    </AbsoluteFill>
  );
};

// 2. Create voice -> Instant Voice Clone -> subir archivo -> Custom voice
const Clone: React.FC = () => {
  const f = useCurrentFrame();
  const S = v(9.63), CLK = v(11.6), UP = v(12.47), DROP = v(14.6), DONE = v(16.0), END = v(17.5);
  const menu = f < UP;
  const cur = menu ? path(f, [[S + 8, 820, 560], [CLK - 3, 600, 860]]) : path(f, [[UP, 600, 860], [UP + 14, 900, 470], [DROP - 14, 900, 470], [DROP, 560, 700]]);
  const fileA = interpolate(f, [UP + 14, UP + 20, DROP + 2, DROP + 8], [0, 1, 1, 0], clamp);
  return (
    <AbsoluteFill>
      <Head f={f} at={S} />
      {menu ? (
        <LCard x={130} y={400} w={820} h={620} style={{opacity: 1 - ramp(f, UP - 5, UP)}}>
          <div style={{position: 'absolute', left: 44, top: 40, width: 64, height: 64, borderRadius: 16, boxShadow: `0 0 0 1.5px ${LINE}`, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Wave w={30} h={30} seed={2} color={INK} n={4} /></div>
          <T x={128} y={54} s={34} w={700}>Create voice</T>
          <T x={590} y={62} s={22} c={MUTED}>14 / 30 created</T>
          <Box x={44} y={140} w={732} h={200} r={18}>
            <T x={28} y={24} s={29} w={700}>✎ Voice Design</T>
            <T x={28} y={72} s={23} c={MUTED}>Design an entirely new voice from a text prompt.</T>
            <div style={{position: 'absolute', left: 28, top: 122, padding: '8px 18px', borderRadius: 20, background: '#f1f1f3', fontFamily: F.ui, fontWeight: 700, fontSize: 21}}>Less than a minute</div>
          </Box>
          <Box x={44} y={366} w={732} h={200} r={18} hot={f >= CLK - 14}>
            <T x={28} y={24} s={29} w={700}>⚡ Instant Voice Clone</T>
            <T x={28} y={72} s={23} c={MUTED}>Clone your voice with only 10 seconds of audio.</T>
            <div style={{position: 'absolute', left: 28, top: 122, padding: '8px 18px', borderRadius: 20, background: '#f1f1f3', fontFamily: F.ui, fontWeight: 700, fontSize: 21}}>2 minutes</div>
          </Box>
        </LCard>
      ) : (
        <div style={{opacity: ramp(f, UP, UP + 6)}}>
          <Box x={150} y={470} w={780} h={440} r={22} bg="#eeeff1" hot={f >= DROP - 16 && f < DONE}>
            {f < DONE && <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: F.ui, fontWeight: 500, fontSize: 36, color: INK}}>{f < DROP + 4 ? 'Click to upload' : 'Cloning voice…'}</div>}
            {f >= DROP + 2 && f < DONE && <div style={{position: 'absolute', left: 60, top: 330, width: 660 * ramp(f, DROP + 2, DONE - 2), height: 10, borderRadius: 5, background: PURPLE}} />}
            {f >= DONE && (
              <div style={{position: 'absolute', left: 150, top: 170, width: 480, height: 96, borderRadius: 20, background: '#fff', boxShadow: `0 0 0 1.5px ${LINE}, 0 14px 40px rgba(0,0,0,0.10)`, display: 'flex', alignItems: 'center', gap: 18, padding: '0 22px', transform: `scale(${pop(f, DONE)})`}}>
                <VoiceIcon s={56} /><div style={{fontFamily: F.ui, fontWeight: 700, fontSize: 32, color: INK}}>Custom voice</div><div style={{marginLeft: 'auto', color: '#22a55b', fontSize: 34, fontWeight: 900}}>✓</div>
              </div>
            )}
          </Box>
          <div style={{opacity: fileA}}><AudioChip x={cur.x - 70} y={cur.y - 90} /></div>
        </div>
      )}
      {f > S + 8 && f < DONE && <Cursor x={cur.x} y={cur.y} press={Math.max(press(f, CLK), press(f, DROP))} />}
    </AbsoluteFill>
  );
};

// 3. Modelo V4 + diálogo + Auto-tag
const LINE_TXT = '¡ESTO ESTÁ LOCO!';
const Tags: React.FC = () => {
  const f = useCurrentFrame();
  const S = v(17.5), OPEN = v(18.0), PICK = v(18.75), T0 = v(19.0), T1 = v(20.2), AUTO = v(21.1), CLIP = v(23.6), END = v(24.8);
  const open = f >= OPEN && f < PICK + 4, picked = f >= PICK;
  const z = interpolate(f, [AUTO - 8, AUTO + 8, CLIP - 6, CLIP], [1, 1.26, 1.26, 1], clamp);
  const cur = path(f, [[S + 4, 760, 960], [OPEN - 3, 820, 568], [PICK - 3, 420, 792], [T1, 620, 760], [AUTO - 3, 640, 892]]);
  const tag = (t: string, at: number) => <div style={{padding: '8px 22px', borderRadius: 12, background: '#f3e8ff', boxShadow: `0 0 0 2px ${PURPLE}66`, color: '#7e22ce', fontFamily: F.ui, fontWeight: 700, fontSize: 30, transform: `scale(${pop(f, at)})`, opacity: f >= at ? 1 : 0}}>{t}</div>;
  const tagged = f >= AUTO + 24;
  return (
    <AbsoluteFill>
      <div style={{opacity: 1 - ramp(f, AUTO - 8, AUTO)}}><Head f={f} at={S} /></div>
      <div style={{position: 'absolute', inset: 0, transform: `scale(${z})`, transformOrigin: '50% 42%', opacity: 1 - ramp(f, CLIP - 5, CLIP)}}>
        <Box x={290} y={400} w={500} h={84} r={18}>
          <div style={{display: 'flex', alignItems: 'center', gap: 16, height: '100%', padding: '0 20px'}}><VoiceIcon /><div style={{fontFamily: F.ui, fontWeight: 500, fontSize: 30, color: INK}}>Custom voice</div><div style={{marginLeft: 'auto', color: MUTED, fontSize: 26}}>⌄</div></div>
        </Box>
        <T x={150} y={506} s={26} w={500}>Model</T>
        <Box x={150} y={546} w={780} h={76} r={14} hot={f >= OPEN - 4 && f < PICK + 4}>
          <div style={{display: 'flex', alignItems: 'center', height: '100%', padding: '0 24px', fontFamily: F.ui, fontWeight: 500, fontSize: 30, color: INK}}>{picked ? 'V4' : 'Select model'}<span style={{marginLeft: 'auto', color: MUTED, fontSize: 26}}>⌄</span></div>
        </Box>
        <LCard x={150} y={646} w={780} h={300}>
          <T x={26} y={22} s={23} c={MUTED}>Character dialogue</T>
          <div style={{position: 'absolute', left: 26, top: 64, fontFamily: F.ui, fontWeight: 500, fontSize: 36, color: INK}}>
            {tagged && <span style={{color: '#7e22ce', fontWeight: 700}}>[excited] [shouting] </span>}{typed(LINE_TXT, f, T0, T1)}
          </div>
          <div style={{position: 'absolute', right: 190, bottom: 26, height: 60, padding: '0 26px', borderRadius: 12, boxShadow: `0 0 0 2.5px ${PURPLE}`, display: 'flex', alignItems: 'center', fontFamily: F.ui, fontWeight: 700, fontSize: 25, color: '#7e22ce', background: f >= AUTO ? '#f3e8ff' : '#fff', transform: `scale(${1 - press(f, AUTO) * 0.08})`}}>Auto-tag</div>
          <div style={{position: 'absolute', right: 26, bottom: 26, height: 60, padding: '0 26px', borderRadius: 12, background: INK, display: 'flex', alignItems: 'center', fontFamily: F.ui, fontWeight: 700, fontSize: 25, color: '#fff'}}>Generate</div>
        </LCard>
        <div style={{position: 'absolute', left: 150, top: 966, display: 'flex', gap: 16}}>{tag('[excited]', AUTO + 5)}{tag('[shouting]', AUTO + 11)}{tag('[laughs]', AUTO + 17)}</div>
        {open && (
          <div style={{position: 'absolute', left: 150, top: 632, width: 780, borderRadius: 16, background: '#fff', boxShadow: `0 0 0 1.5px ${LINE}, 0 24px 60px rgba(0,0,0,0.16)`, padding: 10, opacity: ramp(f, OPEN, OPEN + 4)}}>
            {['V2', 'V3', 'V4'].map((m, i) => <div key={m} style={{height: 66, borderRadius: 10, display: 'flex', alignItems: 'center', padding: '0 18px', fontFamily: F.ui, fontWeight: 500, fontSize: 30, color: INK, background: i === 2 && f >= PICK - 10 ? '#fdeee9' : 'transparent', boxShadow: i === 2 && f >= PICK - 10 ? `inset 0 0 0 2px ${C.claude}` : 'none'}}>{m}</div>)}
          </div>
        )}
        {f > S + 4 && f < AUTO + 14 && <Cursor x={cur.x} y={cur.y} press={Math.max(press(f, OPEN), press(f, PICK), press(f, AUTO))} />}
      </div>
      {f >= CLIP - 2 && (
        <div style={{position: 'absolute', left: 60, top: 420, width: 960, height: 540, borderRadius: 26, overflow: 'hidden', opacity: ramp(f, CLIP - 2, CLIP + 4), transform: `scale(${0.9 + 0.1 * pop(f, CLIP - 2)})`, boxShadow: '0 30px 80px rgba(0,0,0,0.25)'}}>
          <Sequence from={CLIP - 2} layout="none"><OffthreadVideo src={staticFile('film_C.mp4')} startFrom={70} muted style={{width: '100%', height: '100%', objectFit: 'cover'}} /></Sequence>
        </div>
      )}
    </AbsoluteFill>
  );
};

// 4. Imagen y video: Seedance 2.5 + audio + referencias + prompt
const GPROMPT = 'La chica mira directo a cámara frente a la pared de ficha policial y dice el diálogo con actitud, copiando los gestos del video de referencia.';
const Slot: React.FC<{x: number; y: number; w: number; h: number; label: string; hot?: boolean; children?: React.ReactNode}> = ({x, y, w, h, label, hot, children}) => (
  <Box x={x} y={y} w={w} h={h} r={16} bg="#f4f4f6" hot={hot}>
    {children ?? <><div style={{position: 'absolute', left: 0, right: 0, top: h * 0.26, textAlign: 'center', fontFamily: F.ui, fontWeight: 300, fontSize: 40, color: MUTED}}>+</div></>}
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 12, textAlign: 'center', fontFamily: F.ui, fontWeight: 500, fontSize: 22, color: children ? INK : MUTED, textShadow: children ? '0 0 6px #fff' : 'none'}}>{label}</div>
  </Box>
);
const Generator: React.FC = () => {
  const f = useCurrentFrame();
  const S = v(24.8), TAB = v(25.7), OPEN = v(26.7), PICK = v(27.9), AUD = v(29.4), VID = v(31.6), IMG = v(32.9), P0 = v(33.9), P1 = v(35.0), GEN = v(35.25);
  const open = f >= OPEN && f < PICK + 4, picked = f >= PICK;
  const cur = path(f, [[S + 4, 820, 960], [TAB - 3, 300, 448], [OPEN - 3, 330, 972], [PICK - 3, 330, 930], [AUD - 3, 620, 742], [VID - 3, 740, 590], [IMG - 3, 330, 590], [P1, 620, 850], [GEN - 3, 540, 1040]]);
  return (
    <AbsoluteFill>
      <Head f={f} at={S} />
      <LCard x={110} y={390} w={860} h={700} hot={false}>
        <div style={{position: 'absolute', left: 36, top: 26, display: 'flex', gap: 18, alignItems: 'center', fontFamily: F.ui, fontWeight: 500, fontSize: 27, color: MUTED}}>
          <span style={{padding: '6px 14px'}}>Image</span>
          <span style={{padding: '6px 16px', borderRadius: 12, color: INK, fontWeight: 700, background: '#f1f1f3', boxShadow: f >= TAB - 6 && f < OPEN - 6 ? `0 0 0 3px ${C.claude}` : 'none'}}>Video</span>
          <span style={{padding: '6px 14px'}}>Lip sync</span>
        </div>
        <Slot x={36} y={92} w={384} h={186} label={f >= IMG ? 'Image reference' : 'Image refs'} hot={f >= IMG - 12 && f < IMG + 8}>
          {f >= IMG ? <Img src={staticFile('refs/girl.jpg')} style={{position: 'absolute', left: 14, top: 12, width: 356, height: 132, objectFit: 'cover', borderRadius: 10, transform: `scale(${pop(f, IMG)})`}} /> : undefined}
        </Slot>
        <Slot x={440} y={92} w={384} h={186} label={f >= VID ? 'Video reference' : 'Video refs'} hot={f >= VID - 12 && f < VID + 8}>
          {f >= VID ? <div style={{position: 'absolute', left: 14, top: 12, width: 356, height: 132, borderRadius: 10, overflow: 'hidden', transform: `scale(${pop(f, VID)})`}}><Sequence from={VID} durationInFrames={150} layout="none"><OffthreadVideo src={staticFile('perf.mp4')} muted style={{width: '100%', height: '100%', objectFit: 'cover'}} /></Sequence></div> : undefined}
        </Slot>
        {f >= AUD ? (
          <div style={{position: 'absolute', left: 36, top: 296, width: 788, height: 96, borderRadius: 16, background: '#f3e8ff', boxShadow: `0 0 0 2px ${PURPLE}55`, transform: `scale(${0.9 + 0.1 * pop(f, AUD)})`}}>
            <div style={{position: 'absolute', left: 180, top: 12}}><Wave w={428} h={44} seed={11} color={PURPLE} n={46} /></div>
            <div style={{position: 'absolute', left: 0, right: 0, bottom: 8, textAlign: 'center', fontFamily: F.ui, fontWeight: 700, fontSize: 22, color: INK}}>Dialogo.wav</div>
          </div>
        ) : <Slot x={36} y={296} w={788} h={96} label="Audio refs" hot={f >= AUD - 22} />}
        <Box x={36} y={410} w={788} h={130} r={16}>
          <div style={{padding: '16px 20px', fontFamily: F.ui, fontWeight: 500, fontSize: 25, lineHeight: 1.34, color: f >= P0 ? INK : MUTED}}>{f >= P0 ? typed(GPROMPT, f, P0, P1) : 'Describe your video...'}</div>
        </Box>
        <Box x={36} y={558} w={380} h={62} r={12} hot={f >= OPEN - 4 && f < PICK + 4}>
          <div style={{display: 'flex', alignItems: 'center', height: '100%', padding: '0 18px', fontFamily: F.ui, fontWeight: 700, fontSize: 25, color: INK}}>{picked ? 'Seedance 2.5' : 'Select model'}<span style={{marginLeft: 'auto', color: MUTED}}>⌄</span></div>
        </Box>
        <T x={440} y={574} s={23} c={MUTED}>16:9 · 720p · 6s</T>
        <div style={{position: 'absolute', left: 36, top: 634, width: 788, height: 50, borderRadius: 12, background: INK, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, fontFamily: F.ui, fontWeight: 700, fontSize: 25, color: '#fff', transform: `scale(${1 - press(f, GEN) * 0.04})`, boxShadow: f >= GEN ? `0 0 ${interpolate(f, [GEN, GEN + 8], [0, 40], clamp)}px ${PURPLE}` : 'none'}}>Generate ↑</div>
        {open && (
          <div style={{position: 'absolute', left: 36, top: 356, width: 400, borderRadius: 14, background: '#fff', boxShadow: `0 0 0 1.5px ${LINE}, 0 24px 60px rgba(0,0,0,0.18)`, padding: 8, opacity: ramp(f, OPEN, OPEN + 4)}}>
            {['Seedance 2.0', 'Seedance 2.0 Fast', 'Seedance 2.5'].map((m, i) => <div key={m} style={{height: 62, borderRadius: 10, display: 'flex', alignItems: 'center', gap: 12, padding: '0 16px', fontFamily: F.ui, fontWeight: 700, fontSize: 26, color: INK, background: i === 2 && f >= PICK - 10 ? '#fdeee9' : 'transparent'}}><Logo src="seedance.png" h={22} style={{filter: 'invert(1)'}} />{m}</div>)}
          </div>
        )}
      </LCard>
      {f > S + 4 && f < GEN + 10 && <Cursor x={cur.x} y={cur.y} press={Math.max(press(f, TAB), press(f, OPEN), press(f, PICK), press(f, AUD), press(f, VID), press(f, IMG), press(f, GEN))} />}
    </AbsoluteFill>
  );
};

// 5. Resultado + CTA
const Result: React.FC = () => {
  const f = useCurrentFrame();
  const S = v(35.33), AI = v(37.9), LINK = v(39.0);
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 0, top: 330, width: 1080, height: 608, overflow: 'hidden', opacity: ramp(f, S, S + 6), transform: `scale(${1.05 - 0.05 * ramp(f, S, S + 10)})`}}>
        <Sequence from={S} layout="none"><OffthreadVideo src={staticFile('film_C.mp4')} startFrom={36} playbackRate={0.85} muted style={{width: '100%', height: '100%', objectFit: 'cover'}} /></Sequence>
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: 968, display: 'flex', justifyContent: 'center', gap: 16, alignItems: 'center'}}>
        {f >= AI && <div style={{padding: '14px 34px', borderRadius: 40, background: INK, color: '#fff', fontFamily: F.pop, fontWeight: 700, fontSize: 44, transform: `scale(${pop(f, AI)})`}}>Comenta “AI”</div>}
        {f >= LINK && <div style={{padding: '14px 30px', borderRadius: 40, background: '#f3e8ff', color: '#7e22ce', fontFamily: F.ui, fontWeight: 700, fontSize: 34, transform: `scale(${pop(f, LINK)})`}}>y te mando el link</div>}
      </div>
    </AbsoluteFill>
  );
};

// ---------- sonidos de interfaz (SND Sine) ----------
const ui: [number, string, number][] = [];
const tap = (fr: number, n = 'tap_01', vol = 0.5) => ui.push([Math.round(fr), n, vol]);
const typing = (a: number, b: number, step = 4) => { for (let fr = a, i = 0; fr < b; fr += step, i++) ui.push([fr, `type_0${1 + (i * 7) % 5}`, 0.2]); };
tap(5.0 * 30 + 16, 'tap_03', 0.5);
tap(F0 - 2, 'swipe_01', 0.4); tap(v(0.15), 'transition_up', 0.35);
tap(v(4.23) - 2, 'swipe_02', 0.4); typing(v(4.9), v(8.6)); tap(v(9.15), 'button', 0.55);
tap(v(9.63) - 2, 'swipe_03', 0.4); tap(v(11.6), 'tap_01', 0.55); tap(v(12.47), 'swipe_04', 0.35); tap(v(14.6), 'tap_03', 0.5); tap(v(16.0), 'toggle_on', 0.5);
tap(v(17.5) - 2, 'swipe_05', 0.4); tap(v(18.0), 'tap_01', 0.5); tap(v(18.75), 'select', 0.45); typing(v(19.0), v(20.2), 3); tap(v(21.1), 'button', 0.55);
[5, 11, 17].forEach((d, i) => tap(v(21.1) + d, `tap_0${2 + i}`, 0.4)); tap(v(21.1) + 24, 'toggle_on', 0.4); tap(v(23.6) - 2, 'transition_up', 0.4);
tap(v(24.8) - 2, 'swipe_01', 0.4); tap(v(25.7), 'tap_01', 0.5); tap(v(26.7), 'tap_02', 0.5); tap(v(27.9), 'select', 0.45); tap(v(29.4), 'tap_03', 0.5); tap(v(31.6), 'tap_04', 0.5); tap(v(32.9), 'tap_05', 0.5);
typing(v(33.9), v(35.0), 3); tap(v(35.25), 'button', 0.6); tap(v(35.33) + 2, 'transition_up', 0.4); tap(v(37.9), 'tap_02', 0.5); tap(v(39.0), 'tap_03', 0.45);

export const Edit: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: '#fff'}}>
      {f < F0 + 8 && <div style={{position: 'absolute', inset: 0, opacity: 1 - ramp(f, F0 - 4, F0 + 2)}}><Movie /></div>}
      {f >= F0 - 4 && (
        <AbsoluteFill style={{opacity: ramp(f, F0 - 4, F0 + 2)}}>
          <AbsoluteFill style={{background: '#fff'}} />
          <Scene from={F0 - 4} to={v(4.23)}><Title /></Scene>
          <Scene from={v(4.23)} to={v(9.63)}><VoiceDesign /></Scene>
          <Scene from={v(9.63)} to={v(17.5)}><Clone /></Scene>
          <Scene from={v(17.5)} to={v(24.8)}><Tags /></Scene>
          <Scene from={v(24.8)} to={v(35.33)}><Generator /></Scene>
          <Scene from={v(35.33)} to={TOTAL + 10}><Result /></Scene>
          <Sequence from={F0}><Host /></Sequence>
        </AbsoluteFill>
      )}
      {CLIPS.map((c, i) => <Sequence key={c.id} from={starts[i]} durationInFrames={c.frames}><Audio src={staticFile(`film_${c.id}.wav`)} startFrom={c.from ?? 0} /></Sequence>)}
      <Sequence from={F0}><Audio src={staticFile('voz.wav')} /></Sequence>
      {ui.map(([fr, n, vol], i) => <Sequence key={i} from={Math.max(0, fr)} durationInFrames={45}><Audio src={staticFile(`snd/${n}.wav`)} volume={vol} /></Sequence>)}
    </AbsoluteFill>
  );
};
