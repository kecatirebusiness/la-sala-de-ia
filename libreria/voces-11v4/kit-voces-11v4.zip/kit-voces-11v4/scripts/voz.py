# voz.py <final|expl>: WPE + DeepFilterNet(pf), con respaldo por pieza -> <o>_voz.wav
import pickle, numpy as np, wave, torch, warnings, sys, subprocess, os
warnings.filterwarnings('ignore')
from nara_wpe.wpe import wpe
from nara_wpe.utils import stft, istft
from df.enhance import enhance, init_df
FF=os.path.expanduser("~/Library/Python/3.9/lib/python/site-packages/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1")
o=sys.argv[1]; segs,meta,sr=pickle.load(open(f'src/{o}_raw_pieces.pkl','rb'))
mp, st, _ = init_df(post_filter=True); mn, st2, _ = init_df(post_filter=False)
def W(x):
    Y=stft(x[None], size=1024, shift=256).transpose(2,0,1); Z=wpe(Y, taps=18, delay=3, iterations=4, statistics_mode='full')
    z=istft(Z.transpose(1,2,0), size=1024, shift=256)[0][:len(x)]; return np.pad(z,(0,max(0,len(x)-len(z))))
def D(m,s,z): return enhance(m, s, torch.from_numpy(z.astype(np.float32))[None], atten_lim_db=None)[0].numpy()
def env(x):
    hop=int(sr*0.05); return np.array([20*np.log10(np.sqrt(np.mean(x[i:i+hop]**2))+1e-9) for i in range(0,len(x)-hop,hop)])
out=[]
for k,(x,(h,n)) in enumerate(zip(segs,meta)):
    x=x.astype(np.float64); base=D(mn,st2,x)[h:h+n]; eb=env(base); loud=eb>np.percentile(eb,60)
    use='base'; e=base
    for name,cand in (('wpe+pf',lambda: D(mp,st,W(x))[h:h+n]),('pf',lambda: D(mp,st,x)[h:h+n])):
        c=cand(); ec=env(c); off=np.median((ec-eb)[loud]); worst=((ec-eb)[loud]-off).min()
        if worst>-5: e=c*10**((np.median(eb[loud])-np.median(ec[loud]))/20); use=name; break
    e=e.copy(); f=int(0.012*sr); e[:f]*=np.linspace(0,1,f); e[-f:]*=np.linspace(1,0,f); out.append(e); print(k,use,flush=True)
v=np.concatenate(out); w=wave.open(f'{o}_voz_raw.wav','wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes((np.clip(v/np.abs(v).max()*0.5,-1,1)*32767).astype(np.int16).tobytes()); w.close()
subprocess.run([FF,"-v","error","-y","-i",f"{o}_voz_raw.wav","-af","highpass=f=85,equalizer=f=380:t=q:w=1.1:g=-3.5,equalizer=f=3400:t=q:w=1.2:g=2.5,agate=threshold=0.045:ratio=2.2:range=0.22:attack=2:release=110:knee=4,deesser=i=0.3,acompressor=threshold=-20dB:ratio=2.5:attack=10:release=140:makeup=3,loudnorm=I=-16:TP=-1.5:LRA=7","-ar","48000","-ac","1",f"{o}_voz.wav"],check=True)
