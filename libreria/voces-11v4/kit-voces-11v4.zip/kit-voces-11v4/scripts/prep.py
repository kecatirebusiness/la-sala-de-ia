# prep.py: EDL + A-roll (video+voz) para "final" (tutorial) y "expl" (recuadro)
import numpy as np, wave, json, subprocess, os, pickle
FF=os.path.expanduser("~/Library/Python/3.9/lib/python/site-packages/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1")
SRC={"final":"TU-TUTORIAL.mp4","expl":"TU-ACTUACION.mp4"}
PICK={"final":[3,4,5,6,9,13,15,16,22,23,30,32,33,37],"expl":[14]}
GRADE="curves=all='0/0 0.10/0.045 0.28/0.33 0.52/0.66 0.78/0.89 1/1',eq=saturation=1.28,colorbalance=rm=0.05:bm=-0.06:rs=0.015:bs=-0.02,unsharp=5:5:0.45"
CROP={"final":"crop=2160:2160:920:0,scale=1080:1080:flags=lanczos","expl":"crop=2400:1350:780:810,scale=1280:720:flags=lanczos"}
sr=16000; hop=80; win=320
for o in ("final","expl"):
    S=json.load(open(f'src/{o}_segs.json'))
    wf=wave.open(f'src/{o}_clean16k.wav'); a=np.frombuffer(wf.readframes(wf.getnframes()),dtype=np.int16).astype(np.float32)/32768
    pieces=[]
    for i in PICK[o]:
        s=S[i]; t0=s['s']-0.15; t1=s['e']+0.2
        i0=int(t0*sr); n=(int(t1*sr)-i0-win)//hop
        d=np.array([20*np.log10(np.sqrt(np.mean(a[i0+k*hop:i0+k*hop+win]**2))+1e-9) for k in range(n)]); act=d>-62
        reg=[];st=None
        for k,v in enumerate(act):
            if v and st is None: st=k
            if not v and st is not None: reg.append([t0+st*hop/sr,t0+k*hop/sr]); st=None
        if st is not None: reg.append([t0+st*hop/sr,t0+len(act)*hop/sr])
        reg=[r for r in reg if r[1]-r[0]>0.04]; m=[]
        for r in reg:
            if m and r[0]-m[-1][1]<0.22: m[-1][1]=r[1]
            else: m.append(r)
        ch=True
        while ch and len(m)>1:
            ch=False
            for k,r in enumerate(m):
                if r[1]-r[0]<0.6:
                    j=1 if k==0 else (k-1 if k==len(m)-1 else (k-1 if r[0]-m[k-1][1]<=m[k+1][0]-r[1] else k+1))
                    lo,hi=min(k,j),max(k,j); m[lo]=[m[lo][0],m[hi][1]]; del m[hi]; ch=True; break
        for r in m: pieces.append({"seg":i,"text":s['text'],"s":round(r[0]-0.05,3),"e":round(r[1]+0.07,3)})
    t=0
    for p in pieces: p['n']=round((p['e']-p['s'])*30); p['t']=round(t/30,4); t+=p['n']
    json.dump(pieces,open(f'{o}_edl.json','w'),indent=1,ensure_ascii=False)
    print(o,len(pieces),"piezas",t/30,"s")
    os.makedirs(f'pz_{o}',exist_ok=True); lst=[]
    w48=wave.open(f'src/{o}48k.wav'); raw=np.frombuffer(w48.readframes(w48.getnframes()),dtype=np.int16).astype(np.float32)/32768
    segs=[];meta=[]
    for k,p in enumerate(pieces):
        v=f"pz_{o}/v{k:02d}.mp4"; d=p['n']/30
        subprocess.run([FF,"-nostdin","-v","error","-y","-ss",f"{p['s']:.4f}","-i",SRC[o],"-t",f"{d+0.2:.4f}","-an","-vf",CROP[o]+","+GRADE+",fps=30","-frames:v",str(p['n']),"-c:v","h264_videotoolbox","-b:v","18M","-pix_fmt","yuv420p",v],check=True)
        lst.append(v); H=0.6
        segs.append(raw[int((p['s']-H)*48000):int((p['s']+d+H)*48000)]); meta.append((int(H*48000),int(d*48000)))
    open(f'pz_{o}/v.txt','w').write("".join(f"file '{os.path.basename(v)}'\n" for v in lst))
    subprocess.run([FF,"-v","error","-y","-f","concat","-safe","0","-i",f"pz_{o}/v.txt","-vf","setpts=N/30/TB","-r","30","-c:v","h264_videotoolbox","-b:v","16M","-pix_fmt","yuv420p","-an",f"{o}_aroll.mp4"],check=True)
    pickle.dump((segs,meta,48000),open(f'src/{o}_raw_pieces.pkl','wb'))
