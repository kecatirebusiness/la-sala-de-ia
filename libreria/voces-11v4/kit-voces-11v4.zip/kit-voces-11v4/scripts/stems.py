# no-vocals (efectos y ambiente) de cada clip generado + efectos de la referencia por escena
import torch, wave, numpy as np, subprocess, os
from demucs.pretrained import get_model
from demucs.apply import apply_model
FF=os.path.expanduser("~/Library/Python/3.9/lib/python/site-packages/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1")
m=get_model('htdemucs'); m.eval()
def sep(src,dst):
    subprocess.run([FF,"-v","error","-y","-i",src,"-vn","-ar","44100","-ac","2","_s.wav"],check=True)
    w=wave.open("_s.wav"); a=np.frombuffer(w.readframes(w.getnframes()),dtype=np.int16).reshape(-1,2).T.astype(np.float32)/32768
    with torch.no_grad(): out=apply_model(m,torch.from_numpy(a)[None],device='cpu',shifts=1,split=True,overlap=0.25)[0]
    nv=(out[0]+out[1]+out[2]).numpy().T
    f=wave.open(dst,'wb'); f.setnchannels(2); f.setsampwidth(2); f.setframerate(44100); f.writeframes((np.clip(nv,-1,1)*32767).astype(np.int16).tobytes()); f.close()
    print(dst, round(float(20*np.log10(np.sqrt((nv**2).mean())+1e-9)),1),"dB")
for c,src in (("A","v2/gA.mp4"),("B","v2/gB.mp4"),("C","film/gC.mp4"),("D","film/gD.mp4")): sep(src,f"v2/fx_{c}.wav")
