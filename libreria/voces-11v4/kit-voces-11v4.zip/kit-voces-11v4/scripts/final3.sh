#!/bin/zsh
# final3.sh <salida.mp4> : render + música de la referencia (entra cuando se quita la máscara) + -14 LUFS
set -e
cd ~/Videos-editor/replica-11v4
FF=~/Library/Python/3.9/lib/python/site-packages/imageio_ffmpeg/binaries/ffmpeg-macos-aarch64-v7.1
D="./salida"
export PATH=~/.local/node/bin:$PATH
(cd remo && npx remotion render src/index.ts Edit out/raw.mp4 --crf=17 > out/render.log 2>&1)
L=$($FF -hide_banner -ss 6 -t 30 -i musica/pista3.wav -af ebur128 -f null - 2>&1 | grep -E "^\s+I:" | tail -1 | awk '{print $2}')
V=$($FF -hide_banner -ss 44 -t 34 -i remo/out/raw.mp4 -af ebur128 -f null - 2>&1 | grep -E "^\s+I:" | tail -1 | awk '{print $2}')
G=$(python3 -c "print(round(($V-8.5)-($L),2))")
$FF -v error -y -i remo/out/raw.mp4 -itsoffset 37.8 -i musica/pista3.wav -filter_complex "[1:a]volume=${G}dB,aresample=48000[m];[0:a][m]amix=inputs=2:normalize=0:duration=first,loudnorm=I=-14:TP=-1.5:LRA=11[a]" -map 0:v -map "[a]" -c:v libx264 -crf 18 -preset medium -pix_fmt yuv420p -vf "scale=in_range=pc:out_range=tv" -color_range tv -c:a aac -b:a 256k -ar 48000 -movflags +faststart "$D/$1"
$FF -hide_banner -i "$D/$1" 2>&1 | grep Duration
echo "voz $V musica $L ganancia $G"
