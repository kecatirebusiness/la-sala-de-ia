# Instalar

Los comandos que empiezan con / se escriben dentro de Claude Code. Los demás, en la terminal (o pídeselos a Claude Code). Después de instalar plugins: /reload-plugins.

## remotion-dev/remotion
https://github.com/remotion-dev/remotion

```
npx create-video@latest
```

## heygen-com/hyperframes
https://github.com/heygen-com/hyperframes

```
npx skills add heygen-com/hyperframes
```

## openai/whisper
https://github.com/openai/whisper

```
pip install -U openai-whisper
```

## yt-dlp/yt-dlp
https://github.com/yt-dlp/yt-dlp

```
python -m pip install -U "yt-dlp[default]"
```

