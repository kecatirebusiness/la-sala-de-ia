# Edita tus videos con Claude: el proceso completo, gratis

Una carpeta, cinco herramientas gratis y tres prompts. De la carpeta vacía a un reel terminado con tus cortes, tus subtítulos y tu estilo, sin pagar un curso.

Receta completa: https://lasaladeia.com/libreria/editar-videos-con-claude/

Claude no edita solo: necesita herramientas. Remotion y HyperFrames arman el video y los gráficos, FFmpeg corta y exporta, Whisper hace los subtítulos y yt-dlp baja tus videos de referencia. No las instalas tú: se lo pides a Claude. Luego le enseñas tu gusto con 3 a 5 videos que te encanten (para inspirarse, no para copiar) y de ahí en adelante sueltas tu grabación y le dices qué cambiar como se lo dirías a un editor.

**Costo:** Claude Code viene con los planes de pago de Claude (Pro o Max). Las cinco herramientas son gratis y de código abierto (Remotion pide licencia solo a empresas más grandes)

**Tiempo:** 30 minutos para dejarlo montado. Después, cada video es soltar el archivo y un prompt

## Herramientas
- Claude (app de escritorio): Descárgala y abre la pestaña Code. Así Claude puede ver y usar los archivos de tu carpeta. https://claude.com/download
- FFmpeg: El que corta, une, convierte y exporta. Claude lo usa por debajo. https://ffmpeg.org
- La Sala de IA: Aquí editamos así todos nuestros reels y te enseñamos el proceso en vivo. https://lasaladeia.com/?utm_source=libreria

## Repos
- remotion-dev/remotion: https://github.com/remotion-dev/remotion
- heygen-com/hyperframes: https://github.com/heygen-com/hyperframes
- openai/whisper: https://github.com/openai/whisper
- yt-dlp/yt-dlp: https://github.com/yt-dlp/yt-dlp

## Qué hay en este kit
- instalar.md: los comandos de instalación.
- prompts/: un archivo por paso con sus prompts.
