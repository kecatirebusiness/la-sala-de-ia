# Mi editor de video

Esta carpeta es mi editor de video.
- Grabaciones/: mis videos crudos. El más nuevo es el que toca editar.
- Referencias/: videos que me gustan. Solo para inspirarte, nunca para copiar.
- Exportados/: los videos terminados.

Reglas:
- Sigue siempre MI-ESTILO.md.
- Herramientas: Remotion y HyperFrames (armar y gráficos), FFmpeg (cortar y exportar), Whisper (subtítulos), yt-dlp (referencias).
- Formato vertical 1080x1920 salvo que te diga otra cosa.
- Antes de exportar, enséñame un resumen y unos fotogramas.
- Música solo libre de derechos.
