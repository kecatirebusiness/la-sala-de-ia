# MI ESTILO (Claude lo llena con el prompt 2)

## Ritmo de los cortes

## Subtítulos (letra, tamaño, posición, color)

## Colores y letras

## Movimiento y gráficos

## Música

## Los primeros 3 segundos

## Cosas que siempre quiero

## Cosas que nunca quiero
