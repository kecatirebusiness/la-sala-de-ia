# 05 · Pide cambios como a un editor

Si algo no te gusta, díselo normal: «haz el gancho más grande», «los subtítulos más abajo», «quita la música en la parte donde hablo del precio». Las herramientas cortan, pero tu gusto hace el resto. Para la música usa una biblioteca libre de derechos (o la de Instagram/TikTok al publicar), nunca canciones con copyright dentro del video.

## Prompt para Claude Code: ronda de cambios

```
Revisé el video. Cambia esto:
1. [EJ: haz el texto del gancho más grande y que entre en el primer segundo]
2. [EJ: sube los subtítulos, me tapan la boca]
3. [EJ: corta la parte de 0:22 a 0:27]
Si alguno de estos cambios es algo que siempre quiero, anótalo en MI-ESTILO.md para la próxima. Enséñame los fotogramas de cada cambio y vuelve a exportar a Exportados.
```

