# 04 · Prompt 3: edita tu video

Graba como siempre y suelta el archivo en Grabaciones. Claude corta los silencios y las equivocaciones, pone subtítulos y música y te enseña fotogramas para revisar antes de exportar.

## Prompt 3 · Edita mi video

```
Edita el video más nuevo de la carpeta Grabaciones siguiendo MI-ESTILO.md. Corta los silencios y las equivocaciones, pon subtítulos con Whisper, agrega música de fondo baja (usa una pista libre de derechos que yo te dé, o pregúntame) y gráficos donde ayuden a entender. Formato vertical 1080×1920. Antes de exportar, enséñame un resumen de lo que hiciste y unos fotogramas para revisar. Cuando te diga qué cambiar, arréglalo y exporta el final a la carpeta Exportados.
```

