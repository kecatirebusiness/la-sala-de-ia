# 03 · Prompt 2: enséñale tu gusto

Ya puede editar, pero no sabe qué te gusta. Escoge de 3 a 5 videos con el estilo que quieres y pega los links. La línea más importante es «inspírate en ellos, no los copies»: eso es lo que evita que tus videos se vean como los de todo el mundo. Lo que aprende queda en MI-ESTILO.md y lo usa en todos tus videos.

## Prompt 2 · Aprende mi gusto

```
Estos son los videos con el estilo que me gusta: [LINK 1] [LINK 2] [LINK 3] [LINK 4]. Bájalos a la carpeta Referencias y estúdialos: ritmo de los cortes, estilo y tamaño de los subtítulos, colores, letras, movimiento, música y cómo arrancan los primeros 3 segundos. Inspírate en ellos, no los copies: no repitas sus textos, sus gráficos ni su música. Escribe lo que aprendiste en un archivo MI-ESTILO.md y úsalo en todos mis videos, con mi cara, mi voz y mi marca.
```

