# 02 · Prompt 1: que instale sus 5 herramientas

Remotion y HyperFrames arman el video y los gráficos, FFmpeg corta y exporta, Whisper hace los subtítulos y yt-dlp baja tus videos de referencia. No instalas nada tú: pégale este prompt y dale permiso en cada paso.

## Prompt 1 · Instala mis herramientas

```
Quiero usar esta carpeta como mi editor de video. Instala y configura en esta computadora: Remotion (para armar videos), HyperFrames (gráficos animados), FFmpeg (cortar y exportar), Whisper (subtítulos) y yt-dlp (bajar videos de referencia). Usa las carpetas Grabaciones, Referencias y Exportados. Pídeme permiso antes de instalar cada cosa. Al terminar, prueba cada herramienta con un ejemplo corto y dime qué quedó instalado y si algo falló.
```

