G=[
 [(0.00,"Estos agentes de IA hacen más de mil videos UGC a la semana."),(3.48,"Aquí está el mapa.")],
 [(4.76,"Tendencias."),(5.96,"Catorce agentes ven TikTok y Reels todo el día"),(8.68,"y traen los formatos y hooks que funcionan hoy.")],
 [(11.32,"Guiones."),(12.66,"Entra un brief y salen cincuenta hooks,"),(15.24,"cada uno con otro ángulo.")],
 [(16.60,"Creadores."),(17.40,"Cada guion recibe un avatar de IA que va con el producto,"),(19.84,"y tú eliges las caras de la marca.")],
 [(22.04,"Voz y edición hacen el resto:"),(23.70,"voz, cortes, subtítulos y música."),(26.04,"Casi doscientos videos al día.")],
 [(27.84,"Variantes."),(28.32,"Un video se vuelve veinte, cada uno con otros tres primeros segundos."),(31.82,"Publicación los sube a TikTok, Reels y Shorts.")],
 [(35.16,"Testing mira los números."),(36.78,"Los ganadores reciben presupuesto."),(38.18,"Los perdedores se pausan."),(39.62,"Nada sale sin tu sí."),(41.66,"Un toque desde tu teléfono.")],
 [(42.96,"Comenta UGC y te mando el mapa completo.")],
]
