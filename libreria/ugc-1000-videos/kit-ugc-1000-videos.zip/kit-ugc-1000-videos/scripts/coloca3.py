# v3: cada bloque de ElevenLabs se usa ENTERO (flujo natural, sin cortar frases).
# Solo se acortan silencios largos (>0.38 s -> 0.26 s) cortando en el centro del silencio con crossfade.
import json, wave, numpy as np
fr=json.load(open('vo/frases.json'))
SR=48000; HOP=int(0.01*SR); XF=int(0.02*SR)
GAP={0:0,1:0.3,2:0.3,3:0.3,4:0.3,5:0.3,6:0.3,7:0.35}
out=[]; res=[]; t=0.15; out=np.zeros(int(SR*0.15),np.float32)
for gi in range(8):
    g=np.frombuffer(wave.open(f'vo/g{gi}.wav').readframes(10**9),dtype=np.int16).astype(np.float32)/32768
    n=len(g)//HOP; e=np.array([np.sqrt(np.mean(g[i*HOP:(i+1)*HOP]**2)) for i in range(n)])
    thr=max(e.max()*0.015,1e-4); on=np.where(e>thr)[0]
    a0=max(0,on[0]*HOP-int(0.02*SR)); a1=min(len(g),(on[-1]+1)*HOP+int(0.12*SR))
    q=e<thr*1.3; cuts=[]; i=on[0]
    while i<=on[-1]:
        if q[i]:
            j=i
            while j<=on[-1] and q[j]: j+=1
            L=(j-i)*HOP
            if L>0.25*SR:
                rm=L-int(0.17*SR); c0=i*HOP+int(0.085*SR); cuts.append((c0,rm))
            i=j
        else: i+=1
    segs=[]; st=a0
    for c0,rm in cuts: segs.append((st,c0)); st=c0+rm
    segs.append((st,a1))
    y=np.zeros(0,np.float32)
    for p,qq in segs:
        piece=g[p:qq].copy()
        if len(y)>XF and len(piece)>XF:
            r=np.linspace(0,1,XF); y[-XF:]=y[-XF:]*(1-r)+piece[:XF]*r; y=np.concatenate([y,piece[XF:]])
        else: y=np.concatenate([y,piece])
    k=int(0.005*SR); y[:k]*=np.linspace(0,1,k); k=int(0.05*SR); y[-k:]*=np.linspace(1,0,k)
    if gi>0: out=np.concatenate([out,np.zeros(int(GAP[gi]*SR),np.float32)])
    base=len(out)/SR
    def mp(tg):
        s=tg*SR; rem=a0
        for c0,rm in cuts:
            if s>=c0+rm: rem+=rm-XF
            elif s>c0: s=c0
        return base+(s-rem)/SR
    for f in [f for f in fr if f['g']==gi]:
        wt=[(w,round(mp(x),3),round(mp(z),3)) for w,x,z in f['words']]
        res.append(dict(anc=f['anc'],start=wt[0][1],end=wt[-1][2],text=f['text'],words=wt))
    out=np.concatenate([out,y])
tot=len(out)/SR+1.0; out=np.concatenate([out,np.zeros(SR,np.float32)])
w=wave.open('vo/voz3.wav','wb'); w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes((np.clip(out,-1,1)*32767).astype(np.int16).tobytes()); w.close()
json.dump(dict(total=round(tot,3),frases=res),open('vo/tiempos3.json','w'),ensure_ascii=False)
print('total',round(tot,2))
