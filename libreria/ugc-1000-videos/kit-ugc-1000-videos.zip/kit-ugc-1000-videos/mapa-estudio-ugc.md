# Mapa del estudio UGC · 8 equipos, 112 agentes

Empieza por Guiones + Creadores + Voz + Edición: con esos 4 ya salen videos. Suma el resto cuando tengas los primeros ganadores.

## Tendencias · 14 agentes

| Agente principal | Herramienta | ¿Lo monto? |
|---|---|---|
| Escáner de tendencias | TikTok | [ ] |
| Minero de hooks | Instagram | [ ] |
| Detector de formatos | YouTube | [ ] |
| Lector de Ad Library | Meta Ads | [ ] |
| +10 agentes más del mismo tipo (uno por formato, red o marca) | | |

## Guiones y hooks · 22 agentes

| Agente principal | Herramienta | ¿Lo monto? |
|---|---|---|
| Escritor de hooks | Claude | [ ] |
| Guionista | Claude | [ ] |
| +20 agentes más del mismo tipo (uno por formato, red o marca) | | |

## Creadores IA · 18 agentes

| Agente principal | Herramienta | ¿Lo monto? |
|---|---|---|
| Casting de avatares | Higgsfield | [ ] |
| Vestuario y set | Google Drive | [ ] |
| Revisa el lip-sync | Higgsfield | [ ] |
| +15 agentes más del mismo tipo (uno por formato, red o marca) | | |

## Voz · 9 agentes

| Agente principal | Herramienta | ¿Lo monto? |
|---|---|---|
| Casting de voces | ElevenLabs | [ ] |
| Director de lectura | ElevenLabs | [ ] |
| Control de ritmo | Claude | [ ] |
| +6 agentes más del mismo tipo (uno por formato, red o marca) | | |

## Edición · 16 agentes

| Agente principal | Herramienta | ¿Lo monto? |
|---|---|---|
| Cortador | Remotion | [ ] |
| Subtítulos | Claude + faster-whisper | [ ] |
| Elige el b-roll | Google Drive | [ ] |
| Música | YouTube Audio Library | [ ] |
| +12 agentes más del mismo tipo (uno por formato, red o marca) | | |

## Variantes · 12 agentes

| Agente principal | Herramienta | ¿Lo monto? |
|---|---|---|
| Cambia hooks | Claude + Remotion | [ ] |
| +11 agentes más del mismo tipo (uno por formato, red o marca) | | |

## Publicación · 10 agentes

| Agente principal | Herramienta | ¿Lo monto? |
|---|---|---|
| Programador | Metricool / TikTok | [ ] |
| Sube anuncios | Meta Ads | [ ] |
| +8 agentes más del mismo tipo (uno por formato, red o marca) | | |

## Testing · 11 agentes

| Agente principal | Herramienta | ¿Lo monto? |
|---|---|---|
| Probador de hooks | Meta Ads | [ ] |
| Elige ganadores | Google Analytics | [ ] |
| Mueve presupuesto | Meta Ads (con tu sí) | [ ] |
| +8 agentes más del mismo tipo (uno por formato, red o marca) | | |
