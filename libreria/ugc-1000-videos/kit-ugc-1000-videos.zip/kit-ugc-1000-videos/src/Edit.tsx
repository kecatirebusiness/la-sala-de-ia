import React from 'react';
import {AbsoluteFill, Audio, Img, staticFile, useCurrentFrame, interpolate} from 'remotion';
import {C, F, FPS, MONO, SANS, fontCss, WORDS, tw, on, Ico} from './theme';

const BG = '#EEEEEB';
const RED = '#E5484D', BLUE = '#2F7BEA', TEAL = '#16A085', ORANGE = '#E8743B', PURPLE = '#8B5CF6', GOLD = '#B8860B';
const W = 720;

// ---------- datos ----------
const CAT = ['belleza', 'suplementos', 'mascotas', 'belleza', 'jugos', 'skincare', 'ropa hombre', 'podcast', 'cuidado personal', 'skincare', 'suplementos', 'mascotas', 'cuidado personal', 'comida', 'belleza', 'vitaminas', 'ropa', 'café', 'maquillaje', 'skincare'];
const ug = (i: number) => staticFile(`ugc/u${String(i % 20).padStart(2, '0')}.jpg`);
const FACES = [0, 1, 3, 4, 5, 6, 7, 9, 10, 12, 14, 15, 16, 17, 18];
const HOOKS = ['espera, ¿costaba $19?', 'mi dermatóloga me preguntó', 'POV: día 14', 'nadie habla de esto', '3 cosas que ojalá supiera', 'dejé de comprar 5', 'esto reemplazó mi rutina', 'ok, entiendo el hype', 'no lo compres si…', 'reseña honesta', 'mi mamá me lo robó', 'el antes es duro', 'mira hasta el final', 'más barato que un café', 'me equivoqué', 'lo probé por ti', 'el que sí funcionó', 'mi rutina de las 6am', 'los comentarios tenían razón', 'se agotó dos veces'];

type Dept = {k: string; t: string; n: string; c: string; x: number; y: number; w: number; rows: [string, string][]; more?: string};
const DEPTS: Dept[] = [
  {k: 'trend', t: 'TENDENCIAS', n: '14 agentes', c: ORANGE, x: 80, y: 305, w: 86, rows: [['tiktok', 'Escáner de tendencias'], ['instagram', 'Minero de hooks'], ['youtube', 'Detector de formatos'], ['meta', 'Lector de Ad Library']]},
  {k: 'test', t: 'TESTING', n: '11 agentes', c: TEAL, x: 80, y: 415, w: 86, rows: [['meta', 'Probador de hooks'], ['ganalytics', 'Elige ganadores'], ['meta', 'Mueve presupuesto']]},
  {k: 'pub', t: 'PUBLICACIÓN', n: '10 agentes', c: GOLD, x: 80, y: 522, w: 86, rows: [['tiktok', 'Programador'], ['meta', 'Sube anuncios']], more: '+8 agentes más'},
  {k: 'crea', t: 'CREADORES IA', n: '18 agentes', c: PURPLE, x: 555, y: 305, w: 86, rows: [['higgsfield', 'Casting de avatares'], ['gdrive', 'Vestuario y set'], ['higgsfield', 'Revisa el lip-sync']], more: '+15 agentes más'},
  {k: 'voice', t: 'VOZ', n: '9 agentes', c: TEAL, x: 555, y: 415, w: 86, rows: [['elevenlabs', 'Casting de voces'], ['elevenlabs', 'Director de lectura'], ['claude', 'Control de ritmo']]},
  {k: 'edit', t: 'EDICIÓN', n: '16 agentes', c: BLUE, x: 555, y: 522, w: 86, rows: [['remotion', 'Cortador'], ['claude', 'Subtítulos'], ['gdrive', 'Elige el b-roll'], ['youtube', 'Música']]},
];
const SRC: [string, string][] = [['notion', 'Brief de marca'], ['gdocs', 'Página del producto'], ['meta', 'Anuncios pasados'], ['tiktok', 'Tendencias TikTok'], ['gsheets', 'Reseñas'], ['gdrive', 'Voz de marca'], ['instagram', 'Biblioteca de Reels'], ['meta', 'Cuenta de anuncios']];
const HUB = {x: 355, y: 452};
const LABELS: [string, number, number][] = [['GUIONES', 355, 342], ['CREADORES', 468, 375], ['VOZ', 488, 469], ['EDICIÓN', 442, 535], ['VARIANTES', 355, 564], ['PUBLICACIÓN', 236, 527], ['TESTING', 221, 438], ['TENDENCIAS', 252, 375]];

// ---------- piezas ----------
const Tile: React.FC<{i: number; x: number; y: number; w?: number; h?: number; f: number; border?: string; badge?: string; empty?: boolean; dim?: number}> = ({i, x, y, w = 62, h = 110, f, border, badge, empty, dim = 0}) => {
  if (empty) return <div style={{position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: 6, border: `1.5px dashed ${RED}`, background: '#fff', boxSizing: 'border-box'}}/>;
  const z = 1.06 + Math.sin(f / 40 + i) * 0.05;
  return <div style={{position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: 6, overflow: 'hidden', background: '#ccc', boxShadow: border ? `0 0 0 2px ${border}` : undefined, opacity: 1 - dim}}>
    <Img src={ug(i)} style={{width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${z}) translateY(${Math.sin(f / 23 + i * 2) * 2}px)`}}/>
    <div style={{position: 'absolute', left: 3, top: 3, padding: '0 3px', borderRadius: 3, background: 'rgba(0,0,0,.55)', color: '#fff', fontFamily: MONO, fontSize: 4.6}}>ugc-{String((i * 7) % 20 + 1).padStart(2, '0')}</div>
    <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, padding: '8px 3px 2px', background: 'linear-gradient(transparent, rgba(0,0,0,.55))', color: '#fff', fontFamily: SANS, fontSize: 4.6}}>{CAT[i % 20]}</div>
    {badge && <div style={{position: 'absolute', left: 0, right: 0, bottom: 10, textAlign: 'center'}}><span style={{padding: '1px 4px', borderRadius: 2, background: border, color: '#fff', fontFamily: MONO, fontWeight: 700, fontSize: 4.4}}>{badge}</span></div>}
  </div>;
};

const DeptCard: React.FC<{d: Dept; hi?: boolean; dim: number}> = ({d, hi, dim}) => (
  <div style={{position: 'absolute', left: d.x, top: d.y, width: d.w, borderRadius: 6, background: '#fff', border: `1px solid ${hi ? d.c : '#e1e1de'}`, boxShadow: hi ? `0 0 0 2px ${d.c}55, 0 4px 14px rgba(0,0,0,.12)` : '0 1px 2px rgba(0,0,0,.05)', padding: '5px 5px 3px', boxSizing: 'border-box', opacity: hi ? 1 : 1 - dim, transform: hi ? 'scale(1.08)' : undefined, transformOrigin: 'center', zIndex: hi ? 5 : 1}}>
    <div style={{display: 'flex', alignItems: 'center', gap: 3, fontFamily: SANS, fontWeight: 800, fontSize: 6.2, color: C.ink}}><span style={{width: 4, height: 4, borderRadius: 2, background: d.c}}/>{d.t}</div>
    <div style={{fontFamily: SANS, fontSize: 5, color: d.c, marginLeft: 7, marginBottom: 3}}>{d.n}</div>
    {d.rows.map(([l, t], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 3, height: 15, borderTop: '1px solid #f0f0ee', fontFamily: SANS, fontSize: 5.2, color: '#333', boxShadow: hi && i === 0 ? `inset 0 0 0 1px ${d.c}` : undefined, borderRadius: 3, paddingLeft: 2}}><Ico n={l} s={8}/>{t}</div>)}
    {d.more && <div style={{fontFamily: SANS, fontSize: 4.8, color: '#888', marginTop: 2}}>{d.more}</div>}
  </div>
);

const Small: React.FC<{x: number; y: number; w: number; c: string; t: string; n: string; rows: [string, string][]; more?: string; hi?: boolean; dim: number}> = ({x, y, w, c, t, n, rows, more, hi, dim}) => (
  <div style={{position: 'absolute', left: x, top: y, width: w, borderRadius: 6, background: '#fff', border: `1px solid ${hi ? c : '#e1e1de'}`, boxShadow: hi ? `0 0 0 2px ${c}55` : undefined, padding: '4px 6px', boxSizing: 'border-box', opacity: hi ? 1 : 1 - dim, zIndex: hi ? 5 : 1}}>
    <div style={{display: 'flex', alignItems: 'center', gap: 3, fontFamily: SANS, fontWeight: 800, fontSize: 6.2}}><span style={{width: 4, height: 4, borderRadius: 2, background: c}}/>{t}<span style={{flex: 1}}/><span style={{color: c, fontWeight: 500, fontSize: 5}}>{n}</span></div>
    <div style={{display: 'flex', gap: 10, marginTop: 4}}>{rows.map(([l, tt], i) => <div key={i} style={{display: 'flex', alignItems: 'center', gap: 3, fontFamily: SANS, fontSize: 5.2, padding: '1px 3px', borderRadius: 3, boxShadow: hi && i === 0 ? `inset 0 0 0 1px ${c}` : undefined}}><Ico n={l} s={8}/>{tt}</div>)}{more && <span style={{fontFamily: SANS, fontSize: 5, color: '#888'}}>{more}</span>}</div>
  </div>
);

// grafo central (puntitos que se mueven)
const Graph: React.FC<{f: number; dim: number}> = ({f, dim}) => {
  const t = f / FPS;
  const nodes = Array.from({length: 8}).map((_, i) => { const a = (i / 8) * Math.PI * 2 - Math.PI / 2; return [HUB.x + Math.cos(a) * 52, HUB.y + Math.sin(a) * 50, a] as const; });
  return <svg style={{position: 'absolute', left: 0, top: 0, opacity: 1 - dim * 0.7}} width={W} height="1280">
    <circle cx={HUB.x} cy={HUB.y} r="88" fill="none" stroke="#d9d9d5" strokeDasharray="1 3"/>
    {nodes.map(([x, y, a], i) => <g key={i}>
      <line x1={HUB.x} y1={HUB.y} x2={x} y2={y} stroke="#bbb" strokeWidth=".6"/>
      {Array.from({length: 14}).map((_, k) => { const aa = a + (k / 14 - 0.5) * 1.3 + Math.sin(t * 0.7 + k) * 0.03; const r = 22 + (k % 4) * 7 + Math.sin(t + k * 1.7 + i) * 1.5; const px = x + Math.cos(aa) * r, py = y + Math.sin(aa) * r; return <g key={k}><line x1={x} y1={y} x2={px} y2={py} stroke="#444" strokeWidth=".35"/><circle cx={px} cy={py} r={1.6} fill="#222"/></g>; })}
      <circle cx={x} cy={y} r="6.5" fill="#fff" stroke={[RED, RED, PURPLE, TEAL, BLUE, RED, GOLD, TEAL][i]} strokeWidth="1"/>
      <text x={x} y={y + 2} textAnchor="middle" fontSize="5" fontFamily="JBM" fill={[RED, RED, PURPLE, TEAL, BLUE, RED, GOLD, TEAL][i]}>0{i + 1}</text>
    </g>)}
    <circle cx={HUB.x} cy={HUB.y} r="28" fill="#fff" stroke="#999" strokeWidth="1"/>
    <text x={HUB.x} y={HUB.y - 3} textAnchor="middle" fontSize="7.5" fontWeight="800" fontFamily="Inter" fill={C.ink}>ESTUDIO</text>
    <text x={HUB.x} y={HUB.y + 5} textAnchor="middle" fontSize="7.5" fontWeight="800" fontFamily="Inter" fill={C.ink}>UGC IA</text>
    <text x={HUB.x} y={HUB.y + 13} textAnchor="middle" fontSize="4.3" fontFamily="Inter" fill={RED}>112 agentes de IA</text>
    {LABELS.map(([l, x, y]) => <text key={l} x={x} y={y} textAnchor="middle" fontSize="6.6" letterSpacing="1.5" fontFamily="Georgia, serif" fill="#555">{l}</text>)}
    {/* flechas de las tarjetas a las etiquetas */}
    <g stroke="#999" strokeWidth=".7" fill="none">
      <path d={`M166 375 H215`} stroke={ORANGE}/><path d={`M166 438 H195`} stroke={TEAL}/><path d={`M166 527 H200`} stroke={GOLD}/>
      <path d={`M555 375 H505`} stroke={PURPLE}/><path d={`M555 469 H505`} stroke={TEAL}/><path d={`M555 535 H470`} stroke={BLUE}/>
    </g>
  </svg>;
};

const nfmt = (n: number) => Math.round(n).toLocaleString('en-US');
const videos = (f: number) => interpolate(f, [F(0), F(31.5)], [1080, 1240], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

const Stats: React.FC<{f: number; mode: 'base' | 'pub'}> = ({f, mode}) => {
  const hooks = on(f, 13.4) ? 3720 : 3400, win = on(f, 37.0) ? 23 : 18, spend = on(f, 37.0) ? 1800 : 900;
  const hiV = (on(f, 22.0) && !on(f, 27.8)), hiH = on(f, 13.4) && !on(f, 16.6), hiW = on(f, 37.0) && !on(f, 39.6);
  const log = mode === 'pub'
    ? [['07:20', 'tiktok-poster', 'publicó 412 videos', 'listo'], ['07:21', 'reels-poster', 'publicó 388 videos', 'listo'], ['07:22', 'shorts-poster', 'publicó 440 videos', 'listo'], ['07:24', 'ad-uploader', 'subió 186 como anuncios', 'listo']]
    : [['06:58', 'trend-scanner', 'sacó 40 formatos en alza', 'listo'], ['07:04', 'hook-writer', 'escribió 50 hooks para ugc-08', 'listo'], ['07:10', 'cutter', 'terminó 212 videos', 'listo'], ['07:15', 'budget-mover', 'quiere $1,800 en 3 ganadores', 'te espera']];
  const hiLog = on(f, 4.8) && !on(f, 11.3) ? 0 : on(f, 11.3) && !on(f, 16.6) ? 1 : on(f, 39.6) && !on(f, 42.9) ? 3 : mode === 'pub' ? 0 : -1;
  const Cell: React.FC<{l: string; v: string; hi?: boolean}> = ({l, v, hi}) => <div style={{flex: 1, height: 40, borderRadius: 5, border: `1px solid ${hi ? TEAL : '#e6e6e3'}`, boxShadow: hi ? `0 0 0 1px ${TEAL}` : undefined, padding: '4px 6px', boxSizing: 'border-box'}}><div style={{fontFamily: SANS, fontSize: 5, color: '#777'}}>{l}</div><div style={{fontFamily: SANS, fontWeight: 600, fontSize: 13, color: hi ? TEAL : C.ink, marginTop: 3}}>{v}</div></div>;
  return <>
    <div style={{position: 'absolute', left: 78, top: 628, width: 278, height: 78, borderRadius: 7, background: '#fff', border: '1px solid #e3e3e0', padding: 6, boxSizing: 'border-box'}}>
      <div style={{fontFamily: SANS, fontWeight: 700, fontSize: 7, display: 'flex', gap: 4, alignItems: 'center'}}><Num n="02"/>Esta semana <span style={{fontWeight: 400, color: '#888', fontSize: 5}}>números ilustrativos</span></div>
      <div style={{display: 'flex', gap: 4, marginTop: 5}}><Cell l="Videos hechos" v={nfmt(videos(f))} hi={hiV}/><Cell l="Hooks probados" v={nfmt(hooks)} hi={hiH}/><Cell l="Ganadores" v={String(win)} hi={hiW}/><Cell l="Presupuesto movido" v={'$' + nfmt(spend)}/></div>
    </div>
    <div style={{position: 'absolute', left: 365, top: 628, width: 277, height: 78, borderRadius: 7, background: '#fff', border: '1px solid #e3e3e0', padding: 6, boxSizing: 'border-box'}}>
      <div style={{fontFamily: SANS, fontWeight: 700, fontSize: 7, display: 'flex', gap: 4, alignItems: 'center'}}><Num n="04"/>Registro de agentes <span style={{fontWeight: 400, color: '#888', fontSize: 5}}>esta mañana</span></div>
      {log.map(([h, a, t, s], i) => <div key={i} style={{display: 'flex', gap: 4, alignItems: 'center', height: 12, marginTop: i ? 1 : 4, padding: '0 4px', borderRadius: 3, border: `1px solid ${i === hiLog ? (s === 'te espera' ? ORANGE : TEAL) : 'transparent'}`, fontFamily: MONO, fontSize: 4.8, color: '#444'}}><span>{h}</span><span style={{color: ORANGE}}>{a}</span><span style={{fontFamily: SANS}}>{t}</span><span style={{flex: 1}}/><span style={{color: s === 'te espera' ? ORANGE : TEAL}}>{s}</span></div>)}
    </div>
  </>;
};
const Num: React.FC<{n: string}> = ({n}) => <span style={{width: 10, height: 10, borderRadius: 5, background: C.ink, color: '#fff', fontFamily: MONO, fontSize: 5, display: 'inline-flex', alignItems: 'center', justifyContent: 'center'}}>{n}</span>;

// cuadrícula de videos en loop
const Grid: React.FC<{f: number; empties?: number[]; marks?: Record<number, [string, string?]>}> = ({f, empties = [], marks = {}}) => {
  const rows = [0, 1, 2];
  return <div style={{position: 'absolute', left: 78, top: 713, width: 564, height: 368, borderRadius: 8, background: '#fff', border: '1px solid #e3e3e0', overflow: 'hidden'}}>
    <div style={{position: 'absolute', left: 8, top: 8, fontFamily: SANS, fontWeight: 700, fontSize: 9, display: 'flex', alignItems: 'center', gap: 5}}><Num n="07"/>Hecho esta semana <span style={{width: 6, height: 6, borderRadius: 3, background: RED, marginLeft: 3}}/><span style={{color: RED, fontWeight: 600}}>{nfmt(videos(f))} videos</span></div>
    <div style={{position: 'absolute', right: 8, top: 10, fontFamily: SANS, fontSize: 5.6, color: '#777'}}>20 clips, 3 filas, en loop</div>
    {rows.map((r) => {
      const dir = r === 1 ? 1 : -1;
      const off = ((f * 0.35 * dir) % 70 + 70) % 70;
      return Array.from({length: 10}).map((_, k) => {
        const idx = (r * 7 + k) % 20;
        const slot = r * 10 + k;
        const x = -60 + k * 70 + (dir > 0 ? off : -off + 70) - 35;
        const m = marks[slot];
        return <Tile key={`${r}${k}`} i={idx} x={x} y={26 + r * 113} f={f} empty={empties.includes(slot)} border={m?.[0]} badge={m?.[1]}/>;
      });
    })}
  </div>;
};

// ---------- escenas de foco ----------
const TrendPop: React.FC<{f: number}> = ({f}) => {
  const rows = [['Formato: POV, lo probé 7 días', '2.1M vistas, subiendo'], ['Hook: "Deja de scrollear si tu piel…"', 'usado 18K veces esta semana'], ['Formato: hablando a cámara en el carro', 'subiendo en suplementos'], ['Sonido: piano suave + susurro', 'tendencia hace 4 días'], ['Formato: 3 razones por las que cambié', '1.4M vistas, subiendo']];
  return <div style={{position: 'absolute', left: 180, top: 296, width: 218, borderRadius: 7, background: '#fff', border: `1.5px solid ${ORANGE}`, boxShadow: '0 6px 20px rgba(0,0,0,.15)', padding: 7, boxSizing: 'border-box', opacity: tw(f, 5.0, 5.3), transform: `translateY(${(1 - tw(f, 5.0, 5.3)) * 10}px)`, zIndex: 9}}>
    <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 6.6, color: ORANGE, marginBottom: 4}}>40 FORMATOS EN ALZA SACADOS HOY</div>
    {rows.map(([a, b], i) => <div key={i} style={{display: 'flex', gap: 6, alignItems: 'center', height: 32, opacity: tw(f, 6.0 + i * 0.6, 6.3 + i * 0.6)}}>
      <div style={{width: 14, height: 24, borderRadius: 2, overflow: 'hidden'}}><Img src={ug([0, 3, 5, 9, 14][i])} style={{width: '100%', height: '100%', objectFit: 'cover'}}/></div>
      <div><div style={{fontFamily: SANS, fontWeight: 600, fontSize: 7, color: C.ink}}>{a}</div><div style={{fontFamily: SANS, fontSize: 5.6, color: ORANGE}}>{b}</div></div>
    </div>)}
  </div>;
};

const HookFan: React.FC<{f: number}> = ({f}) => {
  const top = {x: 355, y: 325};
  const items = Array.from({length: 50}).map((_, i) => {
    const ring = i < 16 ? 0 : i < 34 ? 1 : 2;
    const idx = ring === 0 ? i : ring === 1 ? i - 16 : i - 34;
    const cnt = ring === 0 ? 16 : ring === 1 ? 18 : 16;
    const R = 45 + ring * 30;
    const a = Math.PI * (0.12 + (idx / (cnt - 1)) * 0.76);
    return [top.x - Math.cos(a) * (R + 40), top.y + Math.sin(a) * R + 20] as const;
  });
  const shown = Math.round(tw(f, 13.4, 15.2, 0, 50, 'lin'));
  const red = [2, 13, 26, 37, 49];
  const callouts = [['HOOK 3 DE 50', '"Dejé de comprar 5 sérums por este"', 165, 500], ['HOOK 27 DE 50', '"Nadie habla de este sérum de $19"', 305, 500], ['HOOK 50 DE 50', '"3 cosas que ojalá hubiera sabido"', 440, 500], ['HOOK 14 DE 50', '"POV: tu piel después de 14 días"', 250, 541], ['HOOK 38 DE 50', '"Mi dermatóloga me preguntó qué cambié"', 385, 541]] as const;
  return <>
    <svg style={{position: 'absolute', left: 0, top: 0, zIndex: 8}} width={W} height="700">
      {items.slice(0, shown).map(([x, y], i) => <g key={i}><line x1={top.x} y1={top.y} x2={x} y2={y} stroke={RED} strokeWidth=".35" strokeDasharray={red.includes(i) ? '2 2' : undefined}/><circle cx={x} cy={y} r="6" fill={red.includes(i) ? RED : '#fff'} stroke={RED} strokeWidth=".9"/><text x={x} y={y + 2} textAnchor="middle" fontSize="5" fontFamily="Inter" fill={red.includes(i) ? '#fff' : RED}>{i + 1}</text></g>)}
    </svg>
    <div style={{position: 'absolute', left: 447, top: 304, fontFamily: SANS, fontWeight: 700, fontSize: 6.6, color: RED, zIndex: 9, opacity: tw(f, 12.8, 13.1)}}>1 brief, 50 hooks</div>
    {callouts.map(([a, b, x, y], i) => <div key={a} style={{position: 'absolute', left: x - 58, top: y, width: 116, borderRadius: 4, background: '#fff', borderLeft: `2px solid ${RED}`, boxShadow: '0 3px 10px rgba(0,0,0,.12)', padding: '4px 6px', boxSizing: 'border-box', zIndex: 9, opacity: tw(f, 14.8 + i * 0.3, 15.0 + i * 0.3)}}><div style={{fontFamily: SANS, fontWeight: 700, fontSize: 5, color: RED}}>{a}</div><div style={{fontFamily: SANS, fontWeight: 600, fontSize: 6.8, color: C.ink, lineHeight: '8.5px'}}>{b}</div></div>)}
  </>;
};

const Avatars: React.FC<{f: number}> = ({f}) => {
  const picks = [1, 8, 13, 18];
  return <>
    <div style={{position: 'absolute', left: 325, top: 283, fontFamily: SANS, fontWeight: 700, fontSize: 6.2, color: PURPLE, zIndex: 9}}>48 AVATARES DE IA · 20 A LA VISTA</div>
    {Array.from({length: 20}).map((_, i) => {
      const x = 330 + (i % 5) * 41, y = 295 + Math.floor(i / 5) * 42;
      const t = 17.5 + i * 0.07;
      const pk = picks.includes(i) && on(f, 20.0 + picks.indexOf(i) * 0.3);
      const fi = FACES[(i * 4) % FACES.length];
      return <div key={i} style={{position: 'absolute', left: x, top: y, width: 36, height: 36, borderRadius: 18, overflow: 'hidden', border: `2px solid ${pk ? PURPLE : '#fff'}`, boxShadow: pk ? `0 0 0 2px ${PURPLE}55` : '0 1px 3px rgba(0,0,0,.2)', zIndex: 9, transform: `scale(${tw(f, t, t + 0.25)})`}}>
        <Img src={ug(fi)} style={{width: '100%', height: '170%', objectFit: 'cover', objectPosition: '50% 18%', transform: `scale(${1.5 + (i % 3) * 0.15})`, transformOrigin: '50% 22%'}}/>
      </div>;
    })}
    {on(f, 20.6) && <div style={{position: 'absolute', left: 395, top: 470, width: 140, borderRadius: 5, background: '#fff', borderLeft: `2px solid ${PURPLE}`, boxShadow: '0 3px 10px rgba(0,0,0,.14)', padding: '4px 7px', zIndex: 9, transform: `scale(${tw(f, 20.6, 20.8, 0.8, 1)})`}}><div style={{fontFamily: SANS, fontWeight: 700, fontSize: 5.2, color: PURPLE}}>AVATAR 09 · ELEGIDO POR TI</div><div style={{fontFamily: SANS, fontWeight: 600, fontSize: 7.4}}>cálida, 30 años, habla como una amiga</div></div>}
  </>;
};

const BigGrid: React.FC<{f: number}> = ({f}) => <>
  <div style={{position: 'absolute', left: 0, right: 0, top: 336, display: 'flex', justifyContent: 'center', zIndex: 10}}><div style={{padding: '6px 16px', borderRadius: 16, background: '#1b1b1b', color: '#fff', fontFamily: SANS, fontWeight: 700, fontSize: 13, display: 'flex', alignItems: 'center', gap: 7}}><span style={{width: 8, height: 8, borderRadius: 4, background: RED}}/>{nfmt(videos(f))} videos esta semana</div></div>
  <div style={{position: 'absolute', left: 78, top: 380, width: 564, height: 230, overflow: 'hidden', zIndex: 9}}>
    {[0, 1].map((r) => Array.from({length: 10}).map((_, k) => { const dir = r ? 1 : -1; const off = ((f * 0.5 * dir) % 70 + 70) % 70; return <Tile key={`${r}${k}`} i={(r * 11 + k * 3) % 20} x={-70 + k * 70 + (dir > 0 ? off : 70 - off)} y={r * 115} w={64} h={110} f={f}/>; }))}
  </div>
</>;

const Variants: React.FC<{f: number}> = ({f}) => <>
  <div style={{position: 'absolute', left: 85, top: 310, width: 83, height: 148, borderRadius: 10, border: '3px solid #222', overflow: 'hidden', zIndex: 9}}>
    <Img src={ug(5)} style={{width: '100%', height: '100%', objectFit: 'cover'}}/>
    <div style={{position: 'absolute', left: 4, bottom: 18, padding: '1px 4px', borderRadius: 2, background: RED, color: '#fff', fontFamily: SANS, fontWeight: 700, fontSize: 5}}>DE LAS FILAS</div>
    <div style={{position: 'absolute', left: 4, bottom: 6, color: '#fff', fontFamily: SANS, fontSize: 5}}>skincare</div>
  </div>
  <div style={{position: 'absolute', left: 104, top: 466, fontFamily: SANS, fontWeight: 600, fontSize: 7, color: RED, textAlign: 'center', zIndex: 9}}>1 video<br/>20 hooks</div>
  {HOOKS.map((h, i) => { const x = 192 + (i % 5) * 89, y = 297 + Math.floor(i / 5) * 81; const t = 28.4 + i * 0.1; return <div key={i} style={{position: 'absolute', left: x, top: y, display: 'flex', gap: 4, zIndex: 9, opacity: tw(f, t, t + 0.2), transform: `scale(${tw(f, t, t + 0.25, 0.7, 1)})`}}>
    <div style={{width: 36, height: 64, borderRadius: 3, overflow: 'hidden', boxShadow: i < 3 ? `0 0 0 1.5px ${RED}` : '0 1px 3px rgba(0,0,0,.2)'}}><Img src={ug(5)} style={{width: '100%', height: '100%', objectFit: 'cover'}}/></div>
    <div style={{width: 46}}><div style={{fontFamily: SANS, fontWeight: 700, fontSize: 6.4, color: i < 3 ? RED : C.ink}}>Hook {String.fromCharCode(65 + i)}</div><div style={{fontFamily: SANS, fontSize: 5.6, color: '#333', lineHeight: '7px'}}>{h}</div></div>
  </div>; })}
  <svg style={{position: 'absolute', left: 0, top: 0, zIndex: 8}} width={W} height="1280"><path d="M126 500 C 150 560, 240 640, 380 740" fill="none" stroke={RED} strokeWidth="1" strokeDasharray="3 3"/></svg>
</>;

const Publish: React.FC<{f: number}> = ({f}) => {
  const P = [['tiktok', 'TikTok', '412 publicados', 315, 345, 32.4], ['instagram', 'Reels', '388 publicados', 453, 385, 33.2], ['youtube', 'Shorts', '440 publicados', 572, 333, 34.0]] as const;
  return <>
    <svg style={{position: 'absolute', left: 0, top: 0, zIndex: 8}} width={W} height="1280">
      <path d="M166 545 C 220 520, 280 450, 300 370" fill="none" stroke={GOLD} strokeWidth="1"/>
      {[[160, 740, 315], [270, 740, 315], [340, 740, 453], [500, 740, 453], [560, 740, 572]].map(([x, y, tx], i) => <path key={i} d={`M${x} ${y} C ${x} 600, ${tx} 520, ${tx} ${i % 2 ? 400 : 368}`} fill="none" stroke={GOLD} strokeWidth="1" strokeDasharray="3 3" opacity={tw(f, 32.2 + i * 0.3, 32.6 + i * 0.3)}/>)}
    </svg>
    {P.map(([l, n, c, x, y, t]) => <div key={n} style={{position: 'absolute', left: x - 28, top: y - 28, width: 56, textAlign: 'center', zIndex: 9, transform: `scale(${tw(f, t - 0.6, t - 0.3)})`}}>
      <div style={{width: 46, height: 46, margin: '0 auto', borderRadius: 23, background: '#fff', border: '2px solid #222', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: '0 3px 10px rgba(0,0,0,.15)'}}><Ico n={l} s={26}/></div>
      <div style={{fontFamily: SANS, fontWeight: 700, fontSize: 8, marginTop: 3}}>{n}</div>
      <div style={{fontFamily: SANS, fontWeight: 600, fontSize: 6.4, color: GOLD}}>{on(f, t) ? c : '…'}</div>
    </div>)}
  </>;
};

const Testing: React.FC<{f: number}> = ({f}) => {
  const R = [['ugc-10, hook A', 'espera, ¿costaba $19?', 3.9, 640, 'GANADOR', 0], ['ugc-18, hook F', 'POV: día 14', 3.4, 580, 'GANADOR', 14], ['ugc-02, hook K', 'mi rutina de las 6am', 3.1, 580, 'GANADOR', 1], ['ugc-06, hook C', 'mi dermatóloga me preguntó', 2.2, 120, 'PROBANDO', 5], ['ugc-17, hook H', 'esto reemplazó mi rutina', 1.9, 120, 'PROBANDO', 9], ['ugc-03, hook B', 'nadie habla de esto', 1.7, 90, 'PROBANDO', 3], ['ugc-09, hook Q', 'reseña honesta, sin anuncios', 0.9, 0, 'PAUSADO', 12], ['ugc-05, hook D', '3 cosas que ojalá supiera', 0.7, 0, 'PAUSADO', 18]] as const;
  return <div style={{position: 'absolute', left: 195, top: 290, width: 326, borderRadius: 7, background: '#fff', boxShadow: '0 6px 22px rgba(0,0,0,.16)', border: '1px solid #e3e3e0', padding: 7, boxSizing: 'border-box', zIndex: 9, opacity: tw(f, 35.3, 35.6)}}>
    <div style={{display: 'flex', fontFamily: SANS, fontWeight: 800, fontSize: 7.4}}>TESTING <span style={{fontWeight: 400, fontSize: 5.6, marginLeft: 4, marginTop: 1}}>anuncios en vivo, 48 horas</span><span style={{flex: 1}}/><span style={{fontFamily: MONO, fontWeight: 400, fontSize: 5, color: '#666'}}>RETENCIÓN 3S · CTR · PRESUPUESTO</span></div>
    {R.map(([a, b, ctr, $, s, img], i) => {
      const w = s === 'GANADOR', p = s === 'PAUSADO';
      const lit = w && on(f, 36.9 + i * 0.15), off = p && on(f, 38.3 + (i - 6) * 0.2);
      const fill = tw(f, 35.6 + i * 0.08, 36.4 + i * 0.08);
      return <div key={i} style={{display: 'flex', alignItems: 'center', gap: 6, height: 31, marginTop: 4, padding: '0 5px', borderRadius: 4, background: lit ? '#E8F7F2' : '#fff', border: `1px solid ${lit ? TEAL : '#eee'}`, opacity: off ? 0.45 : 1}}>
        <div style={{width: 14, height: 24, borderRadius: 2, overflow: 'hidden'}}><Img src={ug(img)} style={{width: '100%', height: '100%', objectFit: 'cover'}}/></div>
        <div style={{width: 110}}><div style={{fontFamily: SANS, fontWeight: 700, fontSize: 6.6, textDecoration: off ? 'line-through' : undefined}}>{a}</div><div style={{fontFamily: SANS, fontSize: 5.4, color: '#666'}}>{b}</div></div>
        <div style={{width: 46, height: 4, borderRadius: 2, background: '#eee'}}><div style={{width: `${(ctr / 4) * 100 * fill}%`, height: '100%', borderRadius: 2, background: w ? TEAL : '#aaa'}}/></div>
        <div style={{width: 24, fontFamily: SANS, fontWeight: 600, fontSize: 6.6, textAlign: 'right'}}>{ctr}%</div>
        <div style={{width: 26, fontFamily: SANS, fontWeight: 700, fontSize: 6.6, color: w ? TEAL : '#555', textAlign: 'right'}}>${$}</div>
        <div style={{flex: 1}}/>
        <div style={{padding: '2px 4px', borderRadius: 2, background: lit ? TEAL : off ? '#ccc' : '#e7e7e4', color: lit || off ? '#fff' : '#888', fontFamily: MONO, fontWeight: 700, fontSize: 4.6}}>{lit ? 'GANADOR' : off ? 'PAUSADO' : 'PROBANDO'}</div>
      </div>;
    })}
  </div>;
};

const Phone: React.FC<{f: number}> = ({f}) => {
  const ok = on(f, 42.2);
  const press = tw(f, 41.7, 42.2);
  return <div style={{position: 'absolute', left: 218, top: 297, width: 284, height: 322, borderRadius: 34, background: '#111', padding: 9, boxSizing: 'border-box', zIndex: 9, boxShadow: '0 12px 40px rgba(0,0,0,.25)', transform: `translateY(${(1 - tw(f, 39.7, 40.1)) * 60}px)`, opacity: tw(f, 39.7, 39.95)}}>
    <div style={{width: '100%', height: '100%', borderRadius: 26, background: '#fff', position: 'relative', overflow: 'hidden', padding: '30px 18px', boxSizing: 'border-box'}}>
      <div style={{position: 'absolute', left: 108, top: 8, width: 58, height: 16, borderRadius: 8, background: '#111'}}/>
      <div style={{fontFamily: MONO, fontSize: 7, letterSpacing: 1, color: '#555'}}>TE ESPERA</div>
      <div style={{fontFamily: SANS, fontWeight: 800, fontSize: 19, color: C.ink}}>3 ganadores</div>
      <div style={{fontFamily: SANS, fontSize: 8.5, color: '#444'}}>quieren $1,800 más de presupuesto</div>
      <div style={{display: 'flex', gap: 4, marginTop: 8, alignItems: 'center'}}>{[0, 14, 1].map((k) => <div key={k} style={{width: 40, height: 70, borderRadius: 4, overflow: 'hidden', boxShadow: `0 0 0 1.5px ${TEAL}`}}><Img src={ug(k)} style={{width: '100%', height: '100%', objectFit: 'cover'}}/></div>)}
        <div style={{marginLeft: 4}}><div style={{fontFamily: SANS, fontSize: 7.5}}>ugc-10, ugc-18, ugc-02</div><div style={{fontFamily: SANS, fontWeight: 700, fontSize: 7, color: TEAL}}>71%, 66%, 62% retención</div></div></div>
      <div style={{marginTop: 12, height: 32, borderRadius: 8, background: ok ? TEAL : '#151515', color: '#fff', fontFamily: SANS, fontWeight: 700, fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'center', position: 'relative'}}>
        {ok ? 'Aprobado ✓' : 'Aprobar'}
        {!ok && <div style={{position: 'absolute', right: 14 + (1 - press) * 40, top: 8, width: 16, height: 16, borderRadius: 8, border: '2px solid #fff', background: BLUE, boxShadow: `0 0 0 ${6 * press}px ${BLUE}44`}}/>}
      </div>
      <div style={{marginTop: 7, height: 26, borderRadius: 8, border: '1px solid #ccc', fontFamily: SANS, fontSize: 10, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>Todavía no</div>
      <div style={{marginTop: 8, height: 26, borderRadius: 8, border: '1px solid #e3e3e0', fontFamily: SANS, fontSize: 8, display: 'flex', alignItems: 'center', padding: '0 10px'}}>212 videos listos para publicar<span style={{flex: 1}}/><span style={{color: BLUE, fontWeight: 600}}>Revisar</span></div>
    </div>
  </div>;
};

// ---------- titular ----------
const UP = (s: string) => s.toUpperCase();
const chunks = (() => {
  const out: {txt: string; a: number; b: number}[] = [];
  let cur: typeof WORDS = [];
  WORDS.forEach((w, i) => { cur.push(w); const nxt = WORDS[i + 1]; const weak = /^(y|los|las|el|la|de|del|con|a|que|un|una|tu|tus|se|en|por|más|otros|cada)$/i.test(w.w); const end = /[.,?!:]$/.test(w.w) || (cur.length >= 3 && !weak && !(nxt && /^[,.]/.test(nxt.w))); if (end || i === WORDS.length - 1) { out.push({txt: cur.map((x) => x.w).join(' '), a: cur[0].a, b: cur[cur.length - 1].b}); cur = []; } });
  return out.map((c, i) => ({...c, b: out[i + 1] ? out[i + 1].a : c.b + 3}));
})();

export const Edit: React.FC = () => {
  const f = useCurrentFrame();
  const t = (a: number, b: number) => f >= F(a) && f < F(b);
  const sc = t(4.7, 11.3) ? 'trend' : t(11.3, 16.6) ? 'scripts' : t(16.6, 22.0) ? 'crea' : t(22.0, 27.8) ? 'edit' : t(27.8, 31.8) ? 'var' : t(31.8, 35.2) ? 'pub' : t(35.2, 39.6) ? 'test' : t(39.6, 42.9) ? 'phone' : t(0, 4.7) ? 'hero' : 'cta';
  const focus = sc !== 'hero' && sc !== 'cta';
  const dim = focus ? 0.78 : 0;
  const cap = chunks.find((c) => f / FPS >= c.a - 0.03 && f / FPS < c.b);
  const hi = (k: string) => (sc === 'trend' && k === 'trend') || (sc === 'test' && k === 'test') || (sc === 'pub' && k === 'pub') || (sc === 'crea' && k === 'crea');
  const marks: Record<number, [string, string?]> = sc === 'test' ? {3: [TEAL, 'GANADOR'], 12: [TEAL, 'GANADOR'], 29: [TEAL, 'GANADOR']} : sc === 'phone' ? {1: [ORANGE, 'TE ESPERA'], 13: [ORANGE, 'TE ESPERA'], 26: [ORANGE, 'TE ESPERA']} : sc === 'hero' || sc === 'cta' ? {1: ['#B59B2B'], 4: ['#E0577A'], 7: [BLUE]} : {};
  const empties = sc === 'pub' ? [1, 3, 4, 6] : sc === 'var' ? [4] : [];
  return (
    <AbsoluteFill style={{background: BG}}>
      <style>{fontCss}</style>
      <div style={{position: 'absolute', left: 0, top: 0, width: 720, height: 1280, transform: 'scale(1.5)', transformOrigin: '0 0', overflow: 'hidden', backgroundImage: 'linear-gradient(#e4e4e1 1px, transparent 1px), linear-gradient(90deg, #e4e4e1 1px, transparent 1px)', backgroundSize: '24px 24px'}}>
        {/* logo */}
        {sc !== 'cta' && <div style={{position: 'absolute', left: 0, right: 0, top: 148, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 6}}><Img src={staticFile('img/lasala.png')} style={{width: 18, height: 18}}/><span style={{fontFamily: SANS, fontWeight: 800, fontSize: 14, color: C.ink}}>La Sala de IA</span></div>}
        {/* titular */}
        {sc === 'hero' && <div style={{position: 'absolute', left: 0, right: 0, top: 170, textAlign: 'center', fontFamily: SANS, fontWeight: 800, fontSize: 27, lineHeight: '31px', color: C.ink, letterSpacing: -0.8}}>Estos agentes de IA hacen<br/>+1,000 videos UGC a la semana</div>}
        {focus && cap && <div style={{position: 'absolute', left: 20, right: 20, top: 190, textAlign: 'center', fontFamily: MONO, fontWeight: 800, fontSize: 25, letterSpacing: 1.5, color: C.ink}}>{UP(cap.txt)}</div>}
        {sc === 'cta' && <div style={{position: 'absolute', left: 0, right: 0, top: 130, textAlign: 'center', zIndex: 20}}>
          <div style={{fontFamily: SANS, fontWeight: 900, fontSize: 58, color: C.ink, letterSpacing: -1.5, WebkitTextStroke: '6px #fff', paintOrder: 'stroke fill', transform: `scale(${tw(f, 42.95, 43.2, 0.7, 1)})`}}>COMENTA</div>
          <div style={{fontFamily: SANS, fontWeight: 900, fontSize: 74, color: BLUE, letterSpacing: -2, marginTop: -16, WebkitTextStroke: '7px #fff', paintOrder: 'stroke fill', transform: `scale(${tw(f, 43.4, 43.65, 0.5, 1)})`, opacity: tw(f, 43.4, 43.5)}}>UGC</div>
        </div>}
        {/* mapa */}
        <div style={{position: 'absolute', left: 78, top: 242, width: 564, height: 46, borderRadius: 7, background: '#fff', border: '1px solid #e3e3e0', opacity: 1 - dim}}>
          <div style={{position: 'absolute', left: 6, top: 5, fontFamily: SANS, fontWeight: 700, fontSize: 7, display: 'flex', gap: 4, alignItems: 'center'}}><Num n="01"/>Con qué empieza <span style={{fontWeight: 400, color: '#888', fontSize: 5}}>una marca, todo lo que ya tiene</span></div>
          <div style={{position: 'absolute', left: 6, right: 6, top: 21, display: 'flex', gap: 4}}>{SRC.map(([l, s]) => <div key={s} style={{flex: 1, height: 17, borderRadius: 4, border: '1px solid #e6e6e3', display: 'flex', alignItems: 'center', gap: 3, padding: '0 4px', fontFamily: SANS, fontSize: 4.8, whiteSpace: 'nowrap', overflow: 'hidden'}}><Ico n={l} s={8}/>{s}</div>)}</div>
        </div>
        <Graph f={f} dim={dim}/>
        {DEPTS.map((d) => <DeptCard key={d.k} d={d} hi={hi(d.k)} dim={dim}/>)}
        <Small x={280} y={304} w={160} c={RED} t="GUIONES Y HOOKS" n="22 agentes" rows={[['claude', 'Escritor de hooks'], ['claude', 'Guionista']]} hi={sc === 'scripts'} dim={dim}/>
        <Small x={280} y={575} w={160} c={RED} t="VARIANTES" n="12 agentes" rows={[['claude', 'Cambia hooks']]} more="+11 agentes más" hi={sc === 'var'} dim={dim}/>
        <div style={{opacity: sc === 'edit' ? 0.25 : 1}}><Stats f={f} mode={sc === 'pub' ? 'pub' : 'base'}/></div>
        <Grid f={f} empties={empties} marks={marks}/>
        {/* focos */}
        {sc === 'trend' && <TrendPop f={f}/>}
        {sc === 'scripts' && <HookFan f={f}/>}
        {sc === 'crea' && <Avatars f={f}/>}
        {sc === 'edit' && <BigGrid f={f}/>}
        {sc === 'var' && <Variants f={f}/>}
        {sc === 'pub' && <Publish f={f}/>}
        {sc === 'test' && <Testing f={f}/>}
        {sc === 'phone' && <Phone f={f}/>}
        {[790, 905, 1020].map((y, i) => <div key={y} style={{position: 'absolute', left: i === 1 ? 646 : 56, top: y, color: RED, fontFamily: SANS, fontWeight: 900, fontSize: 11}}>{i === 1 ? '»' : '«'}</div>)}
      </div>
      <Audio src={staticFile('voz.wav')}/>
    </AbsoluteFill>
  );
};
