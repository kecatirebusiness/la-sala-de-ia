# Tendencias

(lo llena el agente de tendencias cada lunes; testing anota aquí qué ángulos ganaron)
