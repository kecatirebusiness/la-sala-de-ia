# Voz de la marca

Tono:
Palabras que sí:
Palabras que nunca:
