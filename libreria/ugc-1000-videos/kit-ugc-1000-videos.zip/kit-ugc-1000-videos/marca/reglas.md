# Reglas

No se puede decir:
Necesita mi sí: publicar cualquier video, mover presupuesto, claims de salud/dinero, usar la cara de una persona real
Tope de gasto diario: $[TOPE]
