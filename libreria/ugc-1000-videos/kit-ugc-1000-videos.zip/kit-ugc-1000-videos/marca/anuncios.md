# Anuncios pasados

| Anuncio | Ángulo | CTR | Retención 3s | Compras | ¿Funcionó? |
|---|---|---|---|---|---|
