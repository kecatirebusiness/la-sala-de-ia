# Tu sí y ponerlo en automático

El estudio trabaja solo, pero nada sale sin tu sí: los videos nuevos, los cambios de presupuesto y cualquier claim delicado te llegan al teléfono y los apruebas con un toque. Lo demás corre a su hora: tendencias y hooks cada lunes, testing cada 48 horas.

## Prompt para Claude Code: CLAUDE.md del estudio + horarios

```
Crea un CLAUDE.md en la raíz de esta carpeta con las reglas del estudio: antes de cualquier tarea leer marca/, respetar marca/reglas.md, todo video nuevo va a borradores/ y nunca se publica sin mi sí, y ningún cambio de presupuesto se hace solo. Después prográmame: 1) los lunes a las 8:00, reporte de tendencias + 50 hooks nuevos; 2) cada 48 horas, el resumen de ganadores y perdedores; 3) cada mañana, un resumen de 5 líneas por Slack con lo que está esperando mi sí. Dime cómo quedaron programadas y cómo las pauso.
```
