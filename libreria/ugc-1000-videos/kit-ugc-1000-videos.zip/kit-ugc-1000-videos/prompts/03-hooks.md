# Guiones: 1 brief, 50 hooks

Con el brief de la marca y las tendencias, Claude escribe 50 hooks, cada uno desde un ángulo distinto (precio, dolor, curiosidad, prueba social, antes y después…), y el guion completo de los mejores.

## Prompt para Claude Code: 50 hooks UGC

```
Lee marca/brief.md, marca/resenas.md y tendencias.md. Escríbeme 50 hooks para videos UGC de 20 a 30 segundos, en español latino, hablados como una persona real a la cámara. Reparte los ángulos: 10 de dolor, 10 de curiosidad, 10 de prueba social, 10 de precio/valor y 10 de antes y después. Usa frases reales de las reseñas cuando puedas. Para los 10 mejores escribe el guion completo (hook de 3 segundos, problema, producto, prueba, CTA). Respeta marca/reglas.md. Guárdalo en hooks.md como tabla: número, ángulo, hook, guion.
```
