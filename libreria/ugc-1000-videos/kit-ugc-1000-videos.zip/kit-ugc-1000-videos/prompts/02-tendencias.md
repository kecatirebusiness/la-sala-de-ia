# Tendencias: qué está pegando hoy

Los agentes de tendencias revisan TikTok, Reels y la Ad Library de Meta y sacan los formatos, hooks y sonidos que están subiendo en tu nicho.

## Prompt para Claude Code: reporte de tendencias

```
Mi marca: lee marca/brief.md. Te pego lo que encontré esta semana en TikTok, Reels y la Ad Library de Meta: [PEGA LINKS O DESCRIPCIONES DE 10-20 VIDEOS QUE ESTÉN PEGANDO EN TU NICHO]. Sácame los 10 patrones que se repiten: formato (POV, hablando en el carro, 3 razones…), tipo de hook, sonido y duración. Ordénalos por cuántas veces aparecen, dime cuáles le quedan mejor a mi marca y por qué, y guárdalo en tendencias.md.
```
