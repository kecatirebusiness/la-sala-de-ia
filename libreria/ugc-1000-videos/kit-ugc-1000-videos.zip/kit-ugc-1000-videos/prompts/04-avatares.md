# Creadores: un avatar de IA para cada guion

Cada guion recibe un avatar que encaja con el producto, y tú eliges las caras que usa la marca. En Higgsfield creas el avatar con el producto en la mano y después lo pones a hablar con el audio del guion.

## Prompt de imagen para un avatar UGC (Higgsfield · Nano Banana Pro · 9:16)

```
Full-frame vertical selfie photo, edge to edge, no phone device visible, no camera interface, no overlays: [PERSONA, ej. a Latina woman in her early 30s with curly hair] in [LUGAR, ej. her bathroom] holding [TU PRODUCTO] next to her face, talking to the camera mid-sentence, natural window light, real skin texture with visible pores, casual and slightly imperfect framing.
```

Abrir: https://higgsfield.ai?fpr=kecatire

## Prompt para Claude Code: casting de avatares

```
Lee marca/brief.md y hooks.md. Para cada uno de los 10 guiones dime qué creador lo debería decir (edad, estilo, lugar, cómo sostiene el producto) para que se vea como un cliente real del producto. Agrúpalos en 4 o 5 caras que se repiten para que la marca tenga creadores fijos, y escríbeme el prompt de imagen de cada uno con la plantilla de arriba.
```
