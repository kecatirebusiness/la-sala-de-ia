# Variantes: un video se vuelve veinte

Al mismo video le cambias solo los primeros 3 segundos: 20 hooks distintos sobre el mismo cuerpo. Así pruebas ángulos sin grabar ni generar de nuevo.

## Prompt para Claude Code: 20 variantes de un video

```
Tengo este video terminado: [RUTA DEL VIDEO]. Transcríbelo con faster-whisper y detecta dónde termina el hook (los primeros 3 segundos). Con mis 20 mejores hooks de hooks.md, genera la voz de cada hook con ElevenLabs (la misma voz del video) y arma 20 versiones en Remotion: el hook nuevo con subtítulos + el resto del video original. Nómbralas hook-A … hook-T.
```
