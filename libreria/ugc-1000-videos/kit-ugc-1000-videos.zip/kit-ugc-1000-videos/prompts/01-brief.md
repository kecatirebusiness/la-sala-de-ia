# Lo que entra: el brief de la marca

Todo el estudio lee los mismos archivos: qué vendes, a quién, cómo habla la marca, qué dicen las reseñas y qué anuncios ya funcionaron. Se escriben una vez y cada agente los usa. Pídele a Claude que te los arme con una entrevista corta.

## Prompt para Claude Code: el brief de la marca

```
Vamos a montar un estudio de videos UGC para mi marca. Hazme una entrevista corta (una pregunta a la vez, máximo 10) y con mis respuestas crea esta carpeta:

marca/
  brief.md      → producto, precio, a quién le vendo, la promesa principal y las objeciones
  voz.md        → cómo habla la marca, palabras que sí y palabras que nunca
  resenas.md    → las frases reales de clientes que más se repiten (te pego reseñas)
  anuncios.md   → qué anuncios pasados funcionaron y cuáles no, con números si los tengo
  reglas.md     → qué no se puede decir (claims, garantías) y qué necesita mi sí antes de publicar

Mi marca: [QUÉ VENDES Y A QUIÉN EN 2 LÍNEAS]. Escribe todo en español, corto y concreto.
```
