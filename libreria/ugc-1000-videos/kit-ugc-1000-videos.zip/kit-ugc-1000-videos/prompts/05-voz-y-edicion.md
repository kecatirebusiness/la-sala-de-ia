# Voz y edición: el video terminado

Cada creador tiene su voz en ElevenLabs. Con el audio del guion, Higgsfield hace el lip-sync y Remotion arma el video: cortes cada 2-3 segundos, subtítulos palabra por palabra, b-roll del producto y música baja. Un mismo proyecto de Remotion sirve para todos los videos de la marca.

## Prompt para Claude Code: voz + edición de un UGC

```
Para el guion [NÚMERO] de hooks.md: 1) genera la voz con ElevenLabs (voz [VOICE_ID], modelo eleven_v4, español latino) y guárdala en audio/; 2) cuando te pase el video del avatar hablando [RUTA], transcríbelo con faster-whisper con tiempos por palabra; 3) arma un proyecto de Remotion 1080x1920 con subtítulos grandes palabra por palabra dentro de la zona segura de Reels, un corte o zoom cada 2-3 segundos, el b-roll del producto de broll/ donde se mencione y la música de musica/ 10 dB por debajo de la voz; 4) renderiza y déjalo en borradores/ para que yo lo apruebe.
```
