# Publicación y testing: el presupuesto va a los ganadores

Todo se programa en TikTok, Reels y Shorts y se prueba como anuncio 48 horas. Testing mira la retención de 3 segundos, el CTR y el gasto: los ganadores reciben más presupuesto y los perdedores se pausan.

## Prompt para Claude Code: calendario de publicación

```
Tengo estos videos aprobados en aprobados/: [LISTA O CARPETA]. Hazme el calendario de la semana: qué video sale en TikTok, Reels y Shorts, qué día y a qué hora, sin repetir el mismo hook dos días seguidos. Escribe el caption de cada uno con la voz de marca/voz.md y dámelo en una tabla lista para cargar en Metricool.
```

## Prompt para Claude Code: elegir ganadores

```
Te pego los resultados de 48 horas de mis anuncios: [PEGA LA TABLA DE META ADS: anuncio, retención 3s, CTR, gasto, compras]. Ordénalos, marca como GANADOR los que superen [TU REGLA, ej. CTR > 3% y retención > 60%], como PAUSAR los que estén por debajo de [TU REGLA], y dime cuánto presupuesto mover a cada ganador. No cambies nada: dame el resumen para que yo lo apruebe. Anota en tendencias.md qué ángulos ganaron para que los próximos hooks salgan de ahí.
```
