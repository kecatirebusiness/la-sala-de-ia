# Kit · Mapa UGC (La Sala de IA)

1. `npm i` y pon tu voz en `public/voz.wav`.
2. Cambia las 20 imágenes de `public/ugc/` por clips o fotos de tu marca (u00.jpg … u19.jpg).
3. Los tiempos de cada frase están en `src/tiempos.json` (los arma `scripts/coloca3.py`).
4. `npx remotion studio src/index.ts` para verlo y `npx remotion render src/index.ts Edit out/video.mp4` para exportar.
