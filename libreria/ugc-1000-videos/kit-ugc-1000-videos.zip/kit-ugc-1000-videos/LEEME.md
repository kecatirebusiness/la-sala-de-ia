# Kit · Estudio UGC (+1,000 videos a la semana)

Qué hay aquí:
- CLAUDE.md → las reglas del estudio. Abre Claude Code dentro de esta carpeta.
- marca/ → lo que entra: brief, voz, reseñas, anuncios y reglas. Rellénalo o pídele a Claude la entrevista (prompts/01-brief.md).
- prompts/ → un archivo por paso, en el mismo orden que la página de la librería.
- mapa-estudio-ugc.md → los 8 equipos con sus agentes y herramientas.
- borradores/ → todo lo que espera tu sí. aprobados/ → lo que ya aprobaste y se puede publicar.
- audio/, broll/, musica/ → las voces, las tomas del producto y la música de cada video.

Orden recomendado (un fin de semana):
1. Brief de la marca  2. Tendencias  3. 50 hooks  4. Avatares  5. Voz + edición de 5 videos
6. Variantes  7. Publicación y testing  8. Ponlo en automático

Montado juntos, paso a paso, en La Sala de IA: https://lasaladeia.com
