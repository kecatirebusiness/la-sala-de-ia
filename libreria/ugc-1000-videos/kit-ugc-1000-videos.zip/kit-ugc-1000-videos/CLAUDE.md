# Estudio UGC de mi marca

Antes de CUALQUIER tarea lee marca/brief.md, marca/voz.md y marca/reglas.md.

Reglas fijas:
- Todo video nuevo va a borradores/. Nunca se publica nada sin mi sí.
- Ningún cambio de presupuesto en anuncios se hace solo: me mandas el resumen y yo apruebo.
- Nunca inventes claims, resultados ni garantías: solo lo que está en marca/brief.md y marca/reglas.md.
- Los hooks se escriben en español latino, como habla una persona real, usando frases de marca/resenas.md.
- Al terminar una tarea, anota en registro.md qué hiciste y qué quedó esperando mi sí.
